/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#ifndef RCL_ANY_VECTOR_ARRAY_MARSHALER_H
#define RCL_ANY_VECTOR_ARRAY_MARSHALER_H

/**
 * @file AnyVectorArrayMarshaler.h
 * @author the Rooftop team
 * defines the marshaler class for array of AnyVector<T>
 */

#include "AnyVectorMarshaler.h"

template<class T>
using AnyVectorArray = typename std::vector<Keysight::ModularInstruments::AnyVector<T>>;

namespace Keysight {
namespace ApiCoreLibraries {


/**
 *@brief Generic template for AnyVector<T> marshaler
 *@tparam T the element type of AnyVector
*/
template <class T>
class AnyVectorArrayMarshaler : public Keysight::ApiCoreLibraries::ICustomMarshaler<AnyVectorArray<T>>
{
    using AnyVectorByte = typename Keysight::ModularInstruments::AnyVector<std::uint8_t>;
    using AnyVectorByteMarshaler = typename Keysight::ApiCoreLibraries::AnyVectorMarshaler<std::uint8_t>;
    using AnyVectorT = typename Keysight::ModularInstruments::AnyVector<T>;
    using AnyVectorTMarshaler = typename Keysight::ApiCoreLibraries::AnyVectorMarshaler<T>;

    AnyVectorByteMarshaler mAnyVectorByteMarshaler;
    AnyVectorTMarshaler mAnyVectorTMarshaler;

    // The AnyVector<std::uint8> object need to be cached because it can only be initialized from the .NET side (cannot
    // constructed from C++ because C++ don't have the memory allocating delegate)
    // Cache the AnyVector<std::uint8> here, this may cause problem when supporting marshaling multiple AnyVectorArray
    // Probably we can put it in the MarshalBuffer?? Queue<AnyVectorByte>??
    AnyVectorByte mAnyVectorByte;


public:
    void BytesToCpp(MarshalBuffer& marshalBuffer, AnyVectorArray<T>& result) override
    {
        result.clear();

        mAnyVectorByteMarshaler.BytesToCpp(marshalBuffer, mAnyVectorByte);
        auto innerMarshalBuffer = MarshalBuffer(mAnyVectorByte.getSpan().data(),
            static_cast<std::int32_t>(mAnyVectorByte.getSpan().size()));
        auto avn = mAnyVectorByte.size() / mAnyVectorTMarshaler.GetBufferSize();
        for (int i = 0; i < static_cast<int>(avn); ++i)
        {
            auto avt = AnyVectorT();
            mAnyVectorTMarshaler.BytesToCpp(innerMarshalBuffer, avt);
            result.emplace_back(avt);
        }
    }

    void CppToBytes(const AnyVectorArray<T>& input, MarshalBuffer& marshalBuffer) override
    {
        auto requiredSize = input.size() * mAnyVectorTMarshaler.GetBufferSize();
        mAnyVectorByte.resize(requiredSize);
        auto innerMarshalBuffer = MarshalBuffer(mAnyVectorByte.getSpan().data(),
            static_cast<std::int32_t>(mAnyVectorByte.getSpan().size()));
        for (int i = 0; i < static_cast<int>(input.size()); i++)
        {
            mAnyVectorTMarshaler.CppToBytes(input[i], innerMarshalBuffer);
        }
        // Now the anyvector array is marshaled to the buffer that mAnyVectorByte allocated
        mAnyVectorByteMarshaler.CppToBytes(mAnyVectorByte, marshalBuffer);
    }

    std::int32_t GetBufferSize() const override
    {
        return mAnyVectorByteMarshaler.GetBufferSize();
    }
};

}}
#endif // RCL_ANY_VECTOR_ARRAY_MARSHALER_H