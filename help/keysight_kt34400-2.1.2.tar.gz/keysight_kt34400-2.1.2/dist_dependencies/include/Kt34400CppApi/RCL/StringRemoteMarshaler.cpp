#include "StringRemoteMarshaler.h"

using namespace Keysight::ApiCoreLibraries;

void StringRemoteMarshaler::BytesToCpp(MarshalBuffer& marshalBuffer, std::string& result)
{
	std::int32_t size = 0;
	mInt32Marshaler.BytesToCpp(marshalBuffer, size);
	result.assign(reinterpret_cast<char*>(marshalBuffer.Bytes()), size);
	marshalBuffer.Forward(static_cast<std::int32_t>(result.size()));
}

void StringRemoteMarshaler::CppToBytes(const std::string& input, MarshalBuffer& marshalBuffer)
{
	mInt32Marshaler.CppToBytes(static_cast<std::int32_t>(input.size()), marshalBuffer);
	uint8_t* buffer = marshalBuffer.Bytes();
	std::memcpy(buffer, input.c_str(), input.size());
	marshalBuffer.Forward(static_cast<std::int32_t>(input.size()));
}

std::int32_t StringRemoteMarshaler::GetBufferSize() const
{
	throw std::runtime_error("Should not be called here!");
}

std::int32_t StringRemoteMarshaler::GetBufferSizeForRPC(const std::string& input) const
{
	// return real size of string and size of int32_t for string length
	return static_cast<std::int32_t>(input.size()) + sizeof(std::int32_t);
}
