/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#ifndef RCL_OS_H
#define RCL_OS_H

/**
 * @file OS.h
 * @author the Rooftop team
 *
 * This header file attempts to abstract the underlying operating system so that
 * the Rooftop class library will work on both POSIX and windows systems.
 */

#ifdef _WIN32

// Remove the definition in WinUser.h
#ifdef GetMessage
#undef GetMessage
#endif

#endif

#endif // RCL_OS_H