/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#include "RepCap.h"

using namespace std;
using namespace Keysight::ApiCoreLibraries;

RepCap::RepCap(const std::shared_ptr<DriverNode>& parent, const std::string& name, std::int32_t index)
    : DriverNode(parent)
    , mName(name)
    , mIndex(index)
{
}

string RepCap::GetRCName(std::int32_t level) const
{
    if (level < 0)
        throw invalid_argument("Parameter \"level\" in GetRCIndex should >= 0");

    if (level == 0)
        return mName;

    return this->GetParent()->GetRCName(--level);
}

int32_t RepCap::GetRCIndex(std::int32_t level) const
{
    if (level < 0)
        throw invalid_argument("Parameter \"level\" in GetRCIndex should >= 0");

    if (level == 0)
        return mIndex;

    return this->GetParent()->GetRCIndex(--level);
}
