/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************
 * @file DriverConfiguration.h
 *
 * This is the configuration for the use of the driver support class. 
 */
#ifndef SCPIDRIVERSUPPORT_DRIVER_CONFIGURATION_H
#define SCPIDRIVERSUPPORT_DRIVER_CONFIGURATION_H

#include "Log/ILogger.h"
#include <string>
#include <vector>

namespace Keysight {
namespace ApiCoreLibraries {

/**
 * @brief DriverConfiguration is a class contains all the configurable informations 
 * for the client to set before communicating with instrument.
 * 
 */
class DriverConfiguration
{
public:
    /**
    * @brief Construct a instance for driver configurations.
    *
    * @param model The model name.
    * @param supportedModels Array of model names supported by this driver.
    * @param queryInstrumentStatus If true, will query the status of instrument
    * @param simulate If true, will simulate the I/O operation to instrument.
    * @param logger The reference to logger, default is null
    * @param maxLogArrayBytes The maximum number of bytes for logging arrays, default is 1024
    */
    DriverConfiguration(const std::string& model,
                        const std::vector<std::string>& supportedModels,
                        bool queryInstrumentStatus,
                        bool simulate,
                        const std::shared_ptr<Keysight::ModularInstruments::ILogger>& logger = nullptr,
                        std::int32_t maxLogArrayBytes = 1024);

private:
    std::string mModel;
    std::vector<std::string> mSupportedModels;
    bool mQueryInstrumentStatus;
    bool mSimulate;
    const std::shared_ptr<Keysight::ModularInstruments::ILogger> mpLogger{ nullptr };
    std::int32_t mMaxLogArrayBytes = 1024;

public:
    /**
    * @brief Get the value of whether to query the status of instrument.
    *
    * @return The value of whether to query the status of instrument.
    */
    bool getQueryInstrumentStatus() const { return mQueryInstrumentStatus; }
    /**
    * @brief If true, simulate I/O to/from the instrument.
    *
    * @return If true, simulate I/O to/from the instrument.
    */
    bool getSimulate() const { return mSimulate; }
    /**
    * @brief Get the instrument model name.
    *
    * @return The model name.
    */
    std::string getModel() const { return mModel; }
    /**
    * @brief Get the supported models.
    *
    * @return The supported models.
    */
    std::vector<std::string> getSupportedModels() const { return mSupportedModels; }
    /**
    * @brief Get the reference to logger.
    *
    * @return The reference to logger.If NULL, logging is disabled.
    */
    const std::shared_ptr<Keysight::ModularInstruments::ILogger> getLogger() const { return mpLogger; }
    /**
    * @brief Get the maximum number of bytes for logging arrays.
    *
    * @return The maximum number of bytes for logging arrays.
    */
    int getMaxLogArrayByte() const { return mMaxLogArrayBytes;}
};

}}
#endif // SCPIDRIVERSUPPORT_DRIVER_CONFIGURATION_H