/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************
* @file DriverConfiguration.cpp
*
* This is the configuration for the use of the driver support class.
*/
#include "DriverConfiguration.h"

using namespace Keysight::ApiCoreLibraries;

DriverConfiguration::DriverConfiguration(const std::string& model,
                                         const std::vector<std::string>& supportedModels,
                                         bool queryInstrumentStatus,
                                         bool simulate,
                                         const std::shared_ptr<Keysight::ModularInstruments::ILogger>& logger,
                                         std::int32_t maxLogArrayBytes)
    : mModel(model)
    , mSupportedModels(supportedModels)
    , mQueryInstrumentStatus(queryInstrumentStatus)
    , mSimulate(simulate)
    , mpLogger(logger)
    , mMaxLogArrayBytes(maxLogArrayBytes)
{
}
