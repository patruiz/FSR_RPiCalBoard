/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************
 * @file ScpiDriverSupport.h
 *
 * This is the class exported to clients.
 */
#ifndef SCPIDRIVERSUPPORT_SCPI_DRIVER_SUPPORT_H
#define SCPIDRIVERSUPPORT_SCPI_DRIVER_SUPPORT_H

#include "DriverConfiguration.h"
#include "ScpiIoSupport.h"
#include "IviErrorQueryResult.h"
#include "IviSelfTestResult.h"
#include <memory>
#include <string>

namespace Keysight {
namespace ApiCoreLibraries {

/**
* @brief ScpiDriverSupport is a class exported to clients.
*
*/
class ScpiDriverSupport
{
public:
    /**
    * @brief Construct an instance for SCPI I/O.
    *
    * @param idQuery If true, this will query the instrument model.
    * @param reset If true, the instrument is reset at initialization.
    * @param config The driver configuration data.
    * @param scpiIoSupport The reference of SCPI I/O object.
    */
    ScpiDriverSupport(bool idQuery, bool reset, const DriverConfiguration& config, const std::shared_ptr<Keysight::ApiCoreLibraries::ScpiIoSupport::ScpiIoSupport>& scpiIoSupport);
    ~ScpiDriverSupport() = default;
    ScpiDriverSupport(const ScpiDriverSupport&) = delete;
    ScpiDriverSupport& operator=(const ScpiDriverSupport&) = delete;

private:
    DriverConfiguration mConfig;
    std::shared_ptr<Keysight::ApiCoreLibraries::ScpiIoSupport::ScpiIoSupport> mpScpiIoSupport { nullptr };
    std::string mManufacturerName;
    std::string mModelName;
    std::string mModelSerialNumber;
    std::string mModelFWVersion;
    bool mQueryInstrumentStatus;

    void getIdentification();

public:
    /**
    * @brief Get the VISA address of the connected instrument. May be a VISA alias.
    *
    * @return The VISA address of the connected instrument. May be a VISA alias.
    */
    std::string getResourceName();
    /**
    * @brief Get a reference to the ScpiIoSupport object.
    *
    * @return A reference to the ScpiIoSupport object.
    */
    const std::shared_ptr<Keysight::ApiCoreLibraries::ScpiIoSupport::ScpiIoSupport> getScpiIoSupport() { return mpScpiIoSupport;}
    /**
    * @brief Get the value of whether to query the status of instrument.
    *
    * @return The value of whether to query the status of instrument.
    */
    bool getQueryInstrumentStatus() const { return mQueryInstrumentStatus; }
    /**
    * @brief Set the value of whether to query the status of instrument.
    *
    * @param enabled The value of whether to query the status of instrument.
    */
    void setQueryInstrumentStatus(bool enabled) { mQueryInstrumentStatus = enabled; }
    /**
    * @brief If true, simulate I/O to/from the instrument.
    *
    * @return If true, simulate I/O to/from the instrument.
    */
    bool getSimulate() const { return mConfig.getSimulate(); }
    /**
    * @brief Get the supported models.
    *
    * @return The supported models.
    */
    std::vector<std::string> getSupportedModels() const { return mConfig.getSupportedModels(); }
    /**
    * @brief Get the reference to logger.
    *
    * @return The reference to logger.If NULL, logging is disabled.
    */
    const std::shared_ptr<Keysight::ModularInstruments::ILogger> getLogger() const { return mConfig.getLogger(); }
    /**
    * @brief Get the maximum number of bytes for logging arrays.
    *
    * @return The maximum number of bytes for logging arrays.
    */
    int getMaxLogArrayByte() const { return mConfig.getMaxLogArrayByte(); }

    /**
    * @brief Get the instrument manufacture.
    *
    * @return The instrument manufacture string.
    */
    std::string getInstrumentManufacturerName();
    /**
    * @brief Get the instrument model.
    *
    * @return The instrument model name string.
    */
    std::string getModelName();
    /**
    * @brief Get the instrument serial number.
    *
    * @return The instrument serial number string.
    */
    std::string getInstrumentSerialNumber();
    /**
    * @brief Get the instrument firmware version.
    *
    * @return The instrument firmware version string.
    */
    std::string getInstrumentFirmwareVersion();

    /**
    * @brief Places the instrument in a known state and configures instrument options on which the IVI specific driver depends (for example, enabling/disabling headers).
    *        For an IEEE 488.2 instrument, Reset sends the command string *RST to the instrument.
    *
    * @param maxTimeMilliseconds The maximum timeout value in milliseconds.
    */
    void reset(long maxTimeMilliseconds);
    /**
    * @brief Queries the instrument and returns instrument specific error information.
    *
    * @return Error code and error message.
    */
    IviErrorQueryResult errorQuery();
    /**
    * @brief Performs an instrument self test, waits for the instrument to complete the test, and queries the instrument for the results.
    *        If the instrument passes the test, TestResult is zero and TestMessage is 'Self test passed'.
    *
    * @param maxTimeMilliseconds The maximum timeout value in milliseconds.
    * @return Error code and error message.
    */
    IviSelfTestResult selfTest(long maxTimeMilliseconds);
    /**
    * @brief Wait until all previously started instrument I/O operations complete or throws exception if @p timeoutMilliSeconds is reached.
    *
    * @param timeoutMilliSeconds A time out value in millisecond.
    */
    void waitForOperationComplete(long timeoutMilliSeconds);

    /**
    * @brief Poll errors in instrument.
    */
    void pollInstrumentErrors();

    /**
    * @brief End I/O operations and release the I/O resources.
    */
    void close();
};
}}
#endif // SCPIDRIVERSUPPORT_SCPI_DRIVER_SUPPORT_H