/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************
 * @file ScpiDriverSupport.cpp
 *
 * Defines the exported functions for the DLL application.
 */

#include "ScpiDriverSupport.h"
#include "StringUtility.h"
#include <thread>

using namespace std;
using namespace Keysight::ApiCoreLibraries;


// bit definition for register ESR
const int32_t ESR_QYE = 4;              //QYE(Query ERROR)
const int32_t ESR_DDE = 8;              //DDE(Device - Dependent ERROR)
const int32_t ESR_EXE = 16;             //EXE(Execution ERROR)
const int32_t ESR_CME = 32;             //CME(Command ERROR)


ScpiDriverSupport::ScpiDriverSupport(bool idQuery, bool reset, const DriverConfiguration& config, const shared_ptr<Keysight::ApiCoreLibraries::ScpiIoSupport::ScpiIoSupport>& scpiIoSupport)
    : mConfig(config)
    , mpScpiIoSupport(scpiIoSupport)
    , mQueryInstrumentStatus(mConfig.getQueryInstrumentStatus())
{
    if (!mConfig.getSimulate())
    {
        getIdentification();
    }
}

string ScpiDriverSupport::getResourceName()
{
    return mpScpiIoSupport->getScpiIoResource().resourceName;
}

void ScpiDriverSupport::close()
{
    mpScpiIoSupport->close();
}


void ScpiDriverSupport::getIdentification()
{
    auto scpiIo = mpScpiIoSupport->getScpiIo();
    scpiIo->write("*IDN?");
    auto result = scpiIo->read();

    auto idnStrs{ vector<string>{} };
    StringUtility::SplitWithoutTrim(result, ',', idnStrs);
    if (!idnStrs.empty() && sizeof(idnStrs)>= 3)
    {
        if (!idnStrs[0].empty())
        {
            mManufacturerName = idnStrs[0];
        }

        if (!idnStrs[1].empty())
        {
            mModelName = idnStrs[1];
        }

        if (!idnStrs[2].empty())
        {
            mModelSerialNumber = idnStrs[2];
        }

        if (!idnStrs[3].empty())
        {
            mModelFWVersion = idnStrs[3];
        }
    }
}

string ScpiDriverSupport::getInstrumentManufacturerName()
{
    return mConfig.getSimulate() ? "Keysight Technologies" : mManufacturerName;
}

string ScpiDriverSupport::getModelName()
{
    return mConfig.getSimulate() ? mConfig.getModel() : mModelName;
}

string ScpiDriverSupport::getInstrumentSerialNumber()
{
    return mConfig.getSimulate() ? "Sim0000" : mModelSerialNumber;
}

string ScpiDriverSupport::getInstrumentFirmwareVersion()
{
    return mConfig.getSimulate() ? "Sim.0.0.0" : mModelFWVersion;
}

void ScpiDriverSupport::reset(long maxTimeMilliseconds)
{
    auto scpiIo = mpScpiIoSupport->getScpiIo();
    if (mConfig.getSimulate())
    {
        scpiIo->clear(); // Clears cached simulation values
    }

    auto lTimeout = scpiIo->getIoTimeout();

    if (lTimeout < maxTimeMilliseconds)
    {
        scpiIo->setIoTimeout(maxTimeMilliseconds);
    }

    scpiIo->write("*RST;*OPC?");
    scpiIo->read();

    if (lTimeout < maxTimeMilliseconds)
    {
        scpiIo->setIoTimeout(lTimeout);
    }
}

IviErrorQueryResult ScpiDriverSupport::errorQuery()
{
    if (mConfig.getSimulate())
    {
        return{ 0, "No error" };
    }

    auto errorCode = 0;
    auto message = string{};
    auto scpiIo = mpScpiIoSupport->getScpiIo();

    scpiIo->write("SYST:ERR?");
    auto retVal = scpiIo->read();

    vector<string> errorQueryVector;
    StringUtility::SplitWithoutTrim(retVal, ',', errorQueryVector);
    errorCode = stol(errorQueryVector[0]);
    // Some instruments do not return a message
    if (errorQueryVector.size() > 1)
    {
        message = errorQueryVector[1];
    }

    return{ errorCode, message };
}

IviSelfTestResult ScpiDriverSupport::selfTest(long maxTimeMilliseconds)
{
    if (mConfig.getSimulate())
    {
        return{ 0, "Self test passed." };
    }

    auto errorCode = 0;
    auto message = string{};

    auto scpiIo = mpScpiIoSupport->getScpiIo();

    auto lTimeout = scpiIo->getIoTimeout();
    if (lTimeout < maxTimeMilliseconds)
    {
        scpiIo->setIoTimeout(maxTimeMilliseconds);
    }

    scpiIo->write("*TST?");
    auto retVal = scpiIo->read();

    vector<string> selfTestVector{};
    StringUtility::SplitWithoutTrim(retVal, ',', selfTestVector);
    errorCode = stol(selfTestVector[0]);
    if (selfTestVector.size() > 1)// Some instruments do not return a message
    {
        message = selfTestVector[1];
    }
    else
    {
        message = (errorCode == 0) ? "Self test passed" : "Self test failed";
    }

    if (lTimeout < maxTimeMilliseconds)
    {
        scpiIo->setIoTimeout(lTimeout);
    }

    return{ errorCode, message };
}

void ScpiDriverSupport::waitForOperationComplete(long timeoutMilliSeconds)
{
    auto scpiIo = mpScpiIoSupport->getScpiIo();
    auto lTimeout = scpiIo->getIoTimeout();
    try
    {
        scpiIo->setIoTimeout(timeoutMilliSeconds);

        scpiIo->write("*OPC?");
        scpiIo->read();

        scpiIo->setIoTimeout(lTimeout);
    }
    catch (const exception&)
    {
        this_thread::sleep_for(chrono::milliseconds(100)); // Instrument may need a moment...
        scpiIo->setIoTimeout(lTimeout);
        scpiIo->clear();
        scpiIo->write(""); // Some instruments need this to prevent *CLS from leaving query interrupted error in the queue.
        scpiIo->write("*CLS"); // Clear instrument query interrupted error
        throw;
    }
}

void ScpiDriverSupport::pollInstrumentErrors()
{
    if (!mQueryInstrumentStatus)
        return;

    int value{};
    try
    {
        //Query bits of the Standard Event Status Register.
        mpScpiIoSupport->getScpiFormattedIo()->output("*ESR?");
        mpScpiIoSupport->getScpiFormattedIo()->enter(value);
    }
    catch (const runtime_error&)
    {
        mpScpiIoSupport->getScpiIo()->clear();
        throw;
    }

    if (value & (ESR_CME | ESR_DDE | ESR_EXE | ESR_QYE))
    {
        throw runtime_error("Instrument error detected.  Use ErrorQuery() to determine the error(s).");
    }
}
