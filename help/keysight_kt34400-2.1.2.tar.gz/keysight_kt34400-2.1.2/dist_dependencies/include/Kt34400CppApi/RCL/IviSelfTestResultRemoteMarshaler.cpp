/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#include "IviSelfTestResultRemoteMarshaler.h"
#include "StringRemoteMarshaler.h"

using namespace Keysight::ApiCoreLibraries;

void IviSelfTestResultRemoteMarshaler::BytesToCpp(MarshalBuffer& marshalBuffer, IviSelfTestResult& result)
{
	std::int32_t code = 0;
	mInt32Marshaler.BytesToCpp(marshalBuffer, code);
	std::string message;
	
	mStringRemoteMarshaler.BytesToCpp(marshalBuffer, message);
	result = Keysight::ApiCoreLibraries::IviSelfTestResult(code, message);
}

void IviSelfTestResultRemoteMarshaler::CppToBytes(const IviSelfTestResult& input, MarshalBuffer& marshalBuffer)
{
	mInt32Marshaler.CppToBytes(input.GetCode(), marshalBuffer);
	mStringRemoteMarshaler.CppToBytes(input.GetMessage(), marshalBuffer);
}

std::int32_t IviSelfTestResultRemoteMarshaler::GetBufferSize() const
{
	throw std::runtime_error("Should not be called here!");
}

std::int32_t IviSelfTestResultRemoteMarshaler::GetBufferSizeForRPC(const IviSelfTestResult& input) const
{
	return mInt32Marshaler.GetBufferSize() + mStringRemoteMarshaler.GetBufferSizeForRPC(input.GetMessage());
}