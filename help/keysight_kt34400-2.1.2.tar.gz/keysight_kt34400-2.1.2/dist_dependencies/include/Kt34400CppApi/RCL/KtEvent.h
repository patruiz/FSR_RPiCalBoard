/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/

/**
 * @file KtEvent.h
 * @author the Rooftop team
 *
 * Defines a classes/templates for supporting .NET like event in C++
 * below classes/templates defined in this file:
 *  - KtEventT<T>: for event with arguments
 *  - KtEvent: for event without argument
 */

#ifndef RCL_KT_EVENT_H
#define RCL_KT_EVENT_H

#include "KtEventHandler.h"

namespace Keysight {
namespace ApiCoreLibraries {

/**
 * @brief The Rooftop Event class that enable a class or object to notify other classes or objects when something of interest occurs.
 * @tparam T Type of the event arguments
 */
template<typename T>
class KtEventT
{
    using EventHandlerCollection = std::list< typename std::shared_ptr<KtEventHandlerT<T> > >;

public:

    using FuncPtrType = void(*)(const T&);

    /**
     * @brief Construct a new KtEventT object
     */
    KtEventT() = default;

    /**
     * @brief Destroy the Kt Event T object
     * it is by design that Event is the owner of the memory of all the handlers assigned to it
     * so it is the duty of the destructor to erase that memory
     */
    ~KtEventT()
    {
        std::lock_guard<std::recursive_mutex> lock(mKtEventResources);
        mEventHandlers.clear();
    }

    /**
     * @brief operator (), this call actually raises the event. It does so by calling all event handlers.
     * @param args event argument value
     */
    void operator()(const T& args)
    {
        std::lock_guard<std::recursive_mutex> lock(mKtEventResources);
        for (auto& handle : mEventHandlers)
        {
            handle->OnEvent(args);
        }
    }

    /**
     * @brief Register a function to the event
     * @param pFunc The pointer to the function
     */
    void Add(FuncPtrType pFunc)
    {
        (*this) += KtEventHandlerBinder::Bind<T>(pFunc);
    }

    void Add(std::function<void(const T &)> pFunc, int)
    {
        (*this) += KtEventHandlerBinder::Bind<T>(pFunc, 1);
    }

    void PyAdd(std::function<void(const T &)> pFunc, void * pyHandler)
    {
        (*this) += KtEventHandlerBinder::Bind<T>(pFunc, pyHandler, 0);
    }

    void PyRemove(std::function<void(const T &)> pFunc, void * pyHandler)
    {
        (*this) -= KtEventHandlerBinder::Bind<T>(pFunc, pyHandler, 0);
    }

    /**
     * @brief UnRegister the function pointer from the event
     * @param pFunc pFunc The pointer to the function
     */
    void Remove(FuncPtrType pFunc)
    {
        (*this) -= KtEventHandlerBinder::Bind<T>(pFunc);
    }

    /**
     * @brief Register a class member function to the event
     *
     * @tparam C : the type the event handling class
     * @tparam (C::*)(const T&) : the type of the class member function
     * @param pFunc : the pointer to the class member function
     * @param objPtr : the pointer to the instance of the event handler class
     * @example: To register member function 'void OnEvent(const EventArgs& args)' of class 'MyEventHandler'
     *      to the event, call event.Add(&MyEventHandler::OnEvent, &instanceOfMyEventHandler)
     */
    template<typename C, typename MemberFuncType = void (C::*)(const T&)>
    void Add(MemberFuncType pFunc, C* const objPtr)
    {
        (*this) += KtEventHandlerBinder::Bind<T>(pFunc, objPtr);
    }

    /**
     * @brief UnRegister a class member function to the event
     *
     * @tparam C : the type the event handling class
     * @tparam (C::*)(const T&) : the type of the class member function
     * @param pFunc : the pointer to the class member function
     * @param objPtr : the pointer to the instance of the event handler class
     * @example: To register member function 'void OnEvent(const EventArgs& args)' of class 'MyEventHandler'
     *      to the event, call event.Remove(&MyEventHandler::OnEvent, &instanceOfMyEventHandler)
     */
    template<typename C, typename MemberFuncType = void (C::*)(const T&)>
    void Remove(MemberFuncType pFunc, C* const objPtr)
    {
        (*this) -= KtEventHandlerBinder::Bind<T>(pFunc, objPtr);
    }

    /**
     * @brief operator += to add event handler to the event
     * @param pHandlerToAdd a event handler derived from type KtEventHandlerT<T>
     *  The KtEventHandlerT<T> can be created from the KtEventHandlerBinder::Bind method
     * @return KtEventT&
     */
    KtEventT& operator += (const std::shared_ptr<KtEventHandlerT<T>>& pHandlerToAdd)
    {
        std::lock_guard<std::recursive_mutex> lock(mKtEventResources);
        if (pHandlerToAdd)
        {
            mEventHandlers.push_back(pHandlerToAdd);
        }
        return *this;
    }

    /**
     * @brief operator -= to remove event handler to the event
     * @param pHandlerToAdd a event handler derived from type KtEventHandlerT<T>
     *  The KtEventHandlerT<T> can be created from the KtEventHandlerBinder::Bind method
     * @return KtEventT&
     */
    KtEventT& operator -= (const std::shared_ptr<KtEventHandlerT<T>>& pHandlerToRemove)
    {
        std::lock_guard<std::recursive_mutex> lock(mKtEventResources);
        if (!pHandlerToRemove)
        {
            return *this;
        }

        for (auto iter = mEventHandlers.begin(); iter != mEventHandlers.end(); ++iter)
        {
            if (pHandlerToRemove == *iter || IsSameHandler(*pHandlerToRemove, *(*iter)))
            {
                EraseHandler(iter);
                break;
            }
        }
        return *this;
    }

private:
    /**
     * @brief Check if two event handler are same
     *
     * @param p1 reference to event handler 1
     * @param p2 reference to event handler 2
     * @return true if the two event handlers are same, otherwise false
     */
    bool IsSameHandler(const KtEventHandlerT<T>& p1, const KtEventHandlerT<T>& p2)
    {
        if (p1.IsOwn()) return p1.IsSame(p2);
        else return false;
    }

    /**
     * @brief Removes specified event handler from the container
     *
     * @param iter iterator to the event handler
     */

    void EraseHandler(typename EventHandlerCollection::iterator iter)
    {
        mEventHandlers.erase(iter);
    }

    EventHandlerCollection mEventHandlers = {};
    std::recursive_mutex mKtEventResources = {};
};



/**
 * @brief The Rooftop Event class for no argument event that enable a class or object to notify other classes or objects when something of interest occurs.
 */
class KtEvent
{
    using EventHandler = std::shared_ptr<KtEventHandler>;
    using EventHandlerCollection = std::list<EventHandler>;

public:
    using FuncPtrType = void(*)();

    KtEvent() = default;

    /**
    * it is by design that Event is the owner of the memory of all the handlers assigned to it
    * so it is the duty of the destructor to erase that memory
    */
    ~KtEvent()
    {
        std::lock_guard<std::recursive_mutex> lock(mKtEventResources);
        mEventHandlers.clear();
    }

    /**
     * @brief operator(),  this call actually raises the event. It does so by calling all event handlers.
     */
    void operator()()
    {
        std::lock_guard<std::recursive_mutex> lock(mKtEventResources);
        for (auto& handle : mEventHandlers)
        {
            handle->OnEvent();
        }
    }

    /**
     * @brief Register a function to the event
     * @param pFunc The pointer to the function
     */
    void Add(FuncPtrType pFunc)
    {
        (*this) += KtEventHandlerBinder::Bind(pFunc);
    }

    // No way to distinguish CppStaticFunc from StdFunc for lambda without capture,
    // So, added an extra parameter to identify.
    void Add(std::function<void()> pFunc, int)
    {
        (*this) += KtEventHandlerBinder::Bind(pFunc, 1);
    }

    void PyAdd(std::function<void()> pFunc, void * pyHandler)
    {
        (*this) += KtEventHandlerBinder::Bind(pFunc, pyHandler, 0);
    }

    void PyRemove(std::function<void()> pFunc, void * pyHandler)
    {
        (*this) -= KtEventHandlerBinder::Bind(pFunc, pyHandler, 0);
    }

    /**
     * @brief UnRegister the function pointer from the event
     * @param pFunc pFunc The pointer to the function
    */
    void Remove(FuncPtrType pFunc)
    {
        (*this) -= KtEventHandlerBinder::Bind(pFunc);
    }

    void Remove(std::function<void()> pFunc, int)
    {
        (*this) -= KtEventHandlerBinder::Bind(pFunc, 1);
    }

    /**
     * @brief Register a class member function to the event
     *
     * @tparam C : the type the event handling class
     * @tparam (C::*)(const T&) : the type of the class member function
     * @param pFunc : the pointer to the class member function
     * @param objPtr : the pointer to the instance of the event handler class
     * @example: To register member function 'void OnEvent()' of class 'MyEventHandler'
     *      to the event, call event.Add(&MyEventHandler::OnEvent, &instanceOfMyEventHandler)
     */
    template<typename C, typename MemberFuncType = void (C::*)()>
    void Add(MemberFuncType pFunc, C* const objPtr)
    {
        (*this) += KtEventHandlerBinder::Bind(pFunc, objPtr);
    }

    /**
     * @brief Register a class member function to the event
     *
     * @tparam C : the type the event handling class
     * @tparam (C::*)(const T&) : the type of the class member function
     * @param pFunc : the pointer to the class member function
     * @param objPtr : the pointer to the instance of the event handler class
     * @example: To register member function 'void OnEvent()' of class 'MyEventHandler'
     *      to the event, call event.Remove(&MyEventHandler::OnEvent, &instanceOfMyEventHandler)
     */
    template<typename C, typename MemberFuncType = void (C::*)()>
    void Remove(MemberFuncType pFunc, C* const objPtr)
    {
        (*this) -= KtEventHandlerBinder::Bind(pFunc, objPtr);
    }

    /**
     * @brief operator += to add event handler to the event
     * @param pHandlerToAdd a event handler derived from type KtEventHandler
     *  The KtEventHandler can be created from the KtEventHandlerBinder::Bind method
     * @return KtEvent&
     */
    KtEvent& operator += (const std::shared_ptr<KtEventHandler>& pHandlerToAdd)
    {
        std::lock_guard<std::recursive_mutex> lock(mKtEventResources);

        if (pHandlerToAdd)
        {
            mEventHandlers.push_back(pHandlerToAdd);
        }
        return *this;
    }

    /**
     * @brief operator -= to remove event handler to the event
     * @param pHandlerToAdd a event handler derived from type KtEventHandler
     *  The KtEventHandler can be created from the KtEventHandlerBinder::Bind method
     * @return KtEvent&
     */
    KtEvent& operator -= (const std::shared_ptr<KtEventHandler>& pHandlerToRemove)
    {
        std::lock_guard<std::recursive_mutex> lock(mKtEventResources);
        if (!pHandlerToRemove)
        {
            return *this;
        }

        for (auto iter = mEventHandlers.begin(); iter != mEventHandlers.end(); ++iter)
        {
            if (pHandlerToRemove == *iter || IsSameHandler(*pHandlerToRemove, *(*iter)))
            {
                EraseHandler(iter);
                break;
            }
        }
        return *this;
    }

private:
    bool IsSameHandler(const KtEventHandler& p1, const KtEventHandler& p2)
    {
        if (p1.IsOwn()) return p1.IsSame(p2);
        else return false;
    }

    void EraseHandler(EventHandlerCollection::iterator iter)
    {
        mEventHandlers.erase(iter);
    }

    EventHandlerCollection mEventHandlers = {};
    std::recursive_mutex mKtEventResources = {};
};

}}
#endif // RCL_KT_EVENT_H