/******************************************************
 *       Copyright Keysight Technologies 2018-2019
 ******************************************************/
#ifndef RCL_IVI_WAVEFORM_REMOTE_MARSHALER_H
#define RCL_IVI_WAVEFORM_REMOTE_MARSHALER_H

 /**
  * @file IviWaveformRemoteMarshaler.h
  * @author the Rooftop team
  * defines the remote marshaler class for IviWaveform
  */

#include "ICustomMarshaler.h"
#include "AnyVectorRemoteMarshaler.h"
#include "BasicMarshaler.h"
#include "CommonArrayRemoteMarshaler.h"
#include "TimePointMarshaler.h"
#include "ChronoDurationMarshaler.h"
#include "IviWaveform.h"

namespace Keysight::ApiCoreLibraries{

template <class T>
class IviWaveformRemoteMarshaler : public Keysight::ApiCoreLibraries::ICustomMarshaler<Keysight::ApiCoreLibraries::IviWaveform<T>>
{
public:
    void BytesToCpp(MarshalBuffer& marshalBuffer, Keysight::ApiCoreLibraries::IviWaveform<T>& result) override
    {
        std::vector<T> dataArray;
        std::int64_t capacity = 0;
        std::int64_t firstValidPoint = 0;
        Duration intervalPerPoint;
        double offset = 0;
        double scale = 1;
        Duration startTime;
        TimePoint triggerTime;
        std::int64_t validPointCount = 0;

        mCommonArrayMarshaler.BytesToCpp(marshalBuffer, dataArray);
        mInt64Marshaler.BytesToCpp(marshalBuffer, capacity);
        mInt64Marshaler.BytesToCpp(marshalBuffer, firstValidPoint);
        mChronoDurationMarshaler.BytesToCpp(marshalBuffer, intervalPerPoint);
        if(!mIsFloatingData)
        {
            mDoubleMarshaler.BytesToCpp(marshalBuffer, offset);
            mDoubleMarshaler.BytesToCpp(marshalBuffer, scale);
        }        
        mChronoDurationMarshaler.BytesToCpp(marshalBuffer, startTime);
        mTimePointMarshaler.BytesToCpp(marshalBuffer, triggerTime);
        mInt64Marshaler.BytesToCpp(marshalBuffer, validPointCount);
        
        // - Capacity need to be set first
        result.SetCapacity(capacity);
        result.Configure(startTime, intervalPerPoint, validPointCount, triggerTime);
        result.SetFirstValidPoint(firstValidPoint);
        this->SetData(result, dataArray);
        if(!mIsFloatingData)
        {
            result.SetOffset(offset);
            result.SetScale(scale);
        }
    }

    void CppToBytes(const Keysight::ApiCoreLibraries::IviWaveform<T>& input, MarshalBuffer& marshalBuffer) override
    {
        this->DataCppToBytes(input, marshalBuffer);
        mInt64Marshaler.CppToBytes(input.GetCapacity(), marshalBuffer);
        mInt64Marshaler.CppToBytes(input.GetFirstValidPoint(), marshalBuffer);
        mChronoDurationMarshaler.CppToBytes(input.GetIntervalPerPoint(), marshalBuffer);
        if(!mIsFloatingData)
        {
            mDoubleMarshaler.CppToBytes(input.GetOffset(), marshalBuffer);
            mDoubleMarshaler.CppToBytes(input.GetScale(), marshalBuffer);
        }        
        mChronoDurationMarshaler.CppToBytes(input.GetStartTime(), marshalBuffer);
        mTimePointMarshaler.CppToBytes(input.GetTriggerTime(), marshalBuffer);        
        mInt64Marshaler.CppToBytes(input.GetValidPointCount(), marshalBuffer);
    }

    std::int32_t GetBufferSize() const
    {
        throw std::runtime_error("Should not be called here!");
    }

    std::int32_t GetBufferSizeForRPC(const Keysight::ApiCoreLibraries::IviWaveform<T> &waveform) const override
    {
        std::int32_t size = 2 * mChronoDurationMarshaler.GetBufferSize();     // duration and IntervalPerPoint
        size += mTimePointMarshaler.GetBufferSize();                             // IntervalPerPoint        
        size += 3 * mInt64Marshaler.GetBufferSize();                             // validPointCount, capacity and FirstValidPoint
        size += this->GetDataSize(waveform);                                     // data
        if(!mIsFloatingData)
        {
            size += 2 * mDoubleMarshaler.GetBufferSize();                        // scale and offset
        }
        return size;
    }

private:
    Keysight::ApiCoreLibraries::DoubleMarshaler mDoubleMarshaler;
    Keysight::ApiCoreLibraries::Int64Marshaler mInt64Marshaler;
    Keysight::ApiCoreLibraries::AnyVectorRemoteMarshaler<T> mGslSpanMarshaler;
    Keysight::ApiCoreLibraries::ChronoDurationMarshaler mChronoDurationMarshaler;
    Keysight::ApiCoreLibraries::TimePointMarshaler mTimePointMarshaler;
    Keysight::ApiCoreLibraries::CommonArrayRemoteMarshaler<T, Keysight::ApiCoreLibraries::BasicMarshaler<T>> mCommonArrayMarshaler;
    bool mIsFloatingData = std::is_floating_point<T>::value;

private:
    // Check if the Waveform data is using memory view (using data span to refer the pre allocated memory)
    bool IsUsingMemoryView(const Keysight::ApiCoreLibraries::IviWaveform<T>& input) const
    {
        return input.GetDataSpan().getMemory() && input.GetDataSpan().getAllocator() ? true : false;
    }

    void DataCppToBytes(const Keysight::ApiCoreLibraries::IviWaveform<T>& input, MarshalBuffer& marshalBuffer)
    {
        if (this->IsUsingMemoryView(input))
        {
            auto dataSpan = input.GetDataSpan();
            std::vector<T> waveform(dataSpan.getSpan().begin(), dataSpan.getSpan().end());
            mCommonArrayMarshaler.CppToBytes(waveform, marshalBuffer);
        }
        else
        {
            // it is being called by c++
            mCommonArrayMarshaler.CppToBytes(input.GetData(), marshalBuffer);
        }
    }

    void SetData(Keysight::ApiCoreLibraries::IviWaveform<T>& result, const std::vector<T>& dataArray)
    {
        auto dataSpan = result.GetDataSpan();
        if(this->IsUsingMemoryView(result))
        {
            dataSpan = dataArray;
            result.SetDataSpan(dataSpan);
        }
        else
        {
            // it is being called by c++
            result.SetData(dataArray);
        }
    }

    std::int32_t GetDataSize(const Keysight::ApiCoreLibraries::IviWaveform<T> &waveform) const
    {
        if (this->IsUsingMemoryView(waveform))
        {
            return mGslSpanMarshaler.GetBufferSizeForRPC(waveform.GetDataSpan());
        }
        else
        {
            return mCommonArrayMarshaler.GetBufferSizeForRPC(waveform.GetData());
        }
    }
};

}
#endif // RCL_IVI_WAVEFORM_REMOTE_MARSHALER_H