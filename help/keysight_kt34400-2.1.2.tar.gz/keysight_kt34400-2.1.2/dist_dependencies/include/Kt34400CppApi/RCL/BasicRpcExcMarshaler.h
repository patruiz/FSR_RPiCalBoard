/******************************************************
 *       Copyright Keysight Technologies 2018-2019
 ******************************************************/
#ifndef RCL_BASIC_RPC_EXC_MARSHALER_H
#define RCL_BASIC_RPC_EXC_MARSHALER_H

/**
 * @file BasicRpcExcMarshaler.h
 * @author the Rooftop team
 * this file defines the template class for marshaler of the types following some rules:
 * 1. the type is derived from std::exception or sub-class of std::exception
 * 2. the type contains one constructor which has only one parameter with std::string type
 * 3. the what() method contains all the info which can be used to de-serialize
 */

#include "ICustomRpcExcMarshaler.h"
#include <memory>
#include <string>
#include <type_traits>

namespace Keysight {
namespace ApiCoreLibraries {

/**
 *@brief template marshaler class for std::exception types which has one std::string or char * parameter constructor
 *       if no marshaler class is specified in Exception element of CppCustomizedExceptionList in property file,
 *       this class will be automatically used.
*/
template <class T>
class BasicRpcExcMarshaler : public ICustomRpcExcMarshaler<T>
{
public:
    BasicRpcExcMarshaler()
    {
        // runtime check to restrict T to std::exception derived types
        static_assert(std::is_base_of<std::exception, T>::value, "BasicRpcExcMarshaler<T> can only support std::exception derived types!");
    }

    T stringToObj(const std::string & data) override
    {
        return T{ data.c_str() };
    }

    std::string objToString(const T & obj) const override
    {
        return std::string(obj.what() ? obj.what() : "");
    }

};

}}
#endif // RCL_BASIC_RPC_EXC_MARSHALER_H