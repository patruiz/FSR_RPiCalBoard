/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#include "ImplClassBase.h"
#include <sstream>
#include <typeinfo>

using namespace Keysight::ApiCoreLibraries;

std::string ImplClassBase::ToString() const 
{
    auto name = std::string(typeid(*this).name());
    //Remove namespace
    name = name.substr(name.find_last_of("::") + 1);
    //Remove the ending 'Impl'
    if (name.rfind("Impl") == name.size() - 4)
    {
        name = name.substr(0, name.size() - 4);
    }
    return name + "{...}";
}

std::ostream& operator<<(std::ostream& os, const ImplClassBase& value)
{
    os << value.ToString();
    return os;
}