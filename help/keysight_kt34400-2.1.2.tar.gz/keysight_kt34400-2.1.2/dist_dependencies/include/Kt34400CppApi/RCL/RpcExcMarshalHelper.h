/******************************************************
 *       Copyright Keysight Technologies 2018-2019
 ******************************************************/
#ifndef RCL_RPC_EXC_MARSHAL_HELPER_H
#define RCL_RPC_EXC_MARSHAL_HELPER_H

/**
 * @file RpcExcMarshalHelper.h
 * @author the Rooftop team
 * this file defines some marshal helper methods for remote exceptions
 */
#include "ICustomRpcExcMarshaler.h"
#include <exception>
#include <string>
#include <vector>
#ifdef __GNUC__
#include <cxxabi.h>
#endif

namespace Keysight
{
namespace ApiCoreLibraries
{

    const std::string PREFIX_CUST_EXCEPTION = "<CustException>";
    const std::string PREFIX_STD_EXCEPTION = "<StdException>";
    const std::string PREFIX_UNKNOWN_EXCEPTION = "<UnknownException>";
    class RpcExcMarshalHelper
    {
    public:
        template <typename T>
        static std::string marshalException(const T& ex, const ICustomRpcExcMarshaler<T>& marshaler)
        {
            std::string clsName = getFullQualifiedClassName(ex);
            auto data = marshaler.objToString(ex);
            auto ret = PREFIX_CUST_EXCEPTION + "#" + clsName + "#" + data;
            return ret;
        }

        static std::string marshalException(const std::exception& ex)
        {
            std::string clsName = getFullQualifiedClassName(ex);
            std::string data = ex.what();
            auto ret = PREFIX_STD_EXCEPTION + "#" + clsName + "#" + data;
            return ret;
        }

        static std::string marshalException(const std::string& data)
        {
            std::string clsName = "UnknownClass";
            auto ret = PREFIX_UNKNOWN_EXCEPTION + "#" + clsName + "#" + data;
            return ret;
        }

    private:
        static std::string getFullQualifiedClassName(const std::exception& ex)
        {
            std::string clsName = typeid(ex).name();
            auto sepIndex = clsName.find(' ');
            if (sepIndex != std::string::npos)
            {
                clsName = clsName.substr(sepIndex + 1);
            }
            return demangleName(clsName);
        }

        static std::string demangleName(const std::string& mangedName)
        {
#ifdef __GNUC__
            std::size_t sz = 256;
            char* buffer = static_cast<char*>(std::malloc(sz));
            int status;
            std::string name = mangedName;
            char* realname = abi::__cxa_demangle(mangedName.c_str(), buffer, &sz, &status);
            if (status == 0)
            {
                name = std::string(realname);
            }
            std::free(buffer);
            return name;
#else
            return mangedName;
#endif
        }
    };

} // namespace ApiCoreLibraries
} // namespace Keysight
#endif // RCL_RPC_EXC_MARSHAL_HELPER_H