/******************************************************
 *       Copyright Keysight Technologies 2018-2019
 ******************************************************/
#ifndef RCL_IVI_ERROR_QUERY_RESULT_REMOTE_MARSHALER_H
#define RCL_IVI_ERROR_QUERY_RESULT_REMOTE_MARSHALER_H

 /**
  * @file IviErrorQueryResultMarshaler.h
  * @author the Rooftop team
  * defines the rpc marshaler class for ErrorQueryResult
  */
#include "CommonExport.h"
#include "ICustomMarshaler.h"
#include "IviErrorQueryResult.h"
#include "BasicMarshaler.h"
#include "StringRemoteMarshaler.h"
#include <string>

namespace Keysight {
namespace ApiCoreLibraries {

class KTROOFTOP_COMMON_API IviErrorQueryResultRemoteMarshaler : public ICustomMarshaler<IviErrorQueryResult>
{
public:
	void BytesToCpp(MarshalBuffer& marshalBuffer, IviErrorQueryResult& result) override;
	void CppToBytes(const IviErrorQueryResult& input, MarshalBuffer& marshalBuffer) override;
	std::int32_t GetBufferSize() const
	{
		throw std::runtime_error("Should not be called here!");
	}
	std::int32_t GetBufferSizeForRPC(const IviErrorQueryResult& input) const override;
	
private:
	BasicMarshaler<int32_t> mInt32Marshaler;
	StringRemoteMarshaler mStringRemoteMarshaler;
};

}
}

#endif // RCL_IVI_ERROR_QUERY_RESULT_REMOTE_MARSHALER_H