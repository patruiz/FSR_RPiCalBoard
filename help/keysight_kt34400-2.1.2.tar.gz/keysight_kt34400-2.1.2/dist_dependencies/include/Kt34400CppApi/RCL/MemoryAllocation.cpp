/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#include "MemoryAllocation.h"
#include "AppDomain.h"
#include <stdexcept>
#include <system_error>
#include <string>
#include <sstream>

using namespace Keysight::ApiCoreLibraries;
using namespace Keysight::ModularInstruments;
using namespace std;

std::map<int, CSharpAllocationCallback_t> MemoryAllocation::mAllocateHelper{};

void MemoryAllocation::InstallAllocationHelper(int appDomainId, CSharpAllocationCallback_t helper)
{
    if (helper == nullptr)
    {
        throw invalid_argument("null value for CSharpAllocationCallback_t in InstallAllocationHelper is invalid");        
    }
    mAllocateHelper[appDomainId] = helper;
}

void MemoryAllocation::UninstallAllocationHelper(int appDomainId)
{
    mAllocateHelper.erase(appDomainId);
}

int MemoryAllocation::ReportCallbackStatus(std::string& details)
{
    std::ostringstream outStr;
    auto size = static_cast<int>(mAllocateHelper.size());
    outStr << "AllocationCallback ( " << size << " [";
    for(auto& it : mAllocateHelper) 
    {
        outStr << " " << it.first;
    }
    outStr << "] )" << std::endl;
    details = outStr.str();

    return size;
}

AnyVector<std::uint8_t> MemoryAllocation::CreateAnyVectorByte()
{
    if(mAllocateHelper.find(APPDOMAIN_ID) == mAllocateHelper.end())
    {
        throw runtime_error("In MemoryAllocation::CreateAnyVectorByte, mAllocateHelper has no key " + std::to_string(APPDOMAIN_ID));
    }    
    return AnyVector<std::uint8_t>(gsl::span<std::uint8_t>(), mAllocateHelper[APPDOMAIN_ID]);    
}