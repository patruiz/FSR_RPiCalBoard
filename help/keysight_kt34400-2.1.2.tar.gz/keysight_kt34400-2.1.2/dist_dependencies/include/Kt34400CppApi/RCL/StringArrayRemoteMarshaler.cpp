#include "StringArrayRemoteMarshaler.h"
using namespace Keysight::ApiCoreLibraries;

void StringArrayRemoteMarshaler::BytesToCpp(MarshalBuffer& marshalBuffer, std::vector<std::string>& result)
{
	result.clear();
	std::int32_t size = 0;
	mInt32Marshaler.BytesToCpp(marshalBuffer, size);
	for (int index = 0; index < size; index++)
	{
		std::string ele;
		mElementRemoteMarshaler.BytesToCpp(marshalBuffer, ele);
		result.push_back(ele);
	}
}

void StringArrayRemoteMarshaler::CppToBytes(const std::vector<std::string>& input, MarshalBuffer& marshalBuffer)
{
	mInt32Marshaler.CppToBytes(static_cast<std::int32_t>(input.size()), marshalBuffer);
	for (auto& ele : input)
	{
		mElementRemoteMarshaler.CppToBytes(ele, marshalBuffer);
	}
}

std::int32_t StringArrayRemoteMarshaler::GetBufferSize() const
{
	throw std::runtime_error("Should not be called here!");
}

std::int32_t StringArrayRemoteMarshaler::GetBufferSizeForRPC(const std::vector<std::string>& input) const
{
	if (input.size() > 0)
	{
		return sizeof(std::int32_t) + static_cast<std::int32_t>(input.size())*(mElementRemoteMarshaler.GetBufferSizeForRPC(input[0]));
	}
	else
	{
		return sizeof(std::int32_t);
	}
}
