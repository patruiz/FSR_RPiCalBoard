/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#ifndef RCL_ENUM_HELPER_H
#define RCL_ENUM_HELPER_H

/**
 * @file EnumHelper.h
 * @author the Rooftop team
 * defines some help functions for streamlizing Rooftop defined enumerations
 */

#include <map>
#include <string>

namespace Keysight {
namespace ApiCoreLibraries {

class EnumHelper
{
public:
    /**
     * @brief the internal implementation of ostream output operator for driver defined enumeration
     * If the enum value is valid, output the member name
     * If the enum value is invalid, output _Undefined_(value)
     * If the enum is considered as a bitmap type(all the members are power of 2), then the combined member string can be formated
     * @param os : input ostream
     * @param v : enumeration value
     * @param validMembers : a <enum, string> map for all the defined members
     * @return std::ostream& the output stream (os)
     */
    static std::ostream& EnumStreamOut(std::ostream & os, std::int32_t v, const std::map<std::int32_t, std::string>& validMembers);

};

}}

#endif // RCL_ENUM_HELPER_H