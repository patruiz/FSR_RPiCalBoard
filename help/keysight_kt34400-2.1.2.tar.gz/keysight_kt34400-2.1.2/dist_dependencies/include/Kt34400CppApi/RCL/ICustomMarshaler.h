/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#ifndef RCL_I_CUSTOM_MARSHALER_H
#define RCL_I_CUSTOM_MARSHALER_H

/**
 * @file ICustomMarshaler.h
 * @author the Rooftop team
 *
 * defines the base class for all C++ marshalers
 */

#include "MarshalBuffer.h"
#include <memory>

using MarshalBuffer = Keysight::ApiCoreLibraries::Marshal::MarshalBuffer;

namespace Keysight {
namespace ApiCoreLibraries {

/**
 *@brief template pure class to define the interface that the C++ marshaler class should implement
 *  All the C++ marshal class should inherit from this class
 *@tparam T the type of the data to be marshaled
*/
template <class T>
class ICustomMarshaler
{
public:
    /**
     * @brief Takes a marshal buffer and extracts a C++ type. It advances the count in the buffer to the next location
     *  @param marshalBuffer the marshal buffer that holds the buffer
     *  @param result the output C++ object deserialized from the buffer
    */
    virtual void BytesToCpp(MarshalBuffer& marshalBuffer, T& result) = 0;

	void StrToCpp(const std::string& strBuffer, T& result)
	{
		MarshalBuffer buffer(strBuffer);
		this->BytesToCpp(buffer, result);
	}

    /**
     * @brief Takes a C++ type and writes it into the marshal buffer, advancing the count in the marshal buffer to the next available location.
     * @param input the input C++ object
     * @param marshalBuffer the marshal buffer that holds the buffer
    */
    virtual void CppToBytes(const T& input, MarshalBuffer& marshalBuffer) = 0;

	void CppToStr(const T& input, std::string& strBuffer)
	{
		std::int32_t size = this->GetBufferSizeForRPC(input);
		MarshalBuffer buffer(size);
		this->CppToBytes(input, buffer);
		strBuffer = buffer.ToString();
	}

    /**
     * @brief Get the buffer size need required for marshaling T
    */
    virtual std::int32_t GetBufferSize() const = 0;

	virtual std::int32_t GetBufferSizeForRPC(const T& object) const
	{
		return GetBufferSize();
	}
};


}}

#endif // RCL_I_CUSTOM_MARSHALER_H