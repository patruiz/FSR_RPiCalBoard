/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#ifndef RCL_IVI_ERROR_QUERY_RESULT_H
#define RCL_IVI_ERROR_QUERY_RESULT_H

/**
 * @file IviErrorQueryResult.h
 * @author the Rooftop team
 *  define class IviErrorQueryResult
 */

#include <string>
#include <ostream>

namespace Keysight{
namespace ApiCoreLibraries{

/**
*@brief Result of error query
* This is the equivalent C++ class for the C# Ivi.SelfTestResult
*
*/
class IviErrorQueryResult
{
public:
    /**
     * @brief default constructor
     *
     */
    IviErrorQueryResult() = default;

    /**
     * @brief Construct a new Ivi Error Query Result object
     *
     * @param code error code
     * @param message error message
     */
    IviErrorQueryResult(std::int32_t code, const std::string& message)
        : mCode(code)
        , mMessage(message)
    {
    }

    /**
    *@brief Get the Instrument error code.
    *
    *@return the Instrument error code.
    */
    std::int32_t GetCode() const
    {
        return mCode;
    }
    /**
    *@brief Get the Instrument error message.
    *
    *@return the Instrument error message.
    */
    std::string GetMessage() const
    {
        return mMessage;
    }

private:
    int32_t mCode = 0;
    std::string mMessage = "";

    friend std::ostream& operator<<(std::ostream& os, const IviErrorQueryResult& value);
};

/**
 * @brief overloading the output stream operator << for IviErrorQueryResult
 *
 * @param os output stream object
 * @param value the IviErrorQueryResult value
 * @return std::ostream& the stream object
 */
inline std::ostream& operator<<(std::ostream& os, const IviErrorQueryResult& value)
{
    os << "ErrorQueryResult{Code:" << value.mCode << ", Message:" << value.mMessage << "}";
    return os;
}


}}

#endif // RCL_IVI_ERROR_QUERY_RESULT_H