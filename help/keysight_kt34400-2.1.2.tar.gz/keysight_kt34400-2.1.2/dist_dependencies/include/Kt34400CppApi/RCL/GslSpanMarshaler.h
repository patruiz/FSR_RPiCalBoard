/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#ifndef RCL_GSL_SPAN_MARSHALER_H
#define RCL_GSL_SPAN_MARSHALER_H

/**
 * @file GslSpanMarshaler.h
 * @author the Rooftop team
 * defines the marshaler class for gsl::span<T>
 */

#include "ICustomMarshaler.h"
#include "BasicMarshaler.h"
#include <memory>
#include <chrono>
#include <exception>
#include <string>
#include <gsl/gsl>

namespace Keysight {
namespace ApiCoreLibraries {

template <class T>
class GslSpanMarshaler : public ICustomMarshaler<gsl::span<T>>
{
public:
    void BytesToCpp(MarshalBuffer& marshalBuffer, gsl::span<T>& result) override
    {
        std::int64_t pBuffer, length;
        mInt64Marshaler.BytesToCpp(marshalBuffer, pBuffer);
        mInt64Marshaler.BytesToCpp(marshalBuffer, length);
        result = typename gsl::span<T>((T*)pBuffer, static_cast<typename gsl::span<T>::index_type>(length));
    }

    void CppToBytes(const gsl::span<T>& input, MarshalBuffer& marshalBuffer) override
    {
        //throw std::runtime_error("GslSpanMarshaler<T>.CppToBytes should not be called. The value has been populated to the pinned memory.")
        //do nothing
        mInt64Marshaler.CppToBytes(reinterpret_cast<std::int64_t>(input.data()), marshalBuffer);
        mInt64Marshaler.CppToBytes(static_cast<std::int64_t>(input.length()), marshalBuffer);
    }

    std::int32_t GetBufferSize() const override
    {
        return 2 * mInt64Marshaler.GetBufferSize();
    }

private:
    BasicMarshaler<std::int64_t> mInt64Marshaler;
};

}}
#endif // RCL_GSL_SPAN_MARSHALER_H