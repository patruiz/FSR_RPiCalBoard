#ifndef RCL_IVI_WAVEFORM_H
#define RCL_IVI_WAVEFORM_H

/** 
 * Copyright Keysight Technologies 2020-2021
 *
 * @file IviWaveform.h
 * @author NGC Team
 *  The default implementation of the C++ waveform class. 
 *  Most of the methods follow the IVI specification but not all the methods in the Spec are implemented.
 
 */

#include "MeasurementData.h"


namespace Keysight {
namespace ApiCoreLibraries {

/**
 * @brief A template class to represent the Ivi.Waveform<T>
 *
*/

template <typename T>
class IviWaveform:public MeasurementData<T>
{  
    Duration mIntervalPerPoint{ Duration::zero() };
    Duration mStartTime{ Duration::zero() };

// Constructors
public:
    // Default constructor is needed for marshalers
    IviWaveform() = default;

    IviWaveform(const IviWaveform& other)
    {
        *this = other;
    }
    
    IviWaveform& operator=(const IviWaveform& other)
    {
        if (this != &other)
        {
            MeasurementData<T>::operator=(other);
            mIntervalPerPoint = other.mIntervalPerPoint;
            mStartTime = other.mStartTime;
        }
        return *this;
    }
    
    /**
     * @brief Initializes a new instance of the IviWaveform.  This constructor initializes an empty waveform. 
     * @param startTime The time of the first data point in the waveform relative to the trigger time.
     * @param intervalPerPoint The amount of time between data points in the waveform (required).
     * @param triggerTime The absolute time of the trigger in the waveform.
     * @return New instance of an empty waveform
     */
    IviWaveform(const Duration& startTime, const Duration& intervalPerPoint, const TimePoint& triggerTime)
        :IviWaveform(startTime, intervalPerPoint, triggerTime, 0)
    {
    }

    /**
     * @brief Initializes a new instance of the IviWaveform.  This constructor initializes an empty waveform. 
     * @param startTime The time of the first data point in the waveform relative to the trigger time.
     * @param intervalPerPoint The amount of time between data points in the waveform (required).     
     * @return New instance of an empty waveform
     */
    IviWaveform(const Duration& startTime, const Duration& intervalPerPoint)
        :IviWaveform(startTime, intervalPerPoint, TimePoint{})
    {
    }

    /**
     * @brief Initializes a new instance of the IviWaveform.  This constructor initializes an empty waveform. 
     * @param intervalPerPoint The amount of time between data points in the waveform (required).
     * @return New instance of an empty waveform
     */
    IviWaveform(const Duration& intervalPerPoint)
        :IviWaveform(Duration::zero(), intervalPerPoint, TimePoint{})
    {
    }

    /**
     * @brief Initializes a new instance of the IviWaveform.  This constructor initializes an empty waveform. 
     * @param startTime The time of the first data point in the waveform relative to the trigger time.
     * @param intervalPerPoint The amount of time between data points in the waveform (required).
     * @param triggerTime The absolute time of the trigger in the waveform.
     * @param capacity The capacity of the of the waveform data array.
     * @return New instance of an empty waveform
     */
    IviWaveform(const Duration& startTime, const Duration& intervalPerPoint, const TimePoint& triggerTime, std::int64_t capacity)
    {
       this->Configure(startTime, intervalPerPoint, triggerTime, capacity);
    }

    /**
     * @brief Initializes a new instance of the IviWaveform.  This constructor initializes an empty waveform. 
     * @param startTime The time of the first data point in the waveform relative to the trigger time.
     * @param intervalPerPoint The amount of time between data points in the waveform (required).
     * @param capacity The capacity of the of the waveform data array.
     * @return New instance of an empty waveform
     */
    IviWaveform(const Duration& startTime, const Duration& intervalPerPoint, std::int64_t capacity)
        :IviWaveform(startTime, intervalPerPoint, TimePoint{}, capacity)
    {
    }

    /**
     * @brief Initializes a new instance of the IviWaveform.  This constructor initializes an empty waveform.     
     * @param intervalPerPoint The amount of time between data points in the waveform (required).
     * @param capacity The capacity of the of the waveform data array.
     * @return New instance of an empty waveform
     */
    IviWaveform(const Duration& intervalPerPoint, std::int64_t capacity)
        :IviWaveform(Duration::zero(), intervalPerPoint, TimePoint{}, capacity)
    {
    }

// Configure Methods
public:
    /**
     * @brief The Configure method defines the time (implicit) axis and number of data points in the waveform.  Because of
        the interaction between these values, they are set as a group with this method or when the waveform is
        initially created.  If startTime is not specified, it defaults to Zero.  If triggerTime is not specified,
        it defaults to Not A Time.  If validPointCount is not specified, the number of elements in the waveform is not changed.
     * @param startTime The time of the first data point in the waveform relative to the trigger time.
     * @param intervalPerPoint The amount of time between data points in the waveform (required).
     * @param validPointCount The actual number of elements in the waveform.
     * @param triggerTime The time that this measurement was triggered.
     * @remarks The Configure method does not change any of the explicit data in the Waveform.  The capacity of the waveform does
        not change as a side effect of the Configure method.  If the validPointCount exceeds the data array size, an
        Insufficient Capacity exception is thrown.
     */
    void Configure(const Duration& startTime, const Duration& intervalPerPoint, std::int64_t validPointCount, const TimePoint& triggerTime)
    {
        ConfigureWithValidPointCount(startTime, intervalPerPoint, triggerTime, validPointCount);
    }

    /**
     * @brief The Configure method defines the time (implicit) axis and number of data points in the waveform.  Because of
        the interaction between these values, they are set as a group with this method or when the waveform is
        initially created.  If startTime is not specified, it defaults to Zero.  If triggerTime is not specified,
        it defaults to Not A Time.  If validPointCount is not specified, the number of elements in the waveform is not changed.
     * @param startTime The time of the first data point in the waveform relative to the trigger time.
     * @param intervalPerPoint The amount of time between data points in the waveform (required).
     * @param validPointCount The actual number of elements in the waveform.
     * @remarks The Configure method does not change any of the explicit data in the Waveform.  The capacity of the waveform does
        not change as a side effect of the Configure method.  If the validPointCount exceeds the data array size, an
        Insufficient Capacity exception is thrown.
     */
    void Configure(const Duration& startTime, const Duration& intervalPerPoint, std::int64_t validPointCount)
    {
        this->Configure(startTime, intervalPerPoint, validPointCount, TimePoint{});
    }

    /**
     * @brief The Configure method defines the time (implicit) axis and number of data points in the waveform.  Because of
        the interaction between these values, they are set as a group with this method or when the waveform is
        initially created.  If startTime is not specified, it defaults to Zero.  If triggerTime is not specified,
        it defaults to Not A Time.  If validPointCount is not specified, the number of elements in the waveform is not changed.
     * @param startTime The time of the first data point in the waveform relative to the trigger time.
     * @param intervalPerPoint The amount of time between data points in the waveform (required).
     * @remarks The Configure method does not change any of the explicit data in the Waveform.  The capacity of the waveform does
        not change as a side effect of the Configure method.  If the validPointCount exceeds the data array size, an
        Insufficient Capacity exception is thrown.
     */
    void Configure(const Duration& startTime, const Duration& intervalPerPoint)
    {
        this->Configure(startTime, intervalPerPoint, TimePoint{});
    }

    /**
     * @brief The Configure method defines the time (implicit) axis and number of data points in the waveform.  Because of
        the interaction between these values, they are set as a group with this method or when the waveform is
        initially created.  If startTime is not specified, it defaults to Zero.  If triggerTime is not specified,
        it defaults to Not A Time.  If validPointCount is not specified, the number of elements in the waveform is not changed.
     * @param intervalPerPoint The amount of time between data points in the waveform (required).
     * @param validPointCount The actual number of elements in the waveform.
     * @remarks The Configure method does not change any of the explicit data in the Waveform.  The capacity of the waveform does
        not change as a side effect of the Configure method.  If the validPointCount exceeds the data array size, an
        Insufficient Capacity exception is thrown.
     */
    void Configure(const Duration& intervalPerPoint, std::int64_t validPointCount)
    {
        this->Configure(Duration::zero(), intervalPerPoint, validPointCount, TimePoint{});
    }

    /**
     * @brief The Configure method defines the time (implicit) axis and number of data points in the waveform.  Because of
        the interaction between these values, they are set as a group with this method or when the waveform is
        initially created.  If startTime is not specified, it defaults to Zero.  If triggerTime is not specified,
        it defaults to Not A Time.  If validPointCount is not specified, the number of elements in the waveform is not changed.
     * @param intervalPerPoint The amount of time between data points in the waveform (required).
     * @remarks The Configure method does not change any of the explicit data in the Waveform.  The capacity of the waveform does
        not change as a side effect of the Configure method.  If the validPointCount exceeds the data array size, an
        Insufficient Capacity exception is thrown.
     */
    void Configure(const Duration& intervalPerPoint)
    {
        this->Configure(Duration::zero(), intervalPerPoint, TimePoint{});
    }

    /**
     * @brief The Configure method defines the time (implicit) axis and number of data points in the waveform.  Because of
        the interaction between these values, they are set as a group with this method or when the waveform is
        initially created.  If startTime is not specified, it defaults to Zero.  If triggerTime is not specified,
        it defaults to Not A Time.  If validPointCount is not specified, the number of elements in the waveform is not changed.
     * @param startTime The time of the first data point in the waveform relative to the trigger time.
     * @param intervalPerPoint The amount of time between data points in the waveform (required).
     * @param triggerTime The time that this measurement was triggered.
     * @remarks The Configure method does not change any of the explicit data in the Waveform.  The capacity of the waveform does
        not change as a side effect of the Configure method.  If the validPointCount exceeds the data array size, an
        Insufficient Capacity exception is thrown.
     */
    void Configure(const Duration& startTime, const Duration& intervalPerPoint, const TimePoint& triggerTime)
    {
        if (intervalPerPoint == Duration::zero())
        {
            throw std::out_of_range("IntervalPerPoint cannot be zero");
        }
        this->mStartTime = startTime;
        this->mIntervalPerPoint = intervalPerPoint;
        this->mTriggerTime = triggerTime;
    }
    
    /**
     * @brief Additional Configure method.
     * @param startTime The time of the first data point in the waveform relative to the trigger time.
     * @param intervalPerPoint The amount of time between data points in the waveform (required).
     * @param triggerTime The absolute time of the trigger in the waveform.
     * @param capacity The capacity of the of the waveform data array.     
     */
    void Configure(const Duration& startTime, const Duration& intervalPerPoint, const TimePoint& triggerTime, std::int64_t capacity)
    {
        // Check for intervalPerPoint of zero
        if (intervalPerPoint == Duration::zero())
        {
            throw std::invalid_argument("IntervalPerPoint cannot be zero");
        }
        this->mOffset = 0;
        this->mScale = 1.0;

        // Configure the empty waveform
        this->SetCapacity(capacity);
        this->Configure(startTime, intervalPerPoint, 0, triggerTime);
    }

    Duration GetIntervalPerPoint() const  
    { 
        return mIntervalPerPoint; 
    }    

    Duration GetStartTime() const 
    { 
        return this->mValidPointCount == 0 ? Duration::zero() : mStartTime;
    }

    Duration GetEndTime() const 
    { 
        return (this->mValidPointCount == 0) ? Duration::zero() : this->GetStartTime() + this->GetTotalTime();
    }

    Duration GetTotalTime() const
    {
        return (this->mValidPointCount == 0) ? Duration::zero() : this->mIntervalPerPoint * (this->mValidPointCount - 1);
    }

private:
    void ConfigureWithValidPointCount(const Duration& startTime, const Duration& intervalPerPoint, const TimePoint& triggerTime, std::int64_t validPointCount)
    {
        if (validPointCount < 0)
        {
            throw std::out_of_range("ValidPointCount cannot be negative");
        }

        if (validPointCount > this->mCapacity)
        {
            throw std::runtime_error("ValidPointCount cannot exceeds capacity");
        }
        Configure(startTime, intervalPerPoint, triggerTime);
        this->mValidPointCount = validPointCount;
    } 
};

}}
#endif // RCL_IVI_WAVEFORM_H