/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#ifndef RCL_POINTER_MARSHALER_H
#define RCL_POINTER_MARSHALER_H

/**
 * @file PointerMarshaler.h
 * @author the Rooftop team
 * defines the marshaler class for void* pointer
 */

#include "BasicMarshaler.h"
#include <memory>

namespace Keysight {
namespace ApiCoreLibraries {

/**
 *@brief marshaler class for void*
 * This class doesn't inherit from ICustomMarshaler<void*> as there is an issue of handing void*&
*/
class PointerMarshaler
{
public:
    void BytesToCpp(MarshalBuffer& marshalBuffer, void*& result);
    void CppToBytes(const void* input, MarshalBuffer& marshalBuffer);
    std::int32_t GetBufferSize() const;

private:
    Int64Marshaler mInt64Marshaler;
};

}}
#endif // RCL_POINTER_MARSHALER_H