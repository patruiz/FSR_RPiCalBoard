/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#include "PointerMarshaler.h"

using namespace Keysight::ApiCoreLibraries;

void PointerMarshaler::BytesToCpp(MarshalBuffer& marshalBuffer, void*& result)
{
    int64_t anInt64;
    mInt64Marshaler.BytesToCpp(marshalBuffer, anInt64);
    result = reinterpret_cast<void*>(anInt64);
}

void PointerMarshaler::CppToBytes(const void* input, MarshalBuffer& marshalBuffer)
{
    mInt64Marshaler.CppToBytes(reinterpret_cast<std::int64_t>(input), marshalBuffer);
}

std::int32_t PointerMarshaler::GetBufferSize() const
{
    return mInt64Marshaler.GetBufferSize();
}