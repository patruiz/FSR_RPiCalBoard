/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#ifndef RCL_BASIC_MARSHALER_H
#define RCL_BASIC_MARSHALER_H

/**
 * @file BasicMarshaler.h
 * @author the Rooftop team
 * this file defines the template class for marshaler of primitive types and alias for those marshalers
 */
#include "CommonExport.h"
#include "ICustomMarshaler.h"
#include <memory>
#include <chrono>
#include <exception>
#include <string>
#include <cstring>
#include <type_traits>

namespace Keysight {
namespace ApiCoreLibraries {

/**
 *@brief template marshaler class for fundamental types
*/
template <class T>
class KTROOFTOP_COMMON_API BasicMarshaler : public ICustomMarshaler<T>
{
public:
    BasicMarshaler()
    {
        // runtime check to restrict T to fundamental types
        static_assert(std::is_fundamental<T>::value, "BasicMarshaler<T> can only support fundamental types!");
    }

    void BytesToCpp(MarshalBuffer& marshalBuffer, T& result) override
    {
        result = *(reinterpret_cast<T*>(const_cast<std::uint8_t*>(marshalBuffer.Bytes())));
        marshalBuffer.Forward(sizeof(T));
    }

    void CppToBytes(const T& input, MarshalBuffer& marshalBuffer) override
    {
        std::memcpy(marshalBuffer.Bytes(), &input, sizeof(T));
        marshalBuffer.Forward(sizeof(T));
    }

    std::int32_t GetBufferSize() const override
    {
        return sizeof(T);
    }
};

using SingleMarshaler = BasicMarshaler<float>;
using DoubleMarshaler = BasicMarshaler<double>;
using BoolMarshaler = BasicMarshaler<bool>;
using CharMarshaler = BasicMarshaler<char>;
using Int8Marshaler = BasicMarshaler<int8_t>;
using UInt8Marshaler = BasicMarshaler<uint8_t>;
using Int16Marshaler = BasicMarshaler<int16_t>;
using UInt16Marshaler = BasicMarshaler<uint16_t>;
using Int32Marshaler = BasicMarshaler<int32_t>;
using UInt32Marshaler = BasicMarshaler<uint32_t>;
using Int64Marshaler = BasicMarshaler<int64_t>;
using UInt64Marshaler = BasicMarshaler<uint64_t>;

}}
#endif // RCL_BASIC_MARSHALER_H