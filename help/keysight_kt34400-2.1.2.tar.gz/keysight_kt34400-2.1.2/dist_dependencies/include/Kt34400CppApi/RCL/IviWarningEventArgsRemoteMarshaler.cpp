#include "IviWarningEventArgsRemoteMarshaler.h"

using namespace Keysight::ApiCoreLibraries;

void IviWarningEventArgsRemoteMarshaler::BytesToCpp(MarshalBuffer& marshalBuffer, IviWarningEventArgs& result)
{
	std::string code;
	mStringRemoteMarshaler.BytesToCpp(marshalBuffer, code);
	std::string text;
	mStringRemoteMarshaler.BytesToCpp(marshalBuffer, text);
	IviWarningEventArgs waringEventArgs(code, text);
	result = waringEventArgs;
}

void IviWarningEventArgsRemoteMarshaler::CppToBytes(const IviWarningEventArgs& input, MarshalBuffer& marshalBuffer)
{
	mStringRemoteMarshaler.CppToBytes(input.GetCode(), marshalBuffer);
	mStringRemoteMarshaler.CppToBytes(input.GetText(), marshalBuffer);
}

std::int32_t IviWarningEventArgsRemoteMarshaler::GetBufferSize() const
{
	throw std::runtime_error("not implemented");
}

std::int32_t IviWarningEventArgsRemoteMarshaler::GetBufferSizeForRPC(const IviWarningEventArgs& input) const
{
	return mStringRemoteMarshaler.GetBufferSizeForRPC(input.GetCode()) +
		mStringRemoteMarshaler.GetBufferSizeForRPC(input.GetText());
}