/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#include "ChronoDurationMarshaler.h"
#include "BasicMarshaler.h"

using namespace Keysight::ApiCoreLibraries;

void ChronoDurationMarshaler::BytesToCpp(MarshalBuffer& marshalBuffer, Duration& result)
{
    double seconds, fractionalSeconds;
    
    mDoubleMarshaler.BytesToCpp(marshalBuffer, seconds);
    mDoubleMarshaler.BytesToCpp(marshalBuffer, fractionalSeconds);
    result = Duration(seconds + fractionalSeconds);    
}


void ChronoDurationMarshaler::CppToBytes(const Duration& input, MarshalBuffer& marshalBuffer)
{
    mDoubleMarshaler.CppToBytes(input.count(), marshalBuffer);
    mDoubleMarshaler.CppToBytes(0.0, marshalBuffer);    
}

std::int32_t ChronoDurationMarshaler::GetBufferSize() const
{
    return 2 * mDoubleMarshaler.GetBufferSize();
}