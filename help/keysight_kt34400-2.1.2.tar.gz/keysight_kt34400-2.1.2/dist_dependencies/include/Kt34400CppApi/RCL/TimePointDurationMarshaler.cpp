/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#include "TimePointDurationMarshaler.h"
#include "BasicMarshaler.h"

using namespace Keysight::ApiCoreLibraries;

// Marshaled to two double values, seconds since epoch and secondsFractional since epoch
void TimePointDurationMarshaler::BytesToCpp(MarshalBuffer& marshalBuffer, TimePointDuration& result)
{
    double seconds, fractionalSeconds;

    mDoubleMarshaler.BytesToCpp(marshalBuffer, seconds);
    mDoubleMarshaler.BytesToCpp(marshalBuffer, fractionalSeconds);
    std::int64_t ticks = static_cast<std::int64_t>((seconds + fractionalSeconds) * NANO_100_TICKS);
    result = TimePointDuration(ticks);    
}

void TimePointDurationMarshaler::CppToBytes(const TimePointDuration& input, MarshalBuffer& marshalBuffer)
{
	//double seconds = input.count() / static_cast<double>(NANO_100_TICKS);
	double seconds = static_cast<double>(input.count() / NANO_100_TICKS); // Use integer division to only return whole seconds
	double fractionalSeconds = (input.count() % NANO_100_TICKS) / static_cast<double>(NANO_100_TICKS);

    mDoubleMarshaler.CppToBytes(seconds, marshalBuffer);
    mDoubleMarshaler.CppToBytes(fractionalSeconds, marshalBuffer);
}

std::int32_t TimePointDurationMarshaler::GetBufferSize() const
{
    return 2 * mDoubleMarshaler.GetBufferSize();
}