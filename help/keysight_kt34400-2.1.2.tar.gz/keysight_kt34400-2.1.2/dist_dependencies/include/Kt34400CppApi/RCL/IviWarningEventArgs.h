/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#ifndef RCL_IVI_WARNING_EVENT_ARGS_H
#define RCL_IVI_WARNING_EVENT_ARGS_H

/**
 * @file IviWarningEventArgs.h
 * @author the Rooftop team
 *  define class IviWarningEventArgs
 */

#include <string>

namespace Keysight {
namespace ApiCoreLibraries {

/**
 * The C++ equivalent class for Ivi.Driver.WarningEventArgs
 */
class IviWarningEventArgs
{
public:
    /**
     * @brief Construct an empty IviWarningEventArgs object
     *
     */
    IviWarningEventArgs() = default;
    /**
     * @brief Construct a new IviWarningEventArgs object
     *
     * @param code: error code
     */
    IviWarningEventArgs(const std::string& code)
        : mCode(code)
    {
    }

    /**
     * @brief Construct a new IviWarningEventArgs object
     *
     * @param code error code
     * @param text error text
     */
    IviWarningEventArgs(const std::string& code, const std::string& text)
        : mCode(code)
        , mText(text)
    {
    }

    /**
     * @brief Get the error code
     *
     * @return std::string error code
     */
    std::string GetCode() const
    {
        return mCode;
    }

    /**
     * @brief Get the error text
     *
     * @return std::string error text
     */
    std::string GetText() const
    {
        return mText;
    }

private:
    std::string mCode = "";
    std::string mText = "";
};

}}

#endif // RCL_IVI_WARNING_EVENT_ARGS_H