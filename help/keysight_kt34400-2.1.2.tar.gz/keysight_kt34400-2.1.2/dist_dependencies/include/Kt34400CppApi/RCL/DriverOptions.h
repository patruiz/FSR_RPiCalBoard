/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#ifndef RCL_DRIVER_OPTIONS_H
#define RCL_DRIVER_OPTIONS_H

/**
 * @file DriverOptions.h
 * @author the Rooftop team
 * defines the DriverOptions class
 */

#include <string>
#include <regex>

namespace Keysight
{
namespace ApiCoreLibraries
{

    /**
     * @brief DriverOptions is a helper class for parsing the option string passed to the driver constructor
     *
     */
    class DriverOptions
    {
    public:
        /**
         * @brief Construct a new Driver Options object from the string options
         *
         * @param optionsStr
         */
        DriverOptions(const std::string& optionsStr)
            : mStrOptions(optionsStr)
        {
        }

        /**
         * @brief template method to get the setting of T from the option
         * if the option doesn't exist or parsing failed, return the default value, without throwing
         *
         * @tparam T the value type
         * @param name the name of the option
         * @param defaultValue the default value
         * @return T the result
         */
        template <typename T>
        T Get(const std::string& name, T defaultValue)
        {
            T value = defaultValue;
            try
            {
                std::regex re(name + "\\s*=\\s*([\\w:/\\[\\]\\.\\-\\%]*)", std::regex::icase);
                std::smatch match;
                if (std::regex_search(mStrOptions, match, re) && match.size() > 1)
                {
                    std::string result = match.str(1);
                    if (!result.empty())
                    {
                        value = FromString<T>(result);
                    }
                }
            }
            catch (std::regex_error&)
            {
                // Syntax error in the regular expression
            }
            return value;
        }

        bool HasOption(const std::string& name)
        {
            if (this->Get<std::string>(name, "") != "")
            {
                return true;
            }
            return false;
        }

        std::string RemoveOption(const std::string& name)
        {
            auto result = mStrOptions;
            try
            {
                std::regex re(name + "\\s*=\\s*[\\w:/\\[\\]\\.\\-\\%]*", std::regex::icase);
                std::smatch match;
                if (std::regex_search(mStrOptions, match, re) && match.size() > 0)
                {
                    std::string fullOption = match.str(0);
                    if (!fullOption.empty())
                    {
                        size_t pos = result.find(fullOption);
                        result.erase(pos, fullOption.length());
                    }
                }
            }
            catch (std::regex_error&)
            {
                // Syntax error in the regular expression
            }
            return result;
        }      

    private:
        std::string mStrOptions{""};

        /**
         * @brief Generic implementation of converting string to a type T
         * The default is to convet is to numberic type
         *
         * @tparam T type
         * @param str input string
         * @return T the result
         */
        template <typename T>
        T FromString(const std::string& str)
        {
            return static_cast<T>(std::stol(str));
        }
    };

    /**
     * @brief specialization of FromString for boolean type

     * @param str the input string
     * @return the converted boolean value
     */
    template <>
    bool inline DriverOptions::FromString(const std::string& str)
    {
        return (str == "true" || str == "True" || str == "TRUE" || str == "1") ? true : false;
    }

    /**
     * @brief specialization of FromString for string type
     */
    template <>
    std::string inline DriverOptions::FromString(const std::string& str)
    {
        return str;
    }

} // namespace ApiCoreLibraries
} // namespace Keysight

#endif // RCL_DRIVER_OPTIONS_H