#ifndef RCL_IVI_SPECTRUM_MARSHALER_H
#define RCL_IVI_SPECTRUM_MARSHALER_H

#include "IviSpectrum.h"
#include "ICustomMarshaler.h"
#include "AnyVectorMarshaler.h"
#include "TimePointMarshaler.h"
#include <memory>
#include <chrono>

namespace Keysight::ApiCoreLibraries{

template <class T>
class IviSpectrumMarshaler : public Keysight::ApiCoreLibraries::ICustomMarshaler<Keysight::ApiCoreLibraries::IviSpectrum<T>>
{   
            
public:
    void BytesToCpp(MarshalBuffer& marshalBuffer, Keysight::ApiCoreLibraries::IviSpectrum<T>& result) override
    {
        Keysight::ModularInstruments::AnyVector<T> data;
        std::int64_t capacity = 0;
        std::int64_t firstValidPoint = 0;        
        double offset = 0;
        double scale = 1;
        double startFrequency;
        double stopFrequency;
        TimePoint triggerTime;
        std::int64_t validPointCount = 0;

        mGslSpanMarshaler.BytesToCpp(marshalBuffer, data);
        mInt64Marshaler.BytesToCpp(marshalBuffer, capacity);
        mInt64Marshaler.BytesToCpp(marshalBuffer, firstValidPoint);        
        if(!mIsFloatingData)
        {
            mDoubleMarshaler.BytesToCpp(marshalBuffer, offset);
            mDoubleMarshaler.BytesToCpp(marshalBuffer, scale);
        }        
        mDoubleMarshaler.BytesToCpp(marshalBuffer, startFrequency);
        mDoubleMarshaler.BytesToCpp(marshalBuffer, stopFrequency);
        mTimePointMarshaler.BytesToCpp(marshalBuffer, triggerTime);
        mInt64Marshaler.BytesToCpp(marshalBuffer, validPointCount);

        result.SetDataSpan(data);        
        result.SetCapacity(capacity);
        result.Configure(startFrequency, stopFrequency, triggerTime, validPointCount);
        result.SetFirstValidPoint(firstValidPoint);
        if(!mIsFloatingData)
        {
            result.SetOffset(offset);
            result.SetScale(scale);
        }        
    }

    void CppToBytes(const Keysight::ApiCoreLibraries::IviSpectrum<T>& input, MarshalBuffer& marshalBuffer) override
    {
        mGslSpanMarshaler.CppToBytes(input.GetDataSpan(), marshalBuffer);
        mInt64Marshaler.CppToBytes(input.GetCapacity(), marshalBuffer);
        mInt64Marshaler.CppToBytes(input.GetFirstValidPoint(), marshalBuffer);        
        if(!mIsFloatingData)
        {
            mDoubleMarshaler.CppToBytes(input.GetOffset(), marshalBuffer);
            mDoubleMarshaler.CppToBytes(input.GetScale(), marshalBuffer);
        }        
        mDoubleMarshaler.CppToBytes(input.GetStartFrequency(), marshalBuffer);
        mDoubleMarshaler.CppToBytes(input.GetStopFrequency(), marshalBuffer);
        mTimePointMarshaler.CppToBytes(input.GetTriggerTime(), marshalBuffer);
        mInt64Marshaler.CppToBytes(input.GetValidPointCount(), marshalBuffer);
    }

    std::int32_t GetBufferSize() const override
    {
        std::int32_t size = 2 * mDoubleMarshaler.GetBufferSize();   // startFrequency and stopFrequency
        size += mTimePointMarshaler.GetBufferSize();                // triggerTime
        size += 3 * mInt64Marshaler.GetBufferSize();                // Capacity, FirstValidPoint and ValidPointCount
        if(!mIsFloatingData)
        {
            size += 2 * mDoubleMarshaler.GetBufferSize();           // Offset and Scale
        }
        
        return size;
    }

private:
    Keysight::ApiCoreLibraries::DoubleMarshaler mDoubleMarshaler;
    Keysight::ApiCoreLibraries::Int64Marshaler mInt64Marshaler;
    Keysight::ApiCoreLibraries::AnyVectorMarshaler<T> mGslSpanMarshaler;    
    Keysight::ApiCoreLibraries::TimePointMarshaler mTimePointMarshaler;
    bool mIsFloatingData = std::is_floating_point<T>::value;
};
    
}
#endif // RCL_IVI_SPECTRUM_MARSHALER_H