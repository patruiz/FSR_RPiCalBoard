/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#ifndef RCL_IVI_WARNING_EVENT_ARGS_REMOTE_MARSHALER_H
#define RCL_IVI_WARNING_EVENT_ARGS_REMOTE_MARSHALER_H

 /**
  * @file IviWarningEventArgsRemoteMarshaler.h
  * @author the Rooftop team
  * defines the rpc marshaler class for IviWarningEventArgs
  */
#include "CommonExport.h"
#include "ICustomMarshaler.h"
#include "BasicMarshaler.h"
#include "StringRemoteMarshaler.h"
#include "IviWarningEventArgs.h"

namespace Keysight
{
namespace ApiCoreLibraries
{
class KTROOFTOP_COMMON_API IviWarningEventArgsRemoteMarshaler : public ICustomMarshaler<IviWarningEventArgs>
{
public:
	/**
	* @brief Takes a marshal buffer and extracts a C++ type. It advances the count in the buffer to the next location
	*  @param marshalBuffer the marshal buffer that holds the buffer
	*  @param result the output C++ object deserialized from the buffer
	*/
	void BytesToCpp(MarshalBuffer& marshalBuffer, IviWarningEventArgs& result) override;

	/**
	* @brief Takes a C++ type and writes it into the marshal buffer, advancing the count in the marshal buffer to the next available location.
	* @param input the input C++ object
	* @param marshalBuffer the marshal buffer that holds the buffer
	*/
	void CppToBytes(const IviWarningEventArgs& input, MarshalBuffer& marshalBuffer) override;

	/**
	* @brief Get the buffer size need required for marshaling T
	*/
	std::int32_t GetBufferSize() const override;
	/**
	* @brief Get the buffer size required for marshaling T
	*/
	std::int32_t GetBufferSizeForRPC(const IviWarningEventArgs& input) const override;

private:
	StringRemoteMarshaler mStringRemoteMarshaler;
};

}}

#endif // RCL_IVI_WARNING_EVENT_ARGS_REMOTE_MARSHALER_H