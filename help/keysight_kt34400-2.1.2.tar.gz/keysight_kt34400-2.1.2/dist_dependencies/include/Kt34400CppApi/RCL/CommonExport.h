#ifndef RCL_COMMON_EXPORT_H
#define RCL_COMMON_EXPORT_H
#ifdef _RCL_COMMONAPI_STATIC
#define KTROOFTOP_COMMON_API
#else
#if defined(WIN32) || defined (_WIN32)
#ifdef ROOFTOPDEV             //only defined in RooftopDev/RCL
#define KTROOFTOP_COMMON_API
#else
#ifdef _RCL_COMMONAPI_EXPORTS //defined in CppApi and projects need to export some rcl classes
#define KTROOFTOP_COMMON_API __declspec(dllexport)
#else
#define KTROOFTOP_COMMON_API __declspec(dllimport)
#endif
#endif
#else
#define KTROOFTOP_COMMON_API
#endif
#endif

#endif // RCL_COMMON_EXPORT_H