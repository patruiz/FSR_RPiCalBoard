/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#include "MarshalBuffer.h"
#include <memory>

using namespace Keysight::ApiCoreLibraries::Marshal;

MarshalBuffer::MarshalBuffer(std::uint8_t* buffer)
    : mBuffer(buffer)
    , mOffset(sizeof(std::int32_t))
    , mMaxSize(*reinterpret_cast<std::int32_t*>(buffer))
{
}

MarshalBuffer::MarshalBuffer(std::int32_t size)
{
	mBuffer = new std::uint8_t[size];
	mOffset = 0;
	mMaxSize = size;
	mToReleaseMemory = true;
}

MarshalBuffer::MarshalBuffer(const std::string& str)
	: mBuffer(reinterpret_cast<uint8_t*>(const_cast<char*>(str.c_str())))
	, mOffset(0)
	, mMaxSize(static_cast<std::int32_t>(str.size()))
{
}

MarshalBuffer::MarshalBuffer(std::uint8_t* buffer, std::int32_t size)
    : mBuffer(buffer)
    , mOffset(0)
    , mMaxSize(size)
{
}

MarshalBuffer::~MarshalBuffer()
{
	if (mToReleaseMemory)
	{
		delete[] mBuffer;
		mBuffer = nullptr;
	}
}

std::string MarshalBuffer::ToString()
{
	return mBuffer == nullptr ? "" : std::string(reinterpret_cast<char*>(mBuffer), mMaxSize);
}

std::uint8_t* MarshalBuffer::Bytes() const
{
    if (mOffset >= mMaxSize)
    {
        throw std::out_of_range("Offset in MarshalBuffer exceeds the maximum size.");
    }

    return mBuffer + mOffset;
}

void MarshalBuffer::Forward(std::int32_t size)
{
    if ((mOffset += size) > mMaxSize)
    {
        throw std::out_of_range("Offset in MarshalBuffer exceeds the maximum size.");
    }
}

void MarshalBuffer::ResetOffset()
{
    mOffset = sizeof(std::int32_t);
}
