/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#include "IviErrorQueryResultMarshaler.h"
#include "BasicMarshaler.h"

using namespace Keysight::ApiCoreLibraries;

void IviErrorQueryResultMarshaler::BytesToCpp(MarshalBuffer& marshalBuffer, ErrorQueryResult& result)
{
    int32_t code;
    std::string message;

    mInt32Marshaler.BytesToCpp(marshalBuffer, code);
    mStringMarshaler.BytesToCpp(marshalBuffer, message);
    result = ErrorQueryResult(code, message);
}


void IviErrorQueryResultMarshaler::CppToBytes(const ErrorQueryResult& input, MarshalBuffer& marshalBuffer)
{
    mInt32Marshaler.CppToBytes(input.GetCode(), marshalBuffer);
    mStringMarshaler.CppToBytes(input.GetMessage(), marshalBuffer);
}

std::int32_t IviErrorQueryResultMarshaler::GetBufferSize() const
{
    return mInt32Marshaler.GetBufferSize() + mStringMarshaler.GetBufferSize();
}
