#ifndef RCL_IVI_WAVEFORM_MARSHALER_H
#define RCL_IVI_WAVEFORM_MARSHALER_H

#include "IviWaveform.h"
#include "ICustomMarshaler.h"
#include "AnyVectorMarshaler.h"
#include "ChronoDurationMarshaler.h"
#include <memory>
#include <chrono>

namespace Keysight::ApiCoreLibraries{

template <class T>
class IviWaveformMarshaler : public Keysight::ApiCoreLibraries::ICustomMarshaler<Keysight::ApiCoreLibraries::IviWaveform<T>>
{   
            
public:
    void BytesToCpp(MarshalBuffer& marshalBuffer, Keysight::ApiCoreLibraries::IviWaveform<T>& result) override
    {
        Keysight::ModularInstruments::AnyVector<T> data;
        std::int64_t capacity = 0;
        std::int64_t firstValidPoint = 0;
        Duration intervalPerPoint;
        double offset = 0;
        double scale = 1;
        Duration startTime;
        TimePoint triggerTime;
        std::int64_t validPointCount = 0;

        mGslSpanMarshaler.BytesToCpp(marshalBuffer, data);
        mInt64Marshaler.BytesToCpp(marshalBuffer, capacity);
        mInt64Marshaler.BytesToCpp(marshalBuffer, firstValidPoint);
        mChronoDurationMarshaler.BytesToCpp(marshalBuffer, intervalPerPoint);
        if(!mIsFloatingData)
        {
            mDoubleMarshaler.BytesToCpp(marshalBuffer, offset);
            mDoubleMarshaler.BytesToCpp(marshalBuffer, scale);
        }        
        mChronoDurationMarshaler.BytesToCpp(marshalBuffer, startTime);
        mTimePointMarshaler.BytesToCpp(marshalBuffer, triggerTime);
        mInt64Marshaler.BytesToCpp(marshalBuffer, validPointCount);

        result.SetDataSpan(data);
        result.SetCapacity(capacity);
        result.Configure(startTime, intervalPerPoint, validPointCount, triggerTime);        
        result.SetFirstValidPoint(firstValidPoint);        
        if(!mIsFloatingData)
        {
            result.SetOffset(offset);
            result.SetScale(scale);
        }        
    }

    void CppToBytes(const Keysight::ApiCoreLibraries::IviWaveform<T>& input, MarshalBuffer& marshalBuffer) override
    {
        mGslSpanMarshaler.CppToBytes(input.GetDataSpan(), marshalBuffer);
        mInt64Marshaler.CppToBytes(input.GetCapacity(), marshalBuffer);
        mInt64Marshaler.CppToBytes(input.GetFirstValidPoint(), marshalBuffer);
        mChronoDurationMarshaler.CppToBytes(input.GetIntervalPerPoint(), marshalBuffer);
        if(!mIsFloatingData)
        {
            mDoubleMarshaler.CppToBytes(input.GetOffset(), marshalBuffer);
            mDoubleMarshaler.CppToBytes(input.GetScale(), marshalBuffer);
        }        
        mChronoDurationMarshaler.CppToBytes(input.GetStartTime(), marshalBuffer);
        mTimePointMarshaler.CppToBytes(input.GetTriggerTime(), marshalBuffer);
        mInt64Marshaler.CppToBytes(input.GetValidPointCount(), marshalBuffer);
    }

    std::int32_t GetBufferSize() const override
    {
        std::int32_t size = 2 * mChronoDurationMarshaler.GetBufferSize();
        size += mTimePointMarshaler.GetBufferSize();        
        size += 3 * mInt64Marshaler.GetBufferSize();
        if(!mIsFloatingData)
        {
            size += 2 * mDoubleMarshaler.GetBufferSize();
        }
        
        return size;
    }

private:
    Keysight::ApiCoreLibraries::DoubleMarshaler mDoubleMarshaler;
    Keysight::ApiCoreLibraries::Int64Marshaler mInt64Marshaler;
    Keysight::ApiCoreLibraries::AnyVectorMarshaler<T> mGslSpanMarshaler;
    Keysight::ApiCoreLibraries::ChronoDurationMarshaler mChronoDurationMarshaler;
    Keysight::ApiCoreLibraries::TimePointMarshaler mTimePointMarshaler;
    bool mIsFloatingData = std::is_floating_point<T>::value;
};
    
}
#endif // RCL_IVI_WAVEFORM_MARSHALER_H