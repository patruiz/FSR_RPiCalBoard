/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#include "ChronoDurationFemtoMarshaler.h"
#include "BasicMarshaler.h"

using namespace Keysight::ApiCoreLibraries;

void ChronoDurationFemtoMarshaler::BytesToCpp(MarshalBuffer& marshalBuffer, DurationInt64Femto& result)
{
    double seconds, fractionalSeconds;

    mDoubleMarshaler.BytesToCpp(marshalBuffer, seconds);
    mDoubleMarshaler.BytesToCpp(marshalBuffer, fractionalSeconds);
    double totalSencondsInDouble = seconds + fractionalSeconds;
    result = DurationInt64Femto(static_cast<std::int64_t>(totalSencondsInDouble*1.0e15));
}

void ChronoDurationFemtoMarshaler::CppToBytes(const DurationInt64Femto& input, MarshalBuffer& marshalBuffer)
{
    mDoubleMarshaler.CppToBytes(static_cast<double>(input.count()), marshalBuffer);
    mDoubleMarshaler.CppToBytes(0.0, marshalBuffer);    
}

std::int32_t ChronoDurationFemtoMarshaler::GetBufferSize() const
{
    return 2 * mDoubleMarshaler.GetBufferSize();
}