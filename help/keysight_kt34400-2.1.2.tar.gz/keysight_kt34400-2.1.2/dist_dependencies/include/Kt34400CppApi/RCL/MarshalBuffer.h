/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#ifndef RCL_MARSHAL_BUFFER_H
#define RCL_MARSHAL_BUFFER_H

/**
 * @file MarshalBuffer.h
 * @author the Rooftop team
 *
 * defines the MarshalBuffer class
 */
#include "CommonExport.h"
#include <memory>
#include <stdexcept>
#include <queue>
#include "AnyVector.h"

#ifndef STDCALL
# ifdef WIN32
#   define STDCALL __stdcall
# else
#   define STDCALL
# endif
#endif

namespace Keysight {
namespace ApiCoreLibraries {
namespace Marshal {

/**
 * @brief A class holding a byte buffer that is used in Marshal classes
 * This class doesn't allocate any memory, it just take a buffer with pre-allocated memory.
 * This class is not supposed to be used in other places except as the parameter of classes that derived from ICustomMarshaler<T>
*/
class KTROOFTOP_COMMON_API MarshalBuffer
{
public:

    //In some cases, some interimObjects are needed in the marshaler class.
    //For example, in the string marshaler, we need to convert it to bytes in .NET side and pass the reference to C++ as a AnyVector<byte>
    //The AnyVector object need to be cached because when sending data back from C++ to .NET, it may be used to resize the memory(the allocator is in it!)
    //Saving it to the Marshaler is not a good idea as one marshaler may be used to server multiple instance, so we save it to marshalBuffer
    //The interim object may not be limited to AnyVector<byte> but at this point AnyVector<byte> (stands for a byte array) is the most common case we can think of
    //If other types are required in the future, we may need to use boost::variant or std::any (C++17)
    using InterimObjectCollection = typename std::queue<Keysight::ModularInstruments::AnyVector<std::uint8_t>>;

    /**
     * @brief Construct a MarshalBuffer
     * @param buffer the pre-allocated memory buffer, MarshalBuffer takes the first 4 bytes as an std::int32_t for the length of the buffer
     */
    explicit MarshalBuffer(std::uint8_t* buffer);

	explicit MarshalBuffer(std::int32_t size);

	explicit MarshalBuffer(const std::string& str);


    /**
    * @brief Construct a MarshalBuffer
    * @param buffer the pointer to the pre-allocated memory buffer,
    * @param size the buffer size
    */
    MarshalBuffer(std::uint8_t* buffer, std::int32_t size);

	~MarshalBuffer();

	/**
		* @brief Convert marshal buffer to string object
		* @return std::string object
	*/
	std::string ToString();

    /**
     * @brief Get the currently buffer address
     *  A out_of_range exception is thrown if the current address exceed the boundary.
     * @return The address of the current buffer
    */
    std::uint8_t* Bytes() const;

    /**
     * @brief Move forward the current offset
     * @param size the range to move forward
     */
    void Forward(std::int32_t size);

    /**
     * @brief Reset the offset to the beginning
    */
    void ResetOffset();

    /**
     *@brief Get the collection of interim objects
    */
    InterimObjectCollection& GetInterimObjects();


private:
    std::uint8_t* mBuffer = nullptr;
    std::int32_t mOffset = 0;
    std::int32_t mMaxSize = 0;
	bool mToReleaseMemory = false;
};

}}}
#endif // RCL_MARSHAL_BUFFER_H