/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#ifndef RCL_MEMORY_ALLOCATION_H
#define RCL_MEMORY_ALLOCATION_H

/**
* @file MemoryAllocation.h
* @author Rooftop Team
*
* Provide some functionalities for .NET memory allocation from C++
*/

#include "AnyVector.h"
#include <functional>
#include <map>


namespace Keysight{
namespace ApiCoreLibraries {

using CSharpAllocationCallback_t = std::function<void*(void* originalHandle, std::int32_t size)>;

class MemoryAllocation
{
public:
    /**
     * @brief install the memory allocation delegate from .NET
     *
     * @param appDomainId the .NET application domain ID
     * @param helper callback for .NET delegate
     */
    static void InstallAllocationHelper(int appDomainId, CSharpAllocationCallback_t helper);

    /**
     * @brief Uninstall the allocation helper when it is not used
     *
     * @param appDomainId the .NET application domain ID
     */
    static void UninstallAllocationHelper(int appDomainId);

    /**
     * @brief Check the status of the callbacks
     *
     * @param details output string for the details of the report
     * @return int the len of callbacks
     */
    static int ReportCallbackStatus(std::string& details);

    /**
     * @brief Create a valid AnyVector<uint_8> object that contains a valid memory allocation delegate
     *  This method is supposed to be use in variadic size object marshaling case where dynamic memory
     *  allocation is needed
     *  This method is ONLY supposed to be used in .NET marshaler code
     * @return Keysight::ModularInstruments::AnyVector<std::uint8_t>
     */
    static Keysight::ModularInstruments::AnyVector<std::uint8_t> CreateAnyVectorByte();

private:
    /// map of the callbacks, the key is AppDomainID
    static std::map<int, CSharpAllocationCallback_t> mAllocateHelper;
};

}}
#endif // RCL_MEMORY_ALLOCATION_H