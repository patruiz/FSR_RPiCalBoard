/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#ifndef RCL_ENUM_ARRAY_REMOTE_MARSHALER_H
#define RCL_ENUM_ARRAY_REMOTE_MARSHALER_H

 /**
  * @file EnumArrayRemoteMarshaler.h
  * @author the Rooftop team
  * defines the rpc marshaler class for std::vector<EnumType>
  */

#include "ICustomMarshaler.h"
#include "BasicMarshaler.h"
#include <vector>

namespace Keysight {
namespace ApiCoreLibraries {
	/**
	*@brief rpc marshaler class for std::vector < EnumType >
	*@tparam _eleT the element type of the array
	*@tparam  _eleMarshalerT the marshaler class for the element type
	*/
	template <class EnumType>
	class EnumArrayRemoteMarshaler : public Keysight::ApiCoreLibraries::ICustomMarshaler<std::vector<EnumType>>
	{
	public:
		void BytesToCpp(MarshalBuffer& marshalBuffer, std::vector<EnumType>& result) override
		{
			result.clear();
			std::int32_t size = 0;
			mInt32Marshaler.BytesToCpp(marshalBuffer, size);
			for (int index = 0; index < size; index++)
			{
				std::int32_t element;
				mElementRemoteMarshaler.BytesToCpp(marshalBuffer, element);
				result.push_back(static_cast<EnumType>(element));
			}
		}

		void CppToBytes(const std::vector<EnumType>& input, MarshalBuffer& marshalBuffer) override
		{
			mInt32Marshaler.CppToBytes(static_cast<std::int32_t>(input.size()), marshalBuffer);
			for (auto& ele : input)
			{
				mElementRemoteMarshaler.CppToBytes(static_cast<std::int32_t>(ele), marshalBuffer);
			}
		}

		std::int32_t GetBufferSize() const override
		{
			throw std::runtime_error("should not be called here!");
		}

		std::int32_t GetBufferSizeForRPC(const std::vector<EnumType>& input) const override
		{
			if (input.size() > 0)
			{
				return sizeof(std::int32_t) + static_cast<std::int32_t>(input.size())*sizeof(std::int32_t);
			}
			else
			{
				return sizeof(std::int32_t);
			}

		}

	private:
		Keysight::ApiCoreLibraries::Int32Marshaler mInt32Marshaler;
		BasicMarshaler<std::int32_t> mElementRemoteMarshaler;
	};
}}

#endif // RCL_ENUM_ARRAY_REMOTE_MARSHALER_H