/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#ifndef RCL_APP_DOMAIN_H
#define RCL_APP_DOMAIN_H

/**
* @file AppDomain.h
* @author
*
* Provide a method and a APPDOMAIN_ID macro to support getting the .NET AppDomain ID
* The domain ID is only reasonable on Windows
*/


/**
 * @brief API to get the AppDomain ID, Only work on Windows, for Linux the value is always 0
 *
 */
#if defined(_WIN32) || defined(__WIN32__) || defined(__CYGWIN__)

namespace Keysight {
namespace ApiCoreLibraries {

#ifdef __cplusplus
extern "C"
#endif
/**
 * @brief Get the .NET App Domain ID
 *
 * @return int the app domain ID
 */
extern int GetAppDomainID();

}}

#define APPDOMAIN_ID (Keysight::ApiCoreLibraries::GetAppDomainID())

#else
#define APPDOMAIN_ID 0
#endif

#endif // RCL_APP_DOMAIN_H