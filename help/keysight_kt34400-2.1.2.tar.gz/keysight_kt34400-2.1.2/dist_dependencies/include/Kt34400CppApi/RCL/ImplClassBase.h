/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#ifndef RCL_IMPL_CLASS_BASE_H
#define RCL_IMPL_CLASS_BASE_H

/**
 * @file ImplClassBase.h
 * @author the Rooftop team
 *
 * defines class ImplClassBase
 */

#include <string>

namespace Keysight {
namespace ApiCoreLibraries {

/**
 * @brief Base class of all custom defined impl classes
 *  Define some common functionalities here
 */
class ImplClassBase
{
public:
    /**
     * @brief Get the String representation of the class
     * The default implementation is returning the type name
     * Derived classes can override this method for their own representation.
     *
     * @return std::string
     */
    virtual std::string ToString() const;
};
}}

/**
 * @brief Overloading of stream << operator
 *
 * @param os Output stream object where characters are inserted
 * @param value the value object inserted
 * @return std::ostream& The ostream object (os)
 */
std::ostream& operator<<(std::ostream& os, const Keysight::ApiCoreLibraries::ImplClassBase& value);

#endif // RCL_IMPL_CLASS_BASE_H