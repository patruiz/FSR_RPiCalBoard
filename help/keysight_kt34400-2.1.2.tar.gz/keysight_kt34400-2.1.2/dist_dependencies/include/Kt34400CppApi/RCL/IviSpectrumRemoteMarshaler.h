/******************************************************
 *       Copyright Keysight Technologies 2018-2019
 ******************************************************/
#ifndef RCL_IVI_SPECTRUM_REMOTE_MARSHALER_H
#define RCL_IVI_SPECTRUM_REMOTE_MARSHALER_H

 /**
  * @file IviSpectrumRemoteMarshaler.h
  * @author the Rooftop team
  * defines the remote marshaler class for IviSpectrum
  */

#include "ICustomMarshaler.h"
#include "AnyVectorRemoteMarshaler.h"
#include "BasicMarshaler.h"
#include "CommonArrayRemoteMarshaler.h"
#include "TimePointMarshaler.h"
#include "IviSpectrum.h"

namespace Keysight::ApiCoreLibraries{

template <class T>
class IviSpectrumRemoteMarshaler : public Keysight::ApiCoreLibraries::ICustomMarshaler<Keysight::ApiCoreLibraries::IviSpectrum<T>>
{
    using KtRooftop2IviSpectrum = Keysight::ApiCoreLibraries::IviSpectrum<T>;
    using TimePoint = std::chrono::system_clock::time_point;
    using Duration = TimePoint::duration;

public:
    void BytesToCpp(MarshalBuffer& marshalBuffer, Keysight::ApiCoreLibraries::IviSpectrum<T>& result) override
    {
        std::vector<T> dataArray;
        std::int64_t capacity = 0;
        std::int64_t firstValidPoint = 0;        
        double offset = 0;
        double scale = 1;
        double startFrequency;
        double stopFrequency;
        TimePoint triggerTime;
        std::int64_t validPointCount = 0;

        mCommonArrayMarshaler.BytesToCpp(marshalBuffer, dataArray);
        mInt64Marshaler.BytesToCpp(marshalBuffer, capacity);
        mInt64Marshaler.BytesToCpp(marshalBuffer, firstValidPoint);        
        if(!mIsFloatingData)
        {
            mDoubleMarshaler.BytesToCpp(marshalBuffer, offset);
            mDoubleMarshaler.BytesToCpp(marshalBuffer, scale);
        }        
        mDoubleMarshaler.BytesToCpp(marshalBuffer, startFrequency);
        mDoubleMarshaler.BytesToCpp(marshalBuffer, stopFrequency);
        mTimePointMarshaler.BytesToCpp(marshalBuffer, triggerTime);
        mInt64Marshaler.BytesToCpp(marshalBuffer, validPointCount);
        
        // - Capacity need to be set first
        result.SetCapacity(capacity);
        result.Configure(startFrequency, stopFrequency, triggerTime, validPointCount);
        result.SetFirstValidPoint(firstValidPoint);
        this->SetData(result, dataArray);
        if(!mIsFloatingData)
        {
            result.SetOffset(offset);
            result.SetScale(scale);
        }
    }

    void CppToBytes(const Keysight::ApiCoreLibraries::IviSpectrum<T>& input, MarshalBuffer& marshalBuffer) override
    {
        this->DataCppToBytes(input, marshalBuffer);
        mInt64Marshaler.CppToBytes(input.GetCapacity(), marshalBuffer);
        mInt64Marshaler.CppToBytes(input.GetFirstValidPoint(), marshalBuffer);        
        if(!mIsFloatingData)
        {
            mDoubleMarshaler.CppToBytes(input.GetOffset(), marshalBuffer);
            mDoubleMarshaler.CppToBytes(input.GetScale(), marshalBuffer);
        }        
        mDoubleMarshaler.CppToBytes(input.GetStartFrequency(), marshalBuffer);
        mDoubleMarshaler.CppToBytes(input.GetStopFrequency(), marshalBuffer);
        mTimePointMarshaler.CppToBytes(input.GetTriggerTime(), marshalBuffer);        
        mInt64Marshaler.CppToBytes(input.GetValidPointCount(), marshalBuffer);
    }

    std::int32_t GetBufferSize() const
    {
        throw std::runtime_error("Should not be called here!");
    }

    std::int32_t GetBufferSizeForRPC(const Keysight::ApiCoreLibraries::IviSpectrum<T> &waveform) const override
    {
        std::int32_t size = 2 * mDoubleMarshaler.GetBufferSize();               // startFrequency and stopFrequency
        size += mTimePointMarshaler.GetBufferSize();                            // triggerTime        
        size += 3 * mInt64Marshaler.GetBufferSize();                            // validPointCount, capacity and FirstValidPoint
        size += this->GetDataSize(waveform);                                    // data
        if(!mIsFloatingData)
        {
            size += 2 * mDoubleMarshaler.GetBufferSize();                       // scale and offset
        }
        return size;
    }

private:
    Keysight::ApiCoreLibraries::DoubleMarshaler mDoubleMarshaler;
    Keysight::ApiCoreLibraries::Int64Marshaler mInt64Marshaler;
    Keysight::ApiCoreLibraries::AnyVectorRemoteMarshaler<T> mGslSpanMarshaler;    
    Keysight::ApiCoreLibraries::TimePointMarshaler mTimePointMarshaler;
    Keysight::ApiCoreLibraries::CommonArrayRemoteMarshaler<T, Keysight::ApiCoreLibraries::BasicMarshaler<T>> mCommonArrayMarshaler;
    bool mIsFloatingData = std::is_floating_point<T>::value;

private:
    // Check if the Spectrum data is using memory view (using data span to refer the pre allocated memory)
    bool IsUsingMemoryView(const Keysight::ApiCoreLibraries::IviSpectrum<T>& input) const
    {
        return input.GetDataSpan().getMemory() && input.GetDataSpan().getAllocator() ? true : false;
    }

    void DataCppToBytes(const Keysight::ApiCoreLibraries::IviSpectrum<T>& input, MarshalBuffer& marshalBuffer)
    {
        if (this->IsUsingMemoryView(input))
        {
            auto dataSpan = input.GetDataSpan();
            
            // TODO use memory copy
            // size_t size = dataSpan.size();            
            //for (size_t index = 0; index < size; index++)
            //{
            //    waveform.push_back(dataSpan.getSpan()[index]);
            //}

            std::vector<T> waveform(dataSpan.getSpan().begin(), dataSpan.getSpan().end());
            mCommonArrayMarshaler.CppToBytes(waveform, marshalBuffer);
        }
        else
        {
            // it is being called by c++
            mCommonArrayMarshaler.CppToBytes(input.GetData(), marshalBuffer);
        }
    }

    void SetData(Keysight::ApiCoreLibraries::IviSpectrum<T>& result, const std::vector<T>& dataArray)
    {
        auto dataSpan = result.GetDataSpan();
        if(this->IsUsingMemoryView(result))
        {
            dataSpan = dataArray;
            result.SetDataSpan(dataSpan);
        }
        else
        {
            // it is being called by c++
            result.SetData(dataArray);
        }
    }

    std::int32_t GetDataSize(const Keysight::ApiCoreLibraries::IviSpectrum<T> &waveform) const
    {
        if (this->IsUsingMemoryView(waveform))
        {
            return mGslSpanMarshaler.GetBufferSizeForRPC(waveform.GetDataSpan());
        }
        else
        {
            return mCommonArrayMarshaler.GetBufferSizeForRPC(waveform.GetData());
        }
    }
};

}
#endif // RCL_IVI_SPECTRUM_REMOTE_MARSHALER_H