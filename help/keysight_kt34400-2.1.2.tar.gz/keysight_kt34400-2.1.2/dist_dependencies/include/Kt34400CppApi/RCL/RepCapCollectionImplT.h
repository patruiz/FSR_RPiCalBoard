/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#ifndef RCL_REP_CAP_COLLECTION_IMPL_T_H
#define RCL_REP_CAP_COLLECTION_IMPL_T_H

/**
 * @file RepCapCollectionImplT.h
 * @author the Rooftop team
 *
 * defines class RepCapCollectionT, which is the base class for collection style repeated capability Impl class
 */

#include "IRepCapCollectionT.h"
#include "ApiCoreExceptions.h"
#include <regex>
#include <sstream>

namespace Keysight {
namespace ApiCoreLibraries {

/**
 *@brief Base template class for repeated capability collection implement class
 *  This class is a wrapper of std::map and most of the operations are delegated to std::map
 *@note Some of the method are named using the STL conversion to support some standard operations like range based loop
 *@tparam T the repeated capability type.
 */

template <class T>
class RepCapCollectionImplT : public IRepCapCollectionT<T>, public DriverNode
{
public:
    using KeyCollection = std::set<std::string>; // use std::set<std::string, RepCapKeyCILess> for case insensitive key checking

    using key_type = typename IRepCapCollectionT<T>::key_type;
    using value_type = typename IRepCapCollectionT<T>::value_type;
    using size_type = typename IRepCapCollectionT<T>::size_type;
    using iterator = typename IRepCapCollectionT<T>::iterator;

    RepCapCollectionImplT(std::shared_ptr<DriverNode> parent)
        : DriverNode(parent)
    {
    }

    /**
     * @brief Operator [] for read-only access, Not new instance will not be inserted if the key doesn't exist
     * @param key instance name (case insensitive)
     */
    T& operator[] (const std::string& key) override
    {
        return this->Get(key);
    }
    /**
    * @brief Get the reference of instance
    * @param key instance name (case insensitive)
    */
    T& Get(const std::string& key) override
    {
        if (mMap.find(key) != mMap.end())
        {
            return mMap[key];
        }
        else
        {
            throw InvalidOperationException("Physical name '" + key + "' doesn't exist in RepCap collection.");
        }
    }

    /**
     * @brief Get repeated capability instance by index, with bound checking.
     *   The index is the of the order the instance is added.
     *
     * @param index zero-based index of the repeated capability instance to return
     * @return T& reference to the requested repeated capability instance
     * @throw InvalidOperationException if the index out of range
     */
    T& Get(std::int32_t index) override
    {
        if (index < static_cast<std::int32_t>(mIndexTracker.size()) && index >= 0)
        {
            return Get(mIndexTracker[index]);
        }
        else
        {
            std::ostringstream os;
            os << "index '" << index << "' is out of range in RepCap collection.";
            throw InvalidOperationException(os.str());
        }
    }

    /**
     * @brief Get repeated capability physical name, with bound checking.
     *   The index is the of the order the instance is added.
     *
     * @param index zero-based index of the repeated capability name
     * @return std::string
     */
    std::string GetName(std::int32_t index) override
    {
        if (index < static_cast<std::int32_t>(mIndexTracker.size()) && index >= 0)
        {
            return mIndexTracker[index];
        }
        else
        {
            std::ostringstream os;
            os << "index '" << index << "' is out of range in RepCap collection.";
            throw InvalidOperationException(os.str());
        }
    }

    /**
     * @brief Returns the number of repeated capabilities in this collection
     *
     * @return IRepCapCollectionT<T>::size_type The number of elements in the collection.
     */
    size_type size() const override
    {
        return mMap.size();
    }

    /**
     * @brief Returns an iterator to the first element of the container.
     *
     * @return IRepCapCollectionT<T>::iterator Iterator to the first element
     */
    iterator begin() override
    {
        if (mIndexTracker.empty())
        {
            return this->end();
        }
        else
        {
            return this->find(*mIndexTracker.begin());
        }
    }

    /**
     * @brief Returns an iterator to the element following the last element of the container.
     *
     * @return IRepCapCollectionT<T>::iterator Iterator to the element following the last element.
     */
    iterator end() override
    {
        return iterator(mMap.end(), this);
    }

    /**
     * @brief Checks if the repeated capability collection has no elements
     *
     * @return true if the container is empty, false otherwise
     */
    bool empty() const
    {
        return mMap.empty();
    }

    /**
     * @brief Finds an repeated capability with physical name equivalent to key
     *
     * @param key physical name of the instance to search for
     * @return IRepCapCollectionT<T>::iterator Iterator to the repeated capability instance with name equivalent to key.
     *  If no such element is found, past-the-end (see end()) iterator is returned.
     */
    iterator find(const std::string& key) override
    {
		// Delete any IVI qualifier on key as in:  Channel!!Chan1
		auto _key = key;
		std::size_t found = _key.rfind("!");
		if (found != std::string::npos)
			_key.erase(0, found + 1);

		return iterator(mMap.find(_key), this);
	}

    /**
     * @brief Add an instance to the repeated capability collection
     *  The derived classes need to implement this method to created the concrete type instances
     * @param name physical name
     * @param isCustomAdded flag to indicate if this instance is added by customs on-the-fly
    */
    virtual void AddInstance(const std::string& name, bool isCustomAdded=true, bool isRemote=false) = 0;

    /**
     * @brief Remove an instance from the repeated capability collection
     * @param name physical name
     * @param isCustomAdded flag to indicate if this is to remove a custom added instance
     */
    void RemoveInstance(const std::string& name, bool isCustomAdded=true)
    {
        this->Erase(name, isCustomAdded);
    }
    /**
     * @brief Get dynamic repeated capability physical names
     * @param repCapName The name of the repeated capability
     * @param physicalNames Collection for the output physical names, new instances names will be added to this collection
    */
    virtual void GetDynamicRepCapNames(const std::string& repCapName, std::vector<std::string>& physicalNames) = 0;

    /**
     * @brief Get all custom added physical names
     * @return A set of string for all custom added physical names
    */
    KeyCollection GetCustomPhysicalNames() const
    {
        return mCustomPhysicalNames;
    }

    /**
     * @brief increment operation to the iterator
    */
    virtual void IncreaseIterator(iterator& iter) override
    {
        auto iterTrcker = std::find(mIndexTracker.begin(), mIndexTracker.end(), iter->first);
        if (++iterTrcker != mIndexTracker.end())
            iter = this->find(*iterTrcker);
        else
            iter = this->end();
    }

protected:
    /**
     * @brief Internal method for inserting an instance to the repeated capability collection.
     * @param value pair of <physicalName, RepCapInstance>
     * @param isCustomAdded flag to indicate if this instance is added by customs on-the-fly
    */
    std::pair<typename RepCapCollectionImplT<T>::map_iterator, bool> Insert(const value_type& value, bool isCustomAdded = true)
    {
        auto physicalName = value.first;
        if (!IsValidPhysicalName(physicalName))
        {
            auto errMsg = "Physical name '" + physicalName +
                "' invalid. Must only contain characters a-z, A-Z, 0-9, and _ with no spaces.";
            throw InvalidOperationException(errMsg);
        }

        if (find(physicalName) != end())
        {
            auto errMsg = "Physical name '" + physicalName +
                "' already exist in RepCap collection. Note the name is case insensitive.";
            throw InvalidOperationException(errMsg);
        }

        if (isCustomAdded)
        {
            mCustomPhysicalNames.insert(physicalName);
        }

        mIndexTracker.push_back(value.first);
        return mMap.insert(value);
    }
    /**
     * @brief Internal method for removing an instance from the repeated capability collection.
     * @param key repeated capability physical name
     * @param isCustomAdded flag to indicate if this instance is added by customs on-the-fly
    */
    size_type Erase(const key_type& key, bool isCustomAdded = true)
    {
        if (!IsExsitingPhysicalName(key))
        {
            auto errMsg = "Can't remove '" + key + "'. Physical name does not exist.";
            throw InvalidOperationException(errMsg);
        }

        if (isCustomAdded && !IsCustomAddedPhysicalName(key))
        {
            auto errMsg = "Can't remove '" + key + "'. Only custom added physical name can be removed.";
            throw InvalidOperationException(errMsg);
        }

        if (IsCustomAddedPhysicalName(key))
        {
            mCustomPhysicalNames.erase(key);
        }

        mIndexTracker.erase(std::remove(mIndexTracker.begin(), mIndexTracker.end(), key), mIndexTracker.end());
        return mMap.erase(key);
    }
    /**
     * @brief Check if the physical name is valid. A valid physical name only contains characters a-z, A-Z, 0-9, and _ with no spaces
     * @param physicalName
    */
    bool IsValidPhysicalName(const std::string& physicalName) const
    {
        std::regex reg("\\w+");
        return  std::regex_match(physicalName, reg);
    }
    /**
     * @brief Check if a given physical name is custom added
     * @param physicalName
    */
    bool IsCustomAddedPhysicalName(const std::string& physicalName)
    {
        return mCustomPhysicalNames.find(physicalName) != mCustomPhysicalNames.end();
    }
    /**
     * @brief Check if a given physical name exist by case SENSITIVE checking
     * @param physicalName
    */
    bool IsExsitingPhysicalName(const std::string& physicalName)
    {
        for (auto & elem : mMap)
        {
            if (elem.first == physicalName)
                return true;
        }
        return false;
    }

private:
    typename IRepCapCollectionT<T>::MapType mMap = {};
    KeyCollection mCustomPhysicalNames = {};
    std::vector<key_type> mIndexTracker = {};
};

}}
#endif // RCL_REP_CAP_COLLECTION_IMPL_T_H