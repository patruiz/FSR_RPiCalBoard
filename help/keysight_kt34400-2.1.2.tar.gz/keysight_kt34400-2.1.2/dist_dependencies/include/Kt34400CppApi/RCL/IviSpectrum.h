#ifndef RCL_IVI_SPECTRUM_H
#define RCL_IVI_SPECTRUM_H

/** 
 * Copyright Keysight Technologies 2020-2021
 *
 * @file IviSpectrum.h
 * @author NGC Team
 *  The default implementation of the C++ spectrum class. 
 *  Most of the methods follow the IVI specification but not all the methods in the Spec are implemented.
 
 */

#include "MeasurementData.h"

namespace Keysight {
namespace ApiCoreLibraries {


/**
 * @brief A template class to represent the Ivi.Spectrum<T>
 *
*/

template <typename T>
class IviSpectrum : public MeasurementData<T>
{  
    double mStartFrequency{ 0 };
    double mStopFrequency{ 0 };    

// Constructors
public:
    // Default constructor is needed for marshalers
    IviSpectrum() = default;

    IviSpectrum(const IviSpectrum& other)
    {
        *this = other;
    }

    // assignment operator function
    IviSpectrum& operator=(const IviSpectrum& other)
    {
        if (this != &other)
        {
            MeasurementData<T>::operator=(other);
            mStartFrequency = other.mStartFrequency;
            mStopFrequency = other.mStopFrequency;
        }
        return *this;
    }

    /**
     * @brief Initializes a new instance of the Ivi.Driver.Spectrum class.  This constructor initializes an empty spectrum. 
     * @param startFrequency The frequency of the first valid data point in the data array.
     * @param stopFrequency The frequency of the last valid data point in the data array     
     * @return New instance of an empty spectrum
     */
    IviSpectrum(double startFrequency, double stopFrequency)
        :IviSpectrum(startFrequency, stopFrequency, TimePoint{}, 0)
    {
    }

    /**
     * @brief Initializes a new instance of the Ivi.Driver.Spectrum class.  This constructor initializes an empty spectrum. 
     * @param startFrequency The frequency of the first valid data point in the data array.
     * @param stopFrequency The frequency of the last valid data point in the data array
     * @param capacity The capacity of the spectrum data array
     * @return New instance of an empty spectrum
     */
    IviSpectrum(double startFrequency, double stopFrequency, std::int64_t capacity)
        :IviSpectrum(startFrequency, stopFrequency, TimePoint{}, capacity)
    {
    }

    /**
     * @brief Initializes a new instance of the Ivi.Driver.Spectrum class.  This constructor initializes an empty spectrum. 
     * @param startFrequency The frequency of the first valid data point in the data array.
     * @param stopFrequency The frequency of the last valid data point in the data array
     * @param triggerTime The time of the trigger associated with the acquisition of the spectrum
     * @return New instance of an empty spectrum
     */
    IviSpectrum(double startFrequency, double stopFrequency, const TimePoint& triggerTime)
        :IviSpectrum(startFrequency, stopFrequency, triggerTime, 0)
    {
    }

    /**
     * @brief Initializes a new instance of the Ivi.Driver.Spectrum class.  This constructor initializes an empty spectrum. 
     * @param startFrequency The frequency of the first valid data point in the data array.
     * @param stopFrequency The frequency of the last valid data point in the data array
     * @param triggerTime The time of the trigger associated with the acquisition of the spectrum
     * @param capacity The capacity of the spectrum data array
     * @return New instance of an empty spectrum
     */
    IviSpectrum(double startFrequency, double stopFrequency, const TimePoint& triggerTime, std::int64_t capacity)
    {
        this->Configure_(startFrequency, stopFrequency, triggerTime, capacity);
    }

// Configure Methods
public:   

    /**
     * @brief The Configure method defines the frequency (implicit) axis and number of data points in the spectrum.  Because of
		the interaction between these values, they are set as a group with this method or when the spectrum is
		initially created.  If triggerTime is not specified,
		it defaults to Not A Time.  If validPointCount is not specified, the number of elements in the spectrum is not changed.
     * @param startFrequency The frequency of the first valid data point in the spectrum (required).
     * @param stopFrequency The frequency of the last valid data point in the spectrum (required).
     * @param triggerTime The time that this measurement was triggered.
     * @param validPointCount The actual number of elements in the spectrum.
     * @remarks The Configure method does not change any of the explicit data in the Spectrum.  The capacity of the spectrum does
		not change as a side effect of the Configure method.  If the validPointCount exceeds the data array size, an
		Insufficient Capacity exception is thrown.
     */
    void Configure(double startFrequency, double stopFrequency, const TimePoint& triggerTime, std::int64_t validPointCount)
    {
        this->ConfigureWithValidPointCount(startFrequency, stopFrequency, triggerTime, validPointCount);
    }

     /**
     * @brief The Configure method defines the frequency (implicit) axis and number of data points in the spectrum.  Because of
		the interaction between these values, they are set as a group with this method or when the spectrum is
		initially created.  If triggerTime is not specified, it defaults to Not A Time.  
     * @param startFrequency The frequency of the first valid data point in the spectrum (required).
     * @param stopFrequency The frequency of the last valid data point in the spectrum (required).
     * @param triggerTime The time that this measurement was triggered.     
     * @remarks The Configure method does not change any of the explicit data in the Spectrum.  The capacity of the spectrum does
		not change as a side effect of the Configure method.  
     */
    void Configure(double startFrequency, double stopFrequency, const TimePoint& triggerTime)
    {
        this->ConfigureWithValidPointCount(startFrequency, stopFrequency, triggerTime, this->mValidPointCount);
    }

    /**
     * @brief The Configure method defines the frequency (implicit) axis and number of data points in the spectrum.  Because of
		the interaction between these values, they are set as a group with this method or when the spectrum is
		initially created. If validPointCount is not specified, the number of elements in the spectrum is not changed.
     * @param startFrequency The frequency of the first valid data point in the spectrum (required).
     * @param stopFrequency The frequency of the last valid data point in the spectrum (required).
     * @param validPointCount The actual number of elements in the spectrum.
     * @remarks The Configure method does not change any of the explicit data in the Spectrum.  The capacity of the spectrum does
		not change as a side effect of the Configure method.  If the validPointCount exceeds the data array size, an
		Insufficient Capacity exception is thrown.
     */
    void Configure(double startFrequency, double stopFrequency, std::int64_t validPointCount)
    {
        this->ConfigureWithValidPointCount(startFrequency, stopFrequency, TimePoint{}, validPointCount);
    }

    /**
     * @brief The Configure method defines the frequency (implicit) axis and number of data points in the spectrum.  Because of
		the interaction between these values, they are set as a group with this method or when the spectrum is initially created.
     * @param startFrequency The frequency of the first valid data point in the spectrum (required).
     * @param stopFrequency The frequency of the last valid data point in the spectrum (required).
     * @remarks The Configure method does not change any of the explicit data in the Spectrum.  The capacity of the spectrum does
		not change as a side effect of the Configure method. 
     */
    void Configure(double startFrequency, double stopFrequency)
    {
        this->ConfigureWithValidPointCount(startFrequency, stopFrequency, TimePoint{}, this->mValidPointCount);
    }

    /**
     * @brief Additional Configure method.
     * @param startFrequency The frequency of the first valid data point in the data array.
     * @param stopFrequency The frequency of the last valid data point in the data array
     * @param triggerTime The time of the trigger associated with the acquisition of the spectrum
     * @param capacity The capacity of the spectrum data array
     */
    void Configure_(double startFrequency, double stopFrequency, const TimePoint& triggerTime, std::int64_t capacity)
    {
        this->mOffset = 0;
        this->mScale = 1.0;

        // Configure the empty spectrum
        this->SetCapacity(capacity);
        this->Configure(startFrequency, stopFrequency, triggerTime, 0);
    }    

    double GetFrequencyStep() const  
    { 
        if (this->mValidPointCount <= 1)
        {
	        // If there's no valid points or only 1, FrequencyStep is 0
	        return 0;
        }
        else
        {
	        return (mStopFrequency - mStartFrequency) / (double)(this->mValidPointCount - 1);
        }
    }

    double GetStartFrequency() const 
    { 
        return mStartFrequency;
    }

    double GetStopFrequency() const 
    { 
        return mStopFrequency;
    }
    
private:
    void ConfigureWithValidPointCount(double startFrequency, double stopFrequency, const TimePoint& triggerTime, std::int64_t validPointCount)
    {
        if (validPointCount < 0)
        {
            throw std::out_of_range("ValidPointCount cannot be negative");
        }
        if (validPointCount == 1 && startFrequency != stopFrequency)
        {
            throw std::out_of_range("Start frequency must equal stop frequency with one point");
        }
        if (validPointCount > this->mCapacity)
        {
            throw std::runtime_error("ValidPointCount cannot exceeds capacity");
        }
        this->mStartFrequency = startFrequency;
        this->mStopFrequency = stopFrequency;
        this->mTriggerTime = triggerTime;
        this->mValidPointCount = validPointCount;
    } 
};

}}
#endif // RCL_IVI_SPECTRUM_H