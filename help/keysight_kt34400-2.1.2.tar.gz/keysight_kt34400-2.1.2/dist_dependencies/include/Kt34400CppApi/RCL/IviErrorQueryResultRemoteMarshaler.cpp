#include "IviErrorQueryResultRemoteMarshaler.h"

using namespace Keysight::ApiCoreLibraries;

void IviErrorQueryResultRemoteMarshaler::BytesToCpp(MarshalBuffer& marshalBuffer, IviErrorQueryResult& result)
{
	std::int32_t code = 0;
	mInt32Marshaler.BytesToCpp(marshalBuffer, code);
	std::string message;
	mStringRemoteMarshaler.BytesToCpp(marshalBuffer, message);
	result = Keysight::ApiCoreLibraries::IviErrorQueryResult(code, message);
}

void IviErrorQueryResultRemoteMarshaler::CppToBytes(const IviErrorQueryResult& input, MarshalBuffer& marshalBuffer)
{
	mInt32Marshaler.CppToBytes(input.GetCode(), marshalBuffer);
	mStringRemoteMarshaler.CppToBytes(input.GetMessage(), marshalBuffer);
}

std::int32_t IviErrorQueryResultRemoteMarshaler::GetBufferSizeForRPC(const IviErrorQueryResult& input) const
{
	return mInt32Marshaler.GetBufferSize() + mStringRemoteMarshaler.GetBufferSizeForRPC(input.GetMessage());
}