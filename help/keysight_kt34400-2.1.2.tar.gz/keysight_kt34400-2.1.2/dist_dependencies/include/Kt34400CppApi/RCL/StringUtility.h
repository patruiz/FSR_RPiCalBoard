/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#ifndef RCL_STRING_UTILITY_H
#define RCL_STRING_UTILITY_H

/**
 * @file StringUtility.h
 * @author the Rooftop team
 *
 * this file defines some help methods for string manipulation in the namespace StringUtility
 */

#include <algorithm>
#include <cctype>
#include <iomanip>
#include <functional>
#include <limits>
#include <memory>    // For std::unique_ptr
#include <string>
#include <sstream>
#include <stdarg.h>  // For va_start, etc.
#include <vector>


using namespace std;

namespace Keysight {
namespace ApiCoreLibraries {

/**
*@brief A utility class with static methods for string processing
*
*/
namespace StringUtility{

constexpr int str_buf_size = 1024;

/**
 * @brief Removes all leading occurrences of a string.
 *
 * @param s the string to remove
 * @return std::string& The string that remains after all occurrences of the input string are removed
 */
inline std::string &Ltrim(std::string &s)
{
    s.erase(s.begin(), std::find_if(s.begin(), s.end(),
		[](int c) {return !std::isspace(c); }));
	//std::not1(std::ptr_fun<int, int>(std::isspace))));
    return s;
}

/**
 * @brief Removes all tailing occurrences of a string.
 *
 * @param s the string to remove
 * @return std::string& The string that remains after all occurrences of the input string are removed
 */
inline std::string &Rtrim(std::string &s)
{
    s.erase(std::find_if(s.rbegin(), s.rend(),
		[](int c) {return !std::isspace(c); }).base(), s.end());
	//std::not1(std::ptr_fun<int, int>(std::isspace))).base(), s.end());
    return s;
}

/**
 * @brief Removes all leading and tailing occurrences of a string.
 *
 * @param s the string to remove
 * @return std::string& The string that remains after all occurrences of the input string are removed
 */
inline std::string &Trim(std::string &s)
{
    return Ltrim(Rtrim(s));
}

// Split a std:string into an array

/**
 * @brief Returns a string array that contains the substrings in this instance that are delimited by a specified char.
 *
 * @param s the string to split
 * @param delim A char that delimits the input string
 * @param elems output vector of the delimited string
 * @return std::vector<std::string>& returns the reference of the vector of the delimited string
 */
std::vector<std::string> inline &Split(const std::string &s, char delim, std::vector<std::string> &elems)
{
    std::stringstream ss(s);
    std::string item;
    while (std::getline(ss, item, delim))
    {
        if (Trim(item).length() > 0)
        {
            elems.push_back(item);
        }
    }
    return elems;
}

/**
 * @brief Returns a string array that contains the substrings in this instance that are delimited by a specified char.
 *
 * @param s the string to split
 * @param delim A char that delimits the input string
 * @param elems output vector of the delimited string
 * @return std::vector<std::string>& returns the reference of the vector of the delimited string
 */
std::vector<std::string> inline &SplitWithoutTrim(const std::string &s, char delim, std::vector<std::string> &elems)
{
	std::stringstream ss(s);
	std::string item;
	elems.clear();
	while (std::getline(ss, item, delim))
	{
		elems.push_back(item);
	}
	return elems;
}

/**
 * @brief Change a std::string to upper case
 *
 * @param strToConvert string to be converted
 * @return string& the upper case string
 */
inline string &StrToUpper(string &strToConvert)
{
    for (unsigned int i = 0; i < strToConvert.length(); i++)
    {
        strToConvert[i] = static_cast<char>(toupper(strToConvert[i]));
    }
    return strToConvert;  // Return the converted string
}

/**
 * @brief Change a std::string to lower case
 *
 * @param strToConvert string to be converted
 * @return string& the lower case string
 */
inline string &StrToLower(string &strToConvert)
{
    for (unsigned int i = 0; i < strToConvert.length(); i++)
    {
        strToConvert[i] = static_cast<char>(tolower(strToConvert[i]));
    }
    return strToConvert;  // Return the converted string
}

/**
 * @brief Remove leading and trailing whitespace in a std::string
 *
 * @param strToTrim string to be trimmed
 * @return string& the string that all leading and tailing whitespaces removed
 */
inline string &StrTrim(string &strToTrim)
{
    size_t first = strToTrim.find_first_not_of(" \t");
    if (first == string::npos)
    {
        // strToTrim only contained whitespace
        strToTrim = "";
        return strToTrim;
    }
    size_t last = strToTrim.find_last_not_of(" \t\f\v\n\r");
    strToTrim = strToTrim.substr(first, (last - first + 1));
    return strToTrim;
}


/**
 * @brief Replace all occurrences of a substring in a std::string
 *
 * @param s the string be processed
 * @param search the string to be searched
 * @param replace the string to replace 'search'
 * @return string& the string after replaced
 */
inline string &StrReplace(string &s, const string &search, const string &replace)
{
    for (size_t pos = 0;; pos += replace.length())
    {
        pos = s.find(search, pos);
        if (pos == string::npos) break;
        s.erase(pos, search.length());
        s.insert(pos, replace);
    }
    return s;
}

/**
 * @brief Convert a float number to a string
 *
 * @tparam T the float number type
 * @tparam N precision
 * @param param input float value
 * @return std::string the output string
 */
template<typename T, int N>
std::string inline FloatToString(T param)
{
    std::ostringstream fixedStream;
    fixedStream << std::fixed << std::setprecision(N) << param;
    auto fixedStr = fixedStream.str();
    //trim trailing zeros.
    fixedStr.erase(fixedStr.find_last_not_of('0') + 1, std::string::npos);
    //trim decimal point
    if (fixedStr.back() == '.')
    {
        fixedStr.erase(fixedStr.size() - 1, 1);
    }

    std::ostringstream scientificStream;
    scientificStream << std::scientific << std::setprecision(N) << param;
    auto scientificStr = scientificStream.str();
    //trim trailing zeros.
    auto eIndex = scientificStr.find_last_of('e');
    auto start = scientificStr.find_last_not_of('0', eIndex - 1);
    scientificStr.erase(start + 1, eIndex - start - 1);
    //trim decimal point
    eIndex = scientificStr.find_last_of('e');
    if (scientificStr.at(eIndex - 1) == '.')
    {
        scientificStr.erase(eIndex - 1, 1);
    }

    if (fixedStr == "0")
    {
        return scientificStr;
    }

    return scientificStr.length() < fixedStr.length() ? scientificStr : fixedStr;
}

/**
 * @brief Check if the stream output operator is implemented for a type
 *
 * @tparam S : the stream type
 * @tparam T : the type to be checked
 */

template<typename S, typename T>
class is_streamable
{
    template<typename SS, typename TT>
    static auto test(int)
        -> decltype(std::declval<SS&>() << std::declval<TT>(), std::true_type());

    template<typename, typename>
    static auto test(...)->std::false_type;

public:
    static const bool value = decltype(test<S, T>(0))::value;
};

/**
 * @brief Output a variadic number of type value to a string
 *
 * @tparam Args types of the inputs
 * @param args values of the inputs
 * @return std::string the result string
 */
template< typename ... Args >
std::string inline Stringer(Args const& ... args)
{
    std::ostringstream stream;
    using List = int[];
    (void)List {
        0, ((void)(stream << args << ", "), 0) ...
    };
    // Remove the last ', '
    return stream.str().substr(0, stream.str().size() - 2);
}

/**
 * @brief Template method to print any type to a stream
 * @return std::enable_if_t<is_streamable<std::stringstream, X>::value>
 */
template<class X>
std::enable_if_t<is_streamable<std::stringstream, X>::value>
    PrettyPrint(std::ostream& o, const X& x)
{
    o << x;
}

template<class X>
std::enable_if_t<!is_streamable<std::stringstream, X>::value>
    PrettyPrint(std::ostream& o, const X& x)
{
    auto name = std::string(typeid(x).name());
    if (name.find("class ") == 0)
    {
        name = name.substr(6, name.length());
    }
    o << name << " object";
}

/**
 * @brief general implementation for KVStringer
 */
template<typename K1, typename V1>
std::string inline KVStringer(K1 k1, const V1& v1)
{
    std::ostringstream os;
    os << k1 << "=";
    PrettyPrint(os, v1);
    return os.str();
}


/**
* @brief base implementation for KVStringer
*/
std::string inline KVStringer()
{
    return "";
}

/**
 * @brief Template specialization for bool type, output 'True' for true and "False" for false
 */
template<>
std::string inline KVStringer<const char*, bool>(const char* k1, const bool& v1)
{
    std::ostringstream os;
    os << k1 << "=" << (v1 ? "True" : "False");
    return os.str();
}

/**
* @brief Template specialization for float
*/
template<>
std::string inline KVStringer<const char*, float>(const char* k1, const float& v1)
{
    std::ostringstream os;
    os << k1 << "=" << FloatToString<float, 7>(v1);
    return os.str();
}

/**
* @brief Template specialization for double
*/
template<>
std::string inline KVStringer<const char*, double>(const char* k1, const double& v1)
{
    std::ostringstream os;
    os << k1 << "=" << FloatToString<double, 15>(v1);
    return os.str();
}

/**
 * @brief KVStringer is a method that convert variadic number of key:value pair to string
 * The output string is "key1=value1, key2=value2,..."
 * This is the general implementation for KVStringer
 *
 * @tparam K1 type of key 1
 * @tparam V1 type of value 1
 * @tparam Rest the result of the parameters
 * @param k1 value of key 1
 * @param v1 value of value 1
 * @param rest the result of the parameters
 * @return std::string
 */
template<typename K1, typename V1, typename... Rest>
std::string inline KVStringer(K1 k1, V1 v1, const Rest&... rest)
{
    std::ostringstream os;
    os << KVStringer(k1, v1) << ", "<< KVStringer(rest...);
    return os.str();
}

/**
 * @brief Output a formatted string. This is a replacement for boost::format, by using std::snprintf().
 *
 * @tparam Args types of the inputs
 * @param formatter the formatter string
 * @param args values of the inputs
 * @return std::string the result string
 */
template< typename ... Args >
std::string inline StringFormat(const char * formatter, const Args&... args)
{
	char str[str_buf_size] = { 0 };
    snprintf(str, str_buf_size, formatter, args...);
    return std::string(str);
}

}
}}

#endif // RCL_STRING_UTILITY_H