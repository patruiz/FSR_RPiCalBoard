/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#ifndef RCL_ENUM_ANY_VECTOR_REMOTE_MARSHALER_H
#define RCL_ENUM_ANY_VECTOR_REMOTE_MARSHALER_H

 /**
  * @file AnyVectorRemoteMarshaler.h
  * @author the Rooftop team
  * defines the rpc marshaler class for AnyVector<EnumType>
  */
#include "ICustomMarshaler.h"
#include "BasicMarshaler.h"
#include "AnyVector.h"
#include <memory>
#include <chrono>
#include <exception>
#include <string>

namespace Keysight {
namespace ApiCoreLibraries {

template <class EnumType>
class EnumAnyVectorRemoteMarshaler : public ICustomMarshaler<Keysight::ModularInstruments::AnyVector<EnumType>>
{
public:
	void BytesToCpp(MarshalBuffer& marshalBuffer, Keysight::ModularInstruments::AnyVector<EnumType>& result) override
	{
		std::int64_t size;
		mInt64Marshaler.BytesToCpp(marshalBuffer, size);
		if (size != result.getSpan().size())
		{
			result.resize(static_cast<size_t>(size));
		}

		for (int64_t index = 0; index < size; index++)
		{
			std::int32_t value;
			mDataMarshaler.BytesToCpp(marshalBuffer, value);
			result.getSpan().data()[index] = static_cast<EnumType>(value);
		}
	}

	void CppToBytes(const Keysight::ModularInstruments::AnyVector<EnumType>& input, MarshalBuffer& marshalBuffer) override
	{
		// first marshal the size of data in anyvector
		mInt64Marshaler.CppToBytes(static_cast<std::int64_t>(input.getSpan().size()), marshalBuffer);
		for (int64_t index = 0; index < input.getSpan().size(); index++)
		{
			mDataMarshaler.CppToBytes(static_cast<std::int32_t>(input.getSpan().data()[index]), marshalBuffer);
		}
	}

	std::int32_t GetBufferSize() const
	{
		throw std::runtime_error("Should not be called here.");
	}

	std::int32_t GetBufferSizeForRPC(const Keysight::ModularInstruments::AnyVector<EnumType>& input) const override
	{
		return static_cast<std::int32_t>(sizeof(std::int64_t) + input.getSpan().size() * sizeof(std::int32_t));
	}

private:
	BasicMarshaler<std::int64_t> mInt64Marshaler;
	BasicMarshaler<std::int32_t> mDataMarshaler;
};

} //namespace ApiCoreLibraries
} //namespace Keysight

#endif // RCL_ENUM_ANY_VECTOR_REMOTE_MARSHALER_H