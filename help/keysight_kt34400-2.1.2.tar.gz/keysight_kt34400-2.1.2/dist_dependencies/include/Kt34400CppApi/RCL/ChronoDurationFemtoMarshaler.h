/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#ifndef RCL_CHRONO_DURATION_FEMTO_MARSHALER_H
#define RCL_CHRONO_DURATION_FEMTO_MARSHALER_H

/**
 * @file ChronoDurationFemtoMarshaler.h
 * @author the Rooftop team
 * defines the marshaler class for std::chrono::duration<int64_t, std::femto>
 */

#include "BasicMarshaler.h"
#include <memory>
#include <chrono>


namespace Keysight {
namespace ApiCoreLibraries {

using DurationInt64Femto = std::chrono::duration<int64_t, std::femto>;

/**
 *@brief marshaler class for std::chrono::duration<int64_t, std::femto>
*/
class ChronoDurationFemtoMarshaler : public ICustomMarshaler<DurationInt64Femto>
{
public:
    void BytesToCpp(MarshalBuffer& marshalBuffer, DurationInt64Femto& result) override;
    void CppToBytes(const DurationInt64Femto& input, MarshalBuffer& marshalBuffer) override;
    std::int32_t GetBufferSize() const override;

private:
    BasicMarshaler<double> mDoubleMarshaler;
};

}}
#endif // RCL_CHRONO_DURATION_FEMTO_MARSHALER_H