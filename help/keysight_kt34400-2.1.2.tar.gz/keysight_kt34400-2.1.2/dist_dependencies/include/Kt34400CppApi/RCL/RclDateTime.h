#ifndef RCL_DATE_TIME_H
#define RCL_DATE_TIME_H

/** 
 * Copyright Keysight Technologies 2020-2021
 *
 * @file RclDateTime.h
 * @author NGC Team
 *  Defines the data time and time span type used in Rooftop driver 
 
 */

#include <chrono>


namespace Keysight{
namespace ApiCoreLibraries{

using TimePoint = std::chrono::system_clock::time_point;
using Duration = std::chrono::duration<double, std::ratio<1, 1>>;

}}

#endif // RCL_DATE_TIME_H