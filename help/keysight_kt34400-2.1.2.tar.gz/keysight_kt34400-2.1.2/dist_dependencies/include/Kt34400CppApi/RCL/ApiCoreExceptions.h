/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#ifndef RCL_API_CORE_EXCEPTIONS_H
#define RCL_API_CORE_EXCEPTIONS_H

/**
 * @file ApiCoreExceptions.h
 * @author the Rooftop team
 * this file defines the exceptions thrown by Rooftop class library, below exceptions are defined:
 *  - ApiCoreException: base class for all those other exceptions
 *  - InvalidRepCapSelector
 *  - InvalidRepCapIdentifier
 *  - InvalidOperationException
 *  - CreateCmiFailException
 *  - NullPointerException
 *  - OperationNotSupportedException
 */

#include <stdexcept>
#include <sstream>

namespace Keysight {
namespace ApiCoreLibraries {

/**
*@brief Base class for exceptions defined in ApiCoreLibraries
*/
class ApiCoreException :public std::runtime_error
{
public:
    /**
     * @brief Construct a ApiCoreException
     *
     * @param msg exception message
     */
    ApiCoreException(const std::string& msg)
        : std::runtime_error(msg.c_str())
        , mMsg(msg)
    {
    }

    virtual const char* what() const throw() override
    {
        return mMsg.c_str();
    }
protected:
    std::string mMsg;
};

/**
 * @brief InvalidRepCapSelector exception
 *
 */
class InvalidRepCapSelector :public ApiCoreException
{
public:
    /**
     * @brief Construct a new InvalidRepCapSelector exception
     *
     * @param selector selector name
     * @param comment exception comment
     */
    InvalidRepCapSelector(const std::string& selector, const std::string comment = "")
        : ApiCoreException(selector)
    {
        mMsg = "Repeated Capability selector '" + selector + "' is invalid.";
        if (comment != "")
        {
            mMsg += (" " + comment + ".");
        }
    }
};


/**
 * @brief InvalidRepCapIdentifier exception class
 *
 */
class InvalidRepCapIdentifier :public ApiCoreException
{
public:
    /**
     * @brief Construct a new InvalidRepCapIdentifier object
     *
     * @param name repeated capability identifier
     * @param repcapName the repeated capability name
     */
    InvalidRepCapIdentifier(const std::string& name, const std::string repcapName = "")
        : ApiCoreException(name)
    {
        mMsg = "Repeated Capability name '" + name + "' is invalid for repeated capability '" + repcapName + "'.";
    }
};

/**
 * @brief InvalidOperationException exception class
 *
 */
class InvalidOperationException :public ApiCoreException
{
public:
    /**
     * @brief Construct a new InvalidOperationException object
     *
     * @param msg
     */
    InvalidOperationException(const std::string& msg)
        : ApiCoreException(msg)
    {
    }
};

/**
 * @brief CreateCmiFailException exception class
 *
 */
class CreateCmiFailException :public ApiCoreException
{
public:
    /**
     * @brief Create a CreateCmiFailException object
     *
     * @param msg error message
     */
    CreateCmiFailException(const std::string& msg)
        : ApiCoreException(msg)
    {
    }
};

/**
 * @brief NullPointerException class
 *
 */
class NullPointerException :public ApiCoreException
{
public:
    /**
     * @brief Construct a new NullPointerException object
     *
     * @param msg error message
     */
    NullPointerException(const std::string& msg)
        : ApiCoreException(msg)
    {
    }

    /**
     * @brief Construct a NullPointerException object
     *
     * @param msg
     */

    NullPointerException(const char* msg)
        : ApiCoreException(msg)
    {
    }
};

/**
 * @brief OperationNotSupportedException class
 *
 */

class OperationNotSupportedException : public ApiCoreException
{
public:
    /**
     * @brief Construct a new OperationNotSupportedException object
     *
     * @param msg error message
     */
    OperationNotSupportedException(const std::string& msg)
        : ApiCoreException(msg)
    {
    }

    /**
     * @brief Construct a new OperationNotSupportedException object
     *
     * @param msg error message
     */
    OperationNotSupportedException(const char* msg)
        : ApiCoreException(msg)
    {
    }
};

}}
#endif // RCL_API_CORE_EXCEPTIONS_H