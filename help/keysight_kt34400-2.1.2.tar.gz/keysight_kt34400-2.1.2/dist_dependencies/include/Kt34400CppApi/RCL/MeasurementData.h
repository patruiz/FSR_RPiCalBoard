#ifndef RCL_MEASUREMENT_DATA_H
#define RCL_MEASUREMENT_DATA_H

/** 
 * Copyright Keysight Technologies 2020-2021
 *
 * @file MeasurementData.h
 * @author NGC Team
 *  Defines the MeasurementData class, containing mesurement data comment properties
 
 */
#include "AnyVector.h"
#include "RclDateTime.h"
#include <vector>
#include <chrono>
#include <cmath>

namespace Keysight {
namespace ApiCoreLibraries {

template <typename T>
class MeasurementData
{
protected:
    // Initialized to invalid status, from if it is valid status, to check if data span is used or vector is used
    Keysight::ModularInstruments::AnyVector<T> mDataSpan{ Keysight::ModularInstruments::AnyVector<T>(nullptr, 0, (Keysight::ModularInstruments::AnyVectorAllocationCallback)nullptr) };
    std::vector<T> mData{};
    std::int64_t mCapacity{ 0 };
    std::int64_t mFirstValidPoint{ 0 };
    double mOffset{ 0 };
    double mScale{ 1 };
    TimePoint mTriggerTime;
    std::int64_t mValidPointCount{ 0 };

public:
    MeasurementData() = default;

    MeasurementData(const MeasurementData& other)
    {
        *this = other;
    }

    // assignment operator function
    MeasurementData& operator=(const MeasurementData& other)
    {
        if (this != &other)
        {           
            mFirstValidPoint = other.mFirstValidPoint;
            mOffset = other.mOffset;
            mScale = other.mScale;
            mTriggerTime = other.mTriggerTime;
            mValidPointCount = other.mValidPointCount;

            // Need to use SetCapacity instead of directly set the value
            this->SetCapacity(other.mCapacity);
            this->CopyData(other);
        }
        return *this;
    }

    /**
     *@brief GetAllElements returns a copy of the entire data array in the template data type.Note that for scaled(that
        is, integer) types, the scaling must be applied to the returned data elements to convert them to physical
        values by the calling program.
     * @return A copy of the entire data array in the template data type.
     */
    std::vector<T> GetAllElements() const
    {
        return this->GetElements(0, mCapacity);
    }

    /**
     * @brief GetElements returns a copy of a portion of the entire data array in the template data type, starting at the
        specified index and including the number of elements specified by count.  Note that for scaled (that
        is, integer) types, the scaling must be applied to the returned data elements to convert them to physical
     * @param index The index in the spectrum that will be the first element in the returned array.  That is,
        element zero in the returned array is at this index in the spectrum..
     * @param count The number of elements to be returned.
     * @return A copy of a portion of the entire data array in the template data type, starting at the specified
        index and including the number of elements specified by count.
     */
    std::vector<T> GetElements(std::int64_t index, std::int64_t count) const
    {
        if (index + count <= mCapacity)
        {
            std::vector<T> data((std::size_t)(count));
            if (this->IsDataSpan())
            {
                std::copy(mDataSpan.getSpan().begin(), mDataSpan.getSpan().begin() + (std::size_t)(count), data.begin());
            }
            else
            {
                std::copy(mData.begin(), mData.begin() + (std::size_t)(count), data.begin());
            }
            return data;
        }
        else
        {
            throw std::invalid_argument("Index and count exceed the capacity when GetElements");
        }
    }

    /**
     * @brief PutElements sets all or part of the data array in a spectrum, starting at beginning.
        If the array passed extends beyond the end of the spectrum, an ArgumentException
        will be thrown.  The implicit axis of the spectrum is not changed by PutElements.
     * @param data The data to be placed into the spectrum array.
     */
    void PutElements(const std::vector<T>& data)
    {
        this->PutElements(0, data);
    }

    /**
     * @brief PutElements sets all or part of the data array in a spectrum, starting at the element specified by index, or
        (by default, if index is not used) at the beginning of the array.  index is the first element of the spectrum
        data array to receive the new data.  If the array passed extends beyond the end of the spectrum, an ArgumentException
        will be thrown.  The implicit axis of the spectrum is not changed by PutElements.
     * @param index The index of the first element of the data array to change.
     * @param data The data to be placed into the spectrum array.
     */
    void PutElements(std::int64_t index, const std::vector<T>& data)
    {
        if (mCapacity < index + static_cast<std::int64_t>(data.size()))
        {
            this->SetCapacity(index + data.size());
        }

        if (this->IsDataSpan())
        {
            std::copy(data.begin(), data.end(), mDataSpan.getSpan().begin() + (std::size_t)(index));
        }
        else
        {
            std::copy(data.begin(), data.end(), mData.begin() + (std::size_t)(index));
        }
    }
    /**
     * @brief This returns the reference to the data element at the specified index in the spectrum.  Note that for scaled (that is,
        integer) types, the scaling must be applied to the returned data element to convert it to a physical value
        by the calling program.
     * @param index The index of the data element to be returned from the spectrum array.
     * @return the reference to the data element
     */

    T& operator[](std::uint64_t pos)
    {
        if (this->IsDataSpan())
        {
            return mDataSpan.getSpan()[(std::size_t)(pos)];
        }
        else
        {
            return mData[(std::size_t)(pos)];
        }
    }

    Keysight::ModularInstruments::AnyVector<T> GetDataSpan() const
    {
        return mDataSpan;
    }

    void SetDataSpan(const Keysight::ModularInstruments::AnyVector<T>& value)
    {
        mDataSpan = value;
    }

    std::vector<T> GetData() const
    {
        return mData;
    }

    void SetData(const std::vector<T>& data)
    {
        mData = data;
        this->SetCapacity(data.size());
    }

    std::int64_t GetCapacity() const
    {
        return mCapacity;
    }

    void SetCapacity(std::int64_t value)
    {
        if (mCapacity != value)
        {
            mCapacity = value;

            // if it is using data span (from .NET or Python), resize the span, otherwise (c++) resize the vector
            if (this->IsDataSpan())
            {
                if (value != static_cast<std::int64_t>(mDataSpan.size()))
                {
                    mDataSpan.resize(size_t(value));
                }
            }
            else
            {
                if (value != static_cast<std::int64_t>(mData.size()))
                {
                    mData.resize(size_t(value));
                }
            }

            if (mFirstValidPoint >= mCapacity)
            {
                // If a reduction in capacity would cause FirstValidPoint to be invalid, it will be set both ValidPointCount and FirstValidPoint to zero. 
                mFirstValidPoint = 0;
                mValidPointCount = 0;
            }
            else if (mFirstValidPoint + mValidPointCount >= mCapacity)
            {
                // If a reduction in capacity is would cause only ValidPointCount to be invalid, it will be reduced to fit within the capacity.
                mValidPointCount = mCapacity - mFirstValidPoint;
            }
        }
    }

    std::int64_t GetFirstValidPoint() const
    {
        return mFirstValidPoint;
    }

    void SetFirstValidPoint(std::int64_t value)
    {
        if (value < 0)
        {
            throw std::out_of_range("FirstValidPoint must be positive");
        }
        // - To allow marshal from invalid data, check only if capacity != 0        
        if (mCapacity != 0 && value >= mCapacity)
        {
            throw std::invalid_argument("FirstValuePoint must be less than capacity");
        }
        mFirstValidPoint = value;
    }

    double GetOffset() const
    {
        return mOffset;
    }

    void SetOffset(double value)
    {
        if (std::is_floating_point<T>::value)
        {
            throw std::runtime_error("Invalid operation: Offset cannot be set because it is fixed in floating point spectrum");
        }
        if (std::isnan(value) || std::isinf(value))
        {
            throw std::out_of_range("Offset cannot be Nan or Inf");
        }
        mOffset = value;
    }

    double GetScale() const
    {
        return mScale;
    }

    void SetScale(double value)
    {
        if (std::is_floating_point<T>::value)
        {
            throw std::runtime_error("Invalid operation: Scale cannot be set because it is fixed in floating point spectrum");
        }
        if (std::isnan(value) || std::isinf(value))
        {
            throw std::out_of_range("Scale cannot be Nan or Inf");
        }
        mScale = value;
    }

    TimePoint GetTriggerTime() const
    {
        // return mValidPointCount == 0 ? TimePoint{} : mTriggerTime;
        return mTriggerTime;
    }

    void SetTriggerTime(const TimePoint& value)
    {
        mTriggerTime = value;
    }

    std::int64_t GetValidPointCount() const
    {
        return mValidPointCount;
    }

    void SetValidPointCount(std::int64_t value)
    {
        if (value < 0)
        {
            throw std::out_of_range("ValidPointCount cannot be negative");
        }
        if (value > (mCapacity - mFirstValidPoint))
        {
            throw std::runtime_error("ValidPointCount cannot exceeds capacity");
        }
        mValidPointCount = value;
    }

protected:
    /**
    * @brief Return True if data span is used otherwise False
    */
    bool IsDataSpan() const
    {
        return mDataSpan.isResizable();
    }

    void CopyData(const MeasurementData& other)
    {
        if (this->IsDataSpan())
        {
            if (other.IsDataSpan())
            {
                std::copy(other.mDataSpan.getSpan().begin(), other.mDataSpan.getSpan().end(), this->mDataSpan.getSpan().begin());
            }
            else
            {
                std::copy(other.mData.begin(), other.mData.end(), this->mDataSpan.getSpan().begin());
            }
        }
        else
        {
            if (other.IsDataSpan())
            {
                mData = std::vector<T>(other.mDataSpan.getSpan().begin(), other.mDataSpan.getSpan().end());
            }
            else
            {
                mData = other.mData;
            }
        }
    }
};

}}


#endif // RCL_MEASUREMENT_DATA_H