/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#ifndef RCL_STREAM_HELPER_H
#define RCL_STREAM_HELPER_H

/**
 * @file StreamHelper.h
 * @author the Rooftop team
 *
 * this file defines overloading of the output stream operator << for some basic types
 */

#include "AnyVector.h"
#include <iostream>
#include <chrono>
#include <time.h>
#include <vector>

constexpr int maxLogElement = 64;

namespace std {
/**
 * @brief Overloading stream insertion (<>) operators for std::vector<T>
 *  output example : vector(5){1 2 3 4 5}
 *  if the size is too large, only the first 20 elements are listed.
 * @return std::ostream&
 */
template < class T >
inline std::ostream& operator << (std::ostream& os, const std::vector<T>& v)
{
    const int limit = maxLogElement;
    os << "vector(" << v.size() << "){";
    int n = 1;
    for (auto ii = v.begin(); ii != v.end(); ++ii, ++n)
    {
        os << " " << *ii;
        if (n >= limit)
        {
            os << " ...";
            break;
        }
    }
    os << " }";
    return os;
}

/**
 * @brief overloading of the stream output operator for std::chrono::system_clock::time_point
 *
 * @param os Output stream object where characters are inserted
 * @param v the ValueObject inserted
 * @return std::ostream& The ostream object (os)
 */
inline std::ostream& operator << (std::ostream& os, const std::chrono::system_clock::time_point& v)
{
    auto t = std::chrono::system_clock::to_time_t(v);
    struct tm tmBuf;

#ifdef _WIN32
    localtime_s(&tmBuf, &t);
#else
    localtime_r(&t, &tmBuf);
#endif

    char buff[128];
    strftime(buff, sizeof buff, "%c", &tmBuf);
    os << buff;
    return os;
}

/**
 * @brief overloading of the stream output operator for std::chrono::duration<double, std::ratio<1, 1>>
 *
 * @param os Output stream object where characters are inserted
 * @param v the ValueObject inserted
 * @return std::ostream& The ostream object (os)
 */
inline std::ostream& operator << (std::ostream& os, const std::chrono::duration<double, std::ratio<1, 1>>& v)
{
    os << v.count() << "s";
    return os;
}

} // end of namespace std


namespace Keysight{
namespace ModularInstruments{

/**
 * @brief Overloading stream insertion (<>) operators for AnyVector<T>
 *  output example : AnyVector(5){1 2 3 4 5}
 *  if the size is too large, only the first 20 elements are listed.
 *
 * @tparam T element type of AnyVector<T>
 * @param os Output stream object where characters are inserted
 * @param v the value object inserted
 * @return std::ostream& The ostream object (os)
 */
template < class T >
inline std::ostream& operator << (std::ostream& os, const Keysight::ModularInstruments::AnyVector<T> v)
{
    const int limit = maxLogElement;
    os << "AnyVector(" << v.size() << "){";
    int n = 1;
    for (auto ii = v.getSpan().begin(); ii != v.getSpan().end(); ++ii, ++n)
    {
        os << " " << *ii;
        if (n >= limit)
        {
            os << " ...";
            break;
        }
    }
    os << " }";
    return os;
}

}}

#endif // RCL_STREAM_HELPER_H