#include "ResourceName.h"
#include <algorithm>
#include <cctype>

using namespace Keysight::ApiCoreLibraries;

const std::string validIpv4Address =
    "^(rpc|kdi)://("										// starting with rpc:// or kdi://
    "(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])"
	"(:[0-9]+)?)/";											// optional port number

const std::string validIpv6Address =
	"^(rpc|kdi)://("										// starting with rpc:// or kdi://
    "\\[("
    "([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|"				// 1:2:3:4:5:6:7:8
    "([0-9a-fA-F]{1,4}:){1,7}:|"							// 1::                              1:2:3:4:5:6:7::
    "([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|"			// 1::8             1:2:3:4:5:6::8  1:2:3:4:5:6::8
    "([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|"		// 1::7:8           1:2:3:4:5::7:8  1:2:3:4:5::8
    "([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|"		// 1::6:7:8         1:2:3:4::6:7:8  1:2:3:4::8
    "([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|"		// 1::5:6:7:8       1:2:3::5:6:7:8  1:2:3::8
    "([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|"		// 1::4:5:6:7:8     1:2::4:5:6:7:8  1:2::8
    "[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|"			// 1::3:4:5:6:7:8   1::3:4:5:6:7:8  1::8
    ":((:[0-9a-fA-F]{1,4}){1,7}|:)|"						// ::2:3:4:5:6:7:8  ::2:3:4:5:6:7:8 ::8       ::
    "fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|"		// fe80::7:8%eth0   fe80::7:8%1     (link-local IPv6 addresses with zone index)
    "::(ffff(:0{1,4}){0,1}:){0,1}"
    "((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\\.){3,3}"
    "(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|"				// ::255.255.255.255   ::ffff:255.255.255.255  ::ffff:0:255.255.255.255  (IPv4-mapped IPv6
															// addresses and IPv4-translated addresses)
    "([0-9a-fA-F]{1,4}:){1,4}:"
    "((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\\.){3,3}"
    "(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])"				// 2001:db8:3:4::192.0.2.33  64:ff9b::192.0.2.33 (IPv4-Embedded IPv6 Address)
    ")\\]"
	"(:[0-9]+)?)/";											// optional port number

const std::string validHostname =
	"^(rpc|kdi)://("										// starting with rpc:// or kdi://
    "(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\\-]*[a-zA-Z0-9])\\.)*([A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9\\-]*[A-Za-z0-9])"
	"(:[0-9]+)?)/";											// optional port number

ResourceName::ResourceName(const std::string& str)
    :mFullResourceName(str)
{
    this->Parse();    
}

bool ResourceName::HasRemoteHost() const
{
    return mHasRemote;
}

bool ResourceName::IsKdiRemote() const
{
    return mIsKdiRemote;
}

std::string ResourceName::GetRemoteHost() const
{
    return mRemoteHost;
}

std::string ResourceName::GetLocalAddress() const
{
    return mLocalAddress;
}

void ResourceName::Parse()
{
	/**
	 * Three formats for resource name:
	 * 1. <visa_address_or_logical_name>
	 * 2. kdi://<host_name_or_ip>/<visa_address_or_logical_name>
	 * 3. rpc://<host_name_or_ip>:<port>/<visa_address_or_logical_name>
	 */

    // Trim spaces
    mFullResourceName.erase(0, mFullResourceName.find_first_not_of(" "));
    mFullResourceName.erase(mFullResourceName.find_last_not_of(" ") + 1);

    if (!IsEqualIgnoreCase(mFullResourceName.substr(0, 6), "rpc://") && !IsEqualIgnoreCase(mFullResourceName.substr(0, 6), "kdi://"))
    {
        mHasRemote = false;
        mLocalAddress = mFullResourceName;
        return;
    }

    std::string regStrs[] = {validIpv4Address, validHostname, validIpv6Address};
    for(auto& regStr : regStrs)
    {
        std::regex re(regStr, std::regex::icase);
        std::smatch match;
        if (std::regex_search(mFullResourceName, match, re) && match.size() > 2)
        {
            std::string proto = match[1];
			auto portMatch = match[match.size() - 1];
			if (IsEqualIgnoreCase(proto, "rpc") && !portMatch.matched)
			{
				throw std::invalid_argument(mFullResourceName + " doesn't specify port number.");
			}
			if (IsEqualIgnoreCase(proto, "kdi") && portMatch.matched)
			{
				// Warning message seems to be better than exception. Make the check strict for now.
				throw std::invalid_argument(mFullResourceName + " specifies port number.");
			}
			mRemoteHost = match[2];
			mLocalAddress = match.suffix();
            mHasRemote = true;
            mIsKdiRemote = IsEqualIgnoreCase(proto, "kdi");
            return;
        }
    }
    
    // If none of the 3 patterns are matched, then it is an invalid input
    throw std::invalid_argument(mFullResourceName + " doesn't comply with the format requirement.");
}

bool ResourceName::IsEqualIgnoreCase(const std::string& lfs, const std::string& rhs) const
{
    return std::equal(lfs.begin(), lfs.end(), rhs.begin(), rhs.end(),
            [](char a, char b) { return std::tolower(a) == std::tolower(b); });
}