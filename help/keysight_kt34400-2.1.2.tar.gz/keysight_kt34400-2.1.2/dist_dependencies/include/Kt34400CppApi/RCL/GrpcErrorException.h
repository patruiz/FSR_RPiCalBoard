/******************************************************
 *       Copyright Keysight Technologies 2018-2019
 ******************************************************/
#ifndef RCL_GRPC_ERROR_EXCEPTION_H
#define RCL_GRPC_ERROR_EXCEPTION_H

/**
 * @file GrpcErrorException.h
 * @author the Rooftop team
 * this file defines the exception class for Grpc errors
 */
#include <exception>
#include <string>

namespace Keysight {
namespace ApiCoreLibraries {

/**
*@brief exception class for all Grpc errors
*/
class GrpcErrorException :public std::runtime_error
{
public:
    /**
     * @brief Construct a GrpcErrorException
     *
     * @param msg exception message
     * @param code grpc status code
     */
    GrpcErrorException(const std::string& msg, int code = 0)
        : std::runtime_error(msg)
        , mMsg(msg)
        , mCode(code)
    {
        if (mCode != 0)
        {
            mMsg = std::to_string(mCode) + "#" + mMsg;
        } 
    }

    const char* what() const throw() override
    {
        return mMsg.c_str();
    }

private:
    std::string mMsg;
    int mCode;
};

}}
#endif // RCL_GRPC_ERROR_EXCEPTION_H