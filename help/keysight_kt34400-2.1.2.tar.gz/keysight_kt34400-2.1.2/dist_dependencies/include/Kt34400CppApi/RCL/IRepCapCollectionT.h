/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#ifndef RCL_I_REP_CAP_COLLECTION_T_H
#define RCL_I_REP_CAP_COLLECTION_T_H


/**
 * @file IRepCapCollectionT.h
 * @author the Rooftop team
 *
 * defines interface IRepCapCollectionT, which is the base class for repeated capability collection Pimpl class
 */

#include <map>

namespace Keysight {
namespace ApiCoreLibraries {

/**
 *@brief Case insensitive string comparison function object to use for repeated capability names
 */
struct RepCapKeyCILess
{
    // case-independent (ci) compare_less binary function
    struct nocase_compare
    {
        bool operator() (const unsigned char& c1, const unsigned char& c2) const {
            return tolower(c1) < tolower(c2);
        }
    };

    bool operator() (const std::string & s1, const std::string & s2) const {
        return std::lexicographical_compare
        (s1.begin(), s1.end(),   // source range
            s2.begin(), s2.end(),   // dest range
            nocase_compare());  // comparison
    }
};

/**
 *@brief template interface for repeated capability collection.
 * Basically the methods of this class is designed to be a sub-set of std::map with only some necessary read-only methods.
 *@note The method naming convention with this class follows the stl-style, not aligned with other files in this project.
 *@tparam T the repeated capability type.
*/
template <class T>
class IRepCapCollectionT
{
public:

    ///Member types
    typedef typename std::map<std::string, T, RepCapKeyCILess> MapType;
    typedef typename MapType::iterator map_iterator;

    /**
     *@brief interator used to iterate the elements by the order they are inserted
     * all the members flowing the behaviors for STL iterator
    */
    // - Remove the inheritance from std::iterator to supress the warning in C++17
    // - https://stackoverflow.com/questions/43268146/why-is-stditerator-deprecated
    //class ordered_iterator : public std::iterator<std::input_iterator_tag, typename map_iterator::value_type>
    class ordered_iterator
    {
        map_iterator mMapIterator;
        IRepCapCollectionT* mCollection;
        using _Ty = typename map_iterator::value_type;

    public:

        using iterator_category = std::input_iterator_tag;
        using value_type = _Ty;
        using difference_type = ptrdiff_t;
        using pointer = _Ty*;
        using reference = _Ty&;

        ordered_iterator(map_iterator s, IRepCapCollectionT* c) : mMapIterator(s), mCollection(c) {}
        typename MapType::reference operator*() { return *mMapIterator; }
        typename MapType::pointer operator->() { return &(*mMapIterator); }
        ordered_iterator& operator++() { mCollection->IncreaseIterator(*this); return *this; }
        ordered_iterator operator++(int) { ordered_iterator retval = *this; ++(*this); return retval; }
        bool operator==(ordered_iterator other) const { return mMapIterator == other.mMapIterator; }
        bool operator!=(ordered_iterator other) const { return !(*this == other); }
    };

    typedef ordered_iterator iterator;
    typedef typename MapType::const_iterator const_iterator;
    typedef typename MapType::reference reference;
    typedef typename MapType::size_type size_type;
    typedef typename MapType::value_type value_type;
    typedef typename MapType::mapped_type mapped_type;
    typedef typename MapType::key_type key_type;

    //Element access
    /**
     * @brief Operator [] for read-only access,
      * Note that new instance will NOT be inserted if the key doesn't exist
     * @param key instance name (case insensitive)
     */
    virtual T& operator[] (const std::string & key) = 0;

    /**
     * @brief Get the reference of instance by repeated capability instance name
     * @param key instance name (case insensitive)
     */
    virtual T& Get(const std::string & key) = 0;

    /**
     * @brief Get the reference of instance by index, the order the indexes is the order they were added
     *  If the index is out of range, an InvalidOperationException will be thrown
     * @param index the index of the instance
     */
    virtual T& Get(std::int32_t index) = 0;

    /**
     * @brief Get the repeated capability instance name by index, the order the indexes is the order they were added
     *  If the index is out of range, an InvalidOperationException will be thrown
     * @param index the index of the instance
    */
    virtual std::string GetName(std::int32_t index) = 0;

    /**
     * @brief Returns the number of repeated capabilities in this collection
     *
     * @return IRepCapCollectionT<T>::size_type The number of elements in the collection.
     */
    virtual size_type size() const = 0;

    /**
     * @brief Returns an iterator to the first element of the container.
     *
     * @return IRepCapCollectionT<T>::iterator Iterator to the first element
     */
    virtual iterator begin() = 0;

     /**
     * @brief Returns an iterator to the element following the last element of the container.
     *
     * @return IRepCapCollectionT<T>::iterator Iterator to the element following the last element.
     */
    virtual iterator end() = 0;

    /**
     * @brief Finds an repeated capability with physical name equivalent to key
     *
     * @param key physical name of the instance to search for
     * @return IRepCapCollectionT<T>::iterator Iterator to the repeated capability instance with name equivalent to key.
     *  If no such element is found, past-the-end (see end()) iterator is returned.
     */
    virtual iterator find(const std::string& key) = 0;

     /**
     * @brief increment the given iterator
     *
     * @param iter the current iterator
     */
    virtual void IncreaseIterator(iterator& iter) = 0;

};

}}
#endif // RCL_I_REP_CAP_COLLECTION_T_H