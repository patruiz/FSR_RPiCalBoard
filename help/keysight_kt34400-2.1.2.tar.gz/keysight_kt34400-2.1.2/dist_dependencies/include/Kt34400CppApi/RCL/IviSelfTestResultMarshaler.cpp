/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#include "IviSelfTestResultMarshaler.h"
#include "BasicMarshaler.h"

using namespace Keysight::ApiCoreLibraries;

void IviSelfTestResultMarshaler::BytesToCpp(MarshalBuffer& marshalBuffer, SelfTestResult& result)
{
    int32_t code;
    std::string message;

    mInt32Marshaler.BytesToCpp(marshalBuffer, code);
    mStringMarshaler.BytesToCpp(marshalBuffer, message);
    result = SelfTestResult(code, message);
}


void IviSelfTestResultMarshaler::CppToBytes(const SelfTestResult& input, MarshalBuffer& marshalBuffer)
{
    mInt32Marshaler.CppToBytes(input.GetCode(), marshalBuffer);
    mStringMarshaler.CppToBytes(input.GetMessage(), marshalBuffer);
}

std::int32_t IviSelfTestResultMarshaler::GetBufferSize() const
{
    return mInt32Marshaler.GetBufferSize() + mStringMarshaler.GetBufferSize();
}
