/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#include "DriverNode.h"
#include <algorithm>
#include <sstream>

using namespace std;
using namespace Keysight::ApiCoreLibraries;
using namespace Keysight::ModularInstruments; // for logging


DriverNode::DriverNode(const std::shared_ptr<DriverNode>& parent)
    : mpParent(parent)
{
}

std::shared_ptr<DriverNode> DriverNode::GetParent() const
{
    if (auto parent = mpParent.lock())
    {
        return parent;
    }
    else
    {
        throw NullPointerException("mpParent expired in DriverNode::GetParent");
    }
}

std::shared_ptr<ILogger> DriverNode::GetLogger() const
{
    // Default behavior is getting the logger instance from root node
    // the root node of course has to implemented by getting an existing logger
    return this->GetRoot()->GetLogger();
}

void DriverNode::BuildHierarchy(bool isRemote)
{
    //Default behavior is doing nothing
}

std::shared_ptr<const DriverNode> DriverNode::GetRoot() const
{
    if (auto parent = mpParent.lock())
    {
        return parent->GetRoot();
    }
    else
    {
        return shared_from_this();
    }
}

MutexType& DriverNode::GetDriverMutex()
{
    if (auto parent = mpParent.lock())
    {
        return parent->GetDriverMutex();
    }
    else
    {
        throw NullPointerException("mpParent expired in DriverNode::GetDriverMutex");
    }
}

std::int32_t DriverNode::GetRCIndex(std::int32_t level) const
{
    // when run into this method, mean the current node is not a repcap node,
    // look up its parent
    if (level < 0)
        throw invalid_argument("Parameter \"level\" in GetRCIndex should >= 0");

    // if is root node, return NONE_REPCAP_INDEX
    try
    {
        return this->GetParent()->GetRCIndex(level);
    }
    catch(const NullPointerException&)
    {
        return NONE_REPCAP_INDEX;
    }
}


std::string DriverNode::GetRCName(std::int32_t level) const
{
    // when run into this method, mean the current node is not a repcap node,
    // look up its parent
    if (level < 0)
        throw invalid_argument("Parameter \"level\" in GetRCName should >= 0");

    // if is root node, return NONE_REPCAP_INDEX
    try
    {
        return this->GetParent()->GetRCName(level);
    }
    catch (const NullPointerException&)
    {
        return NONE_REPCAP_NAME;
    }
}

std::string DriverNode::GetInstrumentModel() const
{
    return this->GetRoot()->GetInstrumentModel();
}

bool DriverNode::IsInstrumentModel(const std::string& model) const
{
    return this->GetInstrumentModel() == model;
}

void DriverNode::CheckUnsupportedModel(const vector<string>& models, const string& logMethodName, bool logging) const
{
    auto thisModel = this->GetInstrumentModel();
    if (std::find(models.begin(), models.end(), thisModel) == models.end())
    {
        return;
    }

    ostringstream os;
    os << "Operation is not supported for model " << thisModel;
    if (logMethodName != "")
    {
        os << " in " << logMethodName;
    }

    if (logging)
    {
        if (auto logger = this->GetLogger())
        {
            logger->logAppend(LogLevel::Error, "  "+ os.str());
        }
    }

    throw OperationNotSupportedException(os.str());
}