/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#ifndef RCL_TIME_POINT_DURATION_MARSHALER_H
#define RCL_TIME_POINT_DURATION_MARSHALER_H

/**
 * @file TimePointMarshaler.h
 * @author the Rooftop team
 * defines the marshaler class for std::chrono::system_clock::time_point::duration
 */
#include "CommonExport.h"
#include "BasicMarshaler.h"
#include <chrono>
#include <memory>


namespace Keysight {
namespace ApiCoreLibraries {

using TimePointDuration = std::chrono::system_clock::time_point::duration;

/**
 *@brief marshaler class for std::chrono::system_clock::time_point::duration
*/
class KTROOFTOP_COMMON_API TimePointDurationMarshaler : public ICustomMarshaler<TimePointDuration>
{
public:
    void BytesToCpp(MarshalBuffer& marshalBuffer, TimePointDuration& result) override;
    void CppToBytes(const TimePointDuration& input, MarshalBuffer& marshalBuffer) override;
    std::int32_t GetBufferSize() const override;

private:
    BasicMarshaler<double> mDoubleMarshaler;
    std::int64_t NANO_100_TICKS = static_cast<std::int64_t>(1e9 / 100);
};

}}
#endif // RCL_TIME_POINT_DURATION_MARSHALER_H