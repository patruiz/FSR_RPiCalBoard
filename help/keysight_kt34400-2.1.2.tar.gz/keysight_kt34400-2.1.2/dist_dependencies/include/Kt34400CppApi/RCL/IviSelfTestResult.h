/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#ifndef RCL_IVI_SELF_TEST_RESULT_H
#define RCL_IVI_SELF_TEST_RESULT_H

/**
 * @file IviSelfTestResult.h
 * @author the Rooftop team
 *  define class IviSelfTestResult
 */

#include <string>
#include <ostream>

namespace Keysight{
namespace ApiCoreLibraries{

/**
 *@brief Result of a self test operation.
 * This is the equivalent C++ class for the C# Ivi.SelfTestResult
*/

struct IviSelfTestResult
{
public:
    IviSelfTestResult() = default;

    IviSelfTestResult(std::int32_t code, const std::string& message)
        : mTestCode(code)
        , mTestMessage(message)
    {
    }

    /**
    *@brief Get the numeric result from the self test operation. 0 = no error (test passed).
    *@return the numeric result from the self test operation. 0 = no error (test passed).
    */
    std::int32_t GetCode() const
    {
        return mTestCode;
    }

    /**
    *@brief Get the self test status message.
    *@return the self test status message.
    */
    std::string GetMessage() const
    {
        return mTestMessage;
    }

private:
    int32_t mTestCode = 0;
    std::string mTestMessage = "";

    friend std::ostream& operator<<(std::ostream& os, const IviSelfTestResult& value);
};

/**
 * @brief overloading the output stream operator << for IviSelfTestResult
 *
 * @param os output stream object
 * @param value the IviSelfTestResult value
 * @return std::ostream& the stream object
 */
inline std::ostream& operator<<(std::ostream& os, const IviSelfTestResult& value)
{
    os << "SelfTestResult{Code:" << value.mTestCode << ", Message:" << value.mTestMessage << "}";
    return os;
}

}}

#endif // RCL_IVI_SELF_TEST_RESULT_H