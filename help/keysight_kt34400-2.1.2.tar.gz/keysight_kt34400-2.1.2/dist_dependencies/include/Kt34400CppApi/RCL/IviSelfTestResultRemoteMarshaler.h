/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#ifndef RCL_IVI_SELF_TEST_RESULT_REMOTE_MARSHALER_H
#define RCL_IVI_SELF_TEST_RESULT_REMOTE_MARSHALER_H

 /**
  * @file IviSelfTestResultRemoteMarshaler.h
  * @author the Rooftop team
  * defines the rpc marshaler class for IviSelfTestResult
  */
#include "CommonExport.h"
#include "ICustomMarshaler.h"
#include "IviSelfTestResult.h"
#include "BasicMarshaler.h"
#include "StringRemoteMarshaler.h"
#include <string>

namespace Keysight {
namespace ApiCoreLibraries {
/**
* @brief C++ rpc marshal class for Keysight::ApiCoreLibraries::IviSelfTestResult
*/
class KTROOFTOP_COMMON_API IviSelfTestResultRemoteMarshaler : public ICustomMarshaler<IviSelfTestResult>
{
public:
	void BytesToCpp(MarshalBuffer& marshalBuffer, IviSelfTestResult& result) override;
	void CppToBytes(const IviSelfTestResult& input, MarshalBuffer& marshalBuffer) override;
	std::int32_t GetBufferSize() const override;
	std::int32_t GetBufferSizeForRPC(const IviSelfTestResult& input) const override;

private:
	BasicMarshaler<int32_t> mInt32Marshaler;
	StringRemoteMarshaler mStringRemoteMarshaler;
};
}}

#endif // RCL_IVI_SELF_TEST_RESULT_REMOTE_MARSHALER_H