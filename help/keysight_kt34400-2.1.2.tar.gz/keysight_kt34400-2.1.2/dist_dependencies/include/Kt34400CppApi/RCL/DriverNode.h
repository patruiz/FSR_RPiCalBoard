/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#ifndef RCL_DRIVER_NODE_H
#define RCL_DRIVER_NODE_H

/**
 * @file DriverNode.h
 * @author the Rooftop team
 * this header file contains the definition of DriverNode class and some global definitions
 */

#include "OS.h"
#include "ApiCoreExceptions.h"
#include "Log/ILogger.h"
#include <memory>
#include <mutex>
#include <exception>
#include <vector>

namespace Keysight {
namespace ApiCoreLibraries {

using MutexType = std::recursive_mutex;
using LockerType = std::lock_guard<MutexType>;

const std::int32_t NONE_REPCAP_INDEX = -1;
const std::string NONE_REPCAP_NAME = "";

/**
 *@brief Base class of all TreeNode Impl classes
 *
*/
class DriverNode : public std::enable_shared_from_this<DriverNode>
{
public:
    virtual ~DriverNode() = default;

    /**
     * @brief Get parent node
     * @return the parent node
     */
    typename std::shared_ptr<DriverNode> GetParent() const;

    /**
     * @brief Get parent node as type T,
     *  if the casting fails, a logic_error exception is thrown
     * @tparam T the type of the parent node
     *
    */
    template <class T>
    std::shared_ptr<T> GetParent() const
    {
        auto retPtr = std::dynamic_pointer_cast<T>(GetParent());
        if (retPtr)
        {
            return retPtr;
        }
        else
        {
            throw std::logic_error("Cannot cast DriverNode to type '" + std::string(typeid(T).name()) + "' in GetParent.");
        }
    }

    /**
     * @brief Get root node
    */
    std::shared_ptr<const DriverNode> GetRoot() const;

    /**
    * @brief Get the logger instance
    */
    virtual std::shared_ptr<Keysight::ModularInstruments::ILogger> GetLogger() const;

    /**
     * @brief Build its child nodes hierarchy
     * @param isRemote bool for if it is for remote or local
    */
    virtual void BuildHierarchy(bool isRemote=false);

    /**
     * @brief Get the mutex of the driver
    */
    virtual MutexType& GetDriverMutex();

    /**
     * @brief Get the repeated capability index of this node,
     * if the node is not in a repeated capabilities, returns NONE_REPCAP_INDEX
     *
     * @param level the level of repeated capability
     *  0 stands for the closest repeated capability and is the default value
     *  1 is for the parent repeated capability(if it has)...
     */
    virtual std::int32_t GetRCIndex(std::int32_t level = 0) const;
    /**
     * @brief Get the repeated capability name of this node,
     * if the node is not in a repeated capabilities, returns NONE_REPCAP_NAME
     *
     * @param level the level of repeated capability
     *  0 stands for the closest repeated capability and is the default value
     *  1 is for the parent repeated capability(if it has)...
     */
    virtual std::string GetRCName(std::int32_t level = 0) const;

    /**
     * @brief Get the model string of current connected instrument
     *
     * @return std::string
     */
    virtual std::string GetInstrumentModel() const;

    /**
     * @brief Check if the instrument model is the given string
     *
     * @param model the given model
     * @return true or false
     */
    virtual bool IsInstrumentModel(const std::string& model) const;

    /**
     * @brief Check if the current instrument model is in the unsupported list
     *  If is in the unsupported list, throw
     *
     * @param models List of unsupported models
     * @param logMethodName the method in which this is check is performed, used to compose the exception message and the logging message
     *        if the value is empty, don't log the error message.
     * @throw Keysight::ApiCoreLibraries::OperationNotSupportedException if the method doesn't support the given models
     */
    virtual void CheckUnsupportedModel(const std::vector<std::string>& models, const std::string& logMethodName="", bool logging = true) const;

protected:
    /// A protected constructor makes DriverNode an 'abstract' class
    explicit DriverNode(const std::shared_ptr<DriverNode>& parent);

private:
    /// weak pointer pointing to its parent
    std::weak_ptr<DriverNode> mpParent = std::weak_ptr<DriverNode>();
};

}}
#endif // RCL_DRIVER_NODE_H