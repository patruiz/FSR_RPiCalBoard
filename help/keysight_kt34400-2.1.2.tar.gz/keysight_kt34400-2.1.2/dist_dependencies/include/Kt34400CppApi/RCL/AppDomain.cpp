/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
/* @file AppDomain.cpp
*
* Implementation of AddDomain Support, Only for Windows
*/
#include "AppDomain.h"

# if defined(_WIN32) || defined(__WIN32__) || defined(__CYGWIN__)

struct IUnknown; // Workaround for "combaseapi.h(229): error C2187: syntax error: 'identifier' was unexpected here" when using /permissive-

#include <MetaHost.h>
#include <comdef.h>
#include <stdexcept>
#include <sstream>

#pragma comment(lib, "mscoree.lib")

namespace Keysight {
namespace ApiCoreLibraries {

/**
 * @brief wrapper for accessing the Dotnet CLR, providing a method to get the current AppDomain ID
 *  Only support .NET framework > v4.0
 *
 */
class CLRRuntimeWrapper
{
public:
    /**
     * @brief Construct a new CLRRuntimeWrapper object
     *
     */
    CLRRuntimeWrapper()
    {
        LoadCLR();
    }    
    /**
     * @brief try to Load CLR, if succeed, set mClrLoaded = True, otherwise False
     *
     */
    void LoadCLR()
    {
        ICLRMetaHost *pMetaHost = NULL;
        HRESULT hr = CLRCreateInstance(CLSID_CLRMetaHost, IID_ICLRMetaHost, (LPVOID*)&pMetaHost);
        CheckHResult("CLRCreateInstance", hr);

        IEnumUnknown *pEnumUnknown = NULL;
        pMetaHost->EnumerateLoadedRuntimes(GetCurrentProcess(), &pEnumUnknown);

        IUnknown* pUnknown = NULL;
        ULONG fetched = 0;
        // If no runtimes load, It may be running in C++ environment
        hr = pEnumUnknown->Next(1, &pUnknown, &fetched);
        if (hr != S_OK)
        {
            mClrLoaded = false;
            return;
        }

        ICLRRuntimeInfo* pCLRRuntimeInfo = static_cast<ICLRRuntimeInfo*>(pUnknown);
        hr = pCLRRuntimeInfo->GetInterface(CLSID_CLRRuntimeHost, IID_ICLRRuntimeHost, (void **)&mpCLRRuntimeHost);
        CheckHResult("GetInterface", hr);

        mClrLoaded = true;
    }
    /**
     * @brief Get the App Domain Id
     *
     * @return DWORD
     */
    DWORD GetAppDomainId()
    {
        if (!mClrLoaded)
        {
            // CLR may be loaded very late, so check again
            if (mLoadClrRetry)
            {
                LoadCLR();
                mLoadClrRetry = false;
            }
        }

        if (!mClrLoaded)
        {
            // System.AppDomain.CurrentDomain.Id return 1 if App domain is not supported in modern DotNet
            return 1;
        }

        if (!mpCLRRuntimeHost)
        {
            throw "CLRRuntimeHost not yet initialized in unmanaged code";
        }

        DWORD domainId;
        HRESULT hr = mpCLRRuntimeHost->GetCurrentAppDomainId(&domainId);
        CheckHResult("GetCurrentAppDomainId", hr);
        return domainId;
    }

private:
/**
 * @brief Check the HRESULT, if error, throw exception
 *
 * @param api : API name
 * @param hr : HRESULT value
 */
    void CheckHResult(const char* api, HRESULT hr)
    {
        if (FAILED(hr))
        {
            std::ostringstream os;
            os << api << " failed in CLRRuntimeWrapper, error message: " << _com_error(hr).ErrorMessage();
            throw std::runtime_error(os.str());
        }
    }

private:
    // Cache the ICLRRuntimeHost interface for performance
    ICLRRuntimeHost* mpCLRRuntimeHost = nullptr;
    bool mClrLoaded = false;
    // For performance, only try to reload CLR one time if the CLR is not loaded initially.
    bool mLoadClrRetry = true;
};

// Global static instance of CLRRuntimeWrapper
static CLRRuntimeWrapper s_clr;


extern "C"
int GetAppDomainID()
{
    return s_clr.GetAppDomainId();
}

}}

# endif