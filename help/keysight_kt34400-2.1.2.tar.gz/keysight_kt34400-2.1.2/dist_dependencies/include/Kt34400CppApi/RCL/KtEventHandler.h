/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#ifndef RCL_KT_EVENT_HANDLER_H
#define RCL_KT_EVENT_HANDLER_H

/**
 * @file KtEventHanlder.h
 * @author the Rooftop team
 *
 * Defines eventHandler and help fuctions templates for supporting .NET like event in C++
 * below classes/templates defined in this file:
 *  - KtEventHandlerT<T>
 *  - KtEventHandlerAdapterT<T>
 *  - KtEventHandler
 *  - KtEventHandlerAdapter
 *  - KtEventHandlerCFuncAdapterBase<H>
 *  - KtEventHandlerCFuncAdapter<H, T>
 *  - KtEventHandlerCFuncAdapterNoArgs<H>
 *  - KtEventHandlerBinder
 */


#include <cstdio>
#include <iostream>
#include <functional>
#include <list>
#include <mutex>
#include <memory>
#include <typeinfo>
#include <type_traits>


namespace Keysight {
namespace ApiCoreLibraries {

/**
 * @brief base template class of all event handlers for event with parameters
 * @tparam T type of the event arguments
*/
template<typename T>
class KtEventHandlerT
{
public:
    using FuncPtrType = void(*)(const T&);

    /**
     * @brief Destroy the KtEventHandlerT object
     *
     */
    virtual ~KtEventHandlerT() = default;

    /**
     * @brief the processing procedure when the subscribted-to event occurs
     *
     * @param args event arguments
     */
    virtual void OnEvent(const T& args) = 0;

    /**
     * @brief verify if both handlers are bound to the same function.
     *
     * @param pHandler2 the event handler be checked
     * @return true if the given event handler is bound to same function, otherwise false
     */
    virtual bool IsSame(const KtEventHandlerT<T>& pHandler2) const = 0;


    /**
     * @brief Check if the lifetime is controlled by the Event,
     * if the life time is controlled by the event, this event handler will be destroyed when it is removed from the event
     *
     * @return true or false
     */
    virtual bool IsOwn() const
    {
        return true;
    }

#pragma warning( push )
#pragma warning ( disable: 26493 )

    /**
     * @brief convenient function to make inheriting classes implementation of IsSame a little bit easier
     *
     * @param pHandler2 the event handler be checked
     * @return true or false
     */
    bool IsSametype(const KtEventHandlerT<T>& pHandler2) const
    {
        if (typeid(*this) != typeid(pHandler2))
        {
            return false;
        }
        return true;
    }
#pragma warning( pop )
};


/**
 * @brief A wrapper class for .NET
 * This is just a place holder for SWIG to generate a adapter in target language
*/
template<typename T>
class KtEventHandlerAdapterT : public KtEventHandlerT<T>
{
public:
    /**
     * @brief Construct a new Kt Event Handler Adapter T object
     *
     */
    KtEventHandlerAdapterT() = default;

    bool IsSame(const KtEventHandlerT<T>& pHandler2) const override
    {
        return this == &pHandler2;
    }
};


/**
 * @brief Provide an event mechanism that is similar to C# events for non arguments use cases
 * @example myEvent += KtEventHandlerBinder::Bind(&ThisClass::OnMessage, this);  // called inside ThisClass constructor as recommended
*/
class KtEventHandler
{
public:
    using FuncPtrType = void(*)();

    /**
     * @brief Destroy the Kt Event Handler object
     *
     */
    virtual ~KtEventHandler() {};

    /**
     * @brief the processing procedure when the subscribted-to event occurs
     */
    virtual void OnEvent() = 0;

    /**
     * @brief verify if both handlers are bound to the same function.
     *
     * @param pHandler2 the event handler be checked
     * @return true if the given event handler is bound to same function, otherwise false
     */
    virtual bool IsSame(const KtEventHandler& pHandler2) const = 0;

    /**
     * @brief
     *
     * @return true
     * @return false
     */
    virtual bool IsOwn() const
    {
        return true;
    }

#pragma warning( push )
#pragma warning ( disable: 26493 )
    /**
     * @brief convenient function to make inheriting classes implementation of IsSame a little bit easier
     *
     * @param pHandler2 the event handler be checked
     * @return true or false
     */
    bool IsSametype(const KtEventHandler& pHandler2) const
    {
        if (typeid(*this) != typeid(pHandler2))
        {
            return false;
        }
        return true;
    }
#pragma warning( pop )
};


/**
 * @brief A wrapper class for target language
 * This is just a place holder for SWIG to generate a adapter in target language
*/
class KtEventHandlerAdapter: public KtEventHandler
{
public:
    KtEventHandlerAdapter() = default;

    bool IsSame(const KtEventHandler& pHandler2) const override
    {
        return this == &pHandler2;
    }
};

/**
 * @brief KtEventHandlerCFuncAdapterBase is a base class of adapters used to adapt a C function pointer
 * @details
 *  One example is to register a C language function pointer to the event, in C, the event argument class, which is a C++ class, cannot be used,
 *  One approach is to flatten the event arg to primitive types supported in C, Then you can define a ordinary C function.
 * @tparam H is the C function pointer type
 */

template<typename H>
class KtEventHandlerCFuncAdapterBase
{
public:
    using handle_type = H;

    /**
     * @brief Construct a new Kt Event Handler C Func Adapter Base object
     *
     * @param handle the pointer to the C function with type T
     * @param session IVI-C session
     */
    KtEventHandlerCFuncAdapterBase(H handle, std::uint64_t session)
        : mHandle(handle)
        , mSession(session)
    {
    }

   /**
    * @brief operator == KtEventHandlerCFuncAdapterBase to check the underlying function pointer to determine if the two object are same
    * This is used for checking when removing the event handler
    *
    * @param other another KtEventHandlerCFuncAdapterBase instance to be checked
    * @return true if same otherwise false
    */
    bool operator==(const KtEventHandlerCFuncAdapterBase& other) const
    {
        return this->mHandle == other.mHandle && this->mSession == other.mSession;
    }

protected:
    /// the underlying C function pointer
    H mHandle = nullptr;
    /// mSession is the generic handler for the context
    std::uint64_t mSession = 0;

};


/**
 *@brief Adapter class of C function pointer for event with an event argument type.
 * This class is used to help binding a C function pointer to the C++ event.
 *@tparam T the event argument type defined in CppApi
 *@tparam H the callback function type
*/
template<typename H, typename T>
class KtEventHandlerCFuncAdapter: public KtEventHandlerCFuncAdapterBase<H>
{
public:
    using arg_type = T;

    /**
     * @brief Construct a new Kt Event Handler C Func Adapter object
     *
     * @param handle
     * @param session
     */
    KtEventHandlerCFuncAdapter(H handle, std::uint64_t session)
        : KtEventHandlerCFuncAdapterBase<H>(handle, session)
    {
    }

    /**
     *@brief pure virtual OnEvent method need to implemented in concrete class
     * typically doing the parameter reorganization and then invoke the mHanlder function pointer
     * A typical implementation is:
     *  void OnEvent(const T& arg) override
     *  {
     *      (*mHandle)(static_cast<ViSession>(mSession), arg.GetProperty1(), arg.StringProperty2().c_str(), ...);
     *  }
    */
    virtual void OnEvent(const T& arg) = 0;
};


/**
 *@brief CFuncAdapter class for event without arguments.
 * This class is used to help binding a C function pointer to the C++ event.
 * it is a virtual class supposed to be derived by certain concrete classes
 *@tparam H the callback function type
*/
template<typename H>
class KtEventHandlerCFuncAdapterNoArgs : public KtEventHandlerCFuncAdapterBase<H>
{
public:
    /**
     * @brief Construct a new Kt Event Handler C Func Adapter No Args object
     *
     * @param handle the C function pointer
     * @param session the IVI-C session
     */
    KtEventHandlerCFuncAdapterNoArgs(H handle, std::uint64_t session)
        : KtEventHandlerCFuncAdapterBase<H>(handle, session)
    {
    }

    /**
     *@brief pure virtual OnEvent method need to implemented in concrete class
     * typically doing the parameter reorganization and then invoke the mHanlder function pointer
     * A typical implementation is:
     *  void OnEvent() override
     *  {
     *      (*mHandle)(static_cast<ViSession>(mSession));
     *  }
    */
    virtual void OnEvent() = 0;
};


/**
 * @brief a syntax-sugar class that is used to assign a function as a handler to an Event
 * @example myEvent += KtEventHandlerBinder::Bind(OnMessage);  // for non member or static functions
 * @example myEvent += KtEventHandlerBinder::Bind(&ThisClass::OnMessage, this);  // called inside ThisClass constructor as recommended
*/
class KtEventHandlerBinder
{
    /**
     * @brief Event handler wrappering C++ class member function which has no parameters
     *
     * @tparam U the class type
     */
    template<typename U>
    class CppMemberFunc : public KtEventHandler
    {
    public:
        using MemberFuncPtrType = void (U::*)();

        CppMemberFunc(void(U::*pFunc)(), U* const objPtr)
            : mpCallerInstance(objPtr)
            , mpMemberFunction(pFunc)
        {
        }

        void OnEvent() override
        {
            if (mpCallerInstance)
            {
                (mpCallerInstance->*mpMemberFunction)();
            }
        }

        bool IsSame(const KtEventHandler& pHandler2) const override
        {
            auto pCasted = dynamic_cast<const CppMemberFunc<U>*>(&pHandler2);

            if (!this->IsSametype(pHandler2) || !pCasted)
            {
                return false;
            }

            return mpCallerInstance == pCasted->mpCallerInstance &&
                mpMemberFunction == pCasted->mpMemberFunction;
        }

    private:
        U* const mpCallerInstance = nullptr;
        MemberFuncPtrType mpMemberFunction = nullptr;
    };

    /**
     * @brief Event handler wrappering C++ statis function which has no parameters
     */
    class CppStaticFunc : public KtEventHandler
    {
    public:
        CppStaticFunc(void(*functionToCall)())
            : mpFunctionToCall(functionToCall)
        {
        }

        void OnEvent() override
        {
            mpFunctionToCall();
        }

        bool IsSame(const KtEventHandler& pHandler2) const override
        {
            auto pCasted = dynamic_cast<const CppStaticFunc*>(&pHandler2);

            if (!this->IsSametype(pHandler2) || !pCasted)
            {
                return false;
            }

            return mpFunctionToCall == pCasted->mpFunctionToCall;
        }

    private:
        FuncPtrType mpFunctionToCall = nullptr;
    };

    class StdFunc : public KtEventHandler
    {
    public:
        StdFunc(std::function<void()> functionToCall)
            : mpFunctionToCall(functionToCall)
        {
        }

        void OnEvent() override
        {
            if (mpFunctionToCall != nullptr)
            {
                mpFunctionToCall();
            }
        }

        bool IsSame(const KtEventHandler& pHandler2) const override
        {
            auto pCasted = dynamic_cast<const StdFunc*>(&pHandler2);

            if (!this->IsSametype(pHandler2) || !pCasted)
            {
                return false;
            }
            // There's no good way to compare 2 std::function objects, just return false
            return false;
        }

    private:
        std::function<void()> mpFunctionToCall = nullptr;
    };

	class PyFunc : public KtEventHandler
	{
	public:
		PyFunc(std::function<void()> functionToCall, void *pyHandler)
			: mpFunctionToCall(functionToCall)
			, mpPyHandler(pyHandler)
		{
		}

		void OnEvent() override
		{
			if (mpFunctionToCall != nullptr)
			{
				mpFunctionToCall();
			}
		}

		bool IsSame(const KtEventHandler& pHandler2) const override
		{
			auto pCasted = dynamic_cast<const PyFunc*>(&pHandler2);

			if (!this->IsSametype(pHandler2) || !pCasted)
			{
				return false;
			}

			// Compare pyHandler to know whether it is the same python function handler
			return pCasted->mpPyHandler == mpPyHandler;
		}

	private:
		std::function<void()> mpFunctionToCall = nullptr;
		void * mpPyHandler = nullptr;
	};

   /**
    * @brief event handler template wrappering C++ static function with parameter type T
    *
    * @tparam T the event argument type
    */
    template<typename T>
    class CppStaticFuncT : public KtEventHandlerT<T>
    {
    public:
        CppStaticFuncT(typename KtEventHandlerT<T>::FuncPtrType functionToCall)
            : mpFunctionToCall(functionToCall)
        {
        }

        void OnEvent(const T& evt) override
        {
            mpFunctionToCall(evt);
        }

        bool IsSame(const KtEventHandlerT<T>& pHandler2) const override
        {
            auto pCasted = dynamic_cast<const CppStaticFuncT<T>*>(&pHandler2);
            if (!this->IsSametype(pHandler2) || !pCasted)
            {
                return false;
            }
            return mpFunctionToCall == pCasted->mpFunctionToCall;
        }

    private:
        typename KtEventHandlerT<T>::FuncPtrType mpFunctionToCall = nullptr;
    };

    template<typename T>
    class StdFuncT : public KtEventHandlerT<T>
    {
    public:
        StdFuncT(std::function<void(const T &)> functionToCall)
            : mpFunctionToCall(functionToCall)
        {
        }

        void OnEvent(const T& evt) override
        {
            if (mpFunctionToCall != nullptr)
            {
                mpFunctionToCall(evt);
            }
        }

        bool IsSame(const KtEventHandlerT<T>& pHandler2) const override
        {
            auto pCasted = dynamic_cast<const StdFuncT<T>*>(&pHandler2);
            if (!this->IsSametype(pHandler2) || !pCasted)
            {
                return false;
            }
            return false;
        }

    private:
        std::function<void(const T &)> mpFunctionToCall = nullptr;
    };

	template<typename T>
	class PyFuncT : public KtEventHandlerT<T>
	{
	public:
		PyFuncT(std::function<void(const T &)> functionToCall, void * pyHandler)
			: mpFunctionToCall(functionToCall)
			, mpPyHandler(pyHandler)
		{
		}

		void OnEvent(const T& evt) override
		{
			if (mpFunctionToCall != nullptr)
			{
				mpFunctionToCall(evt);
			}
		}

		bool IsSame(const KtEventHandlerT<T>& pHandler2) const override
		{
			auto pCasted = dynamic_cast<const PyFuncT<T>*>(&pHandler2);
			if (!this->IsSametype(pHandler2) || !pCasted)
			{
				return false;
			}
			return pCasted->mpPyHandler == mpPyHandler;
		}

	private:
		std::function<void(const T &)> mpFunctionToCall = nullptr;
		void * mpPyHandler = nullptr;
	};

   /**
    * @brief event handler template wrappering C++ class member function with parameter type T
    *
    * @tparam T the event argument type
    * @tparam U the type of the class in which the function is defined
    */
    template<typename T, typename U>
    class CppMemberFuncT : public KtEventHandlerT<T>
    {
    public:
        using MemberFuncPtrType = void (U::*)(const T&);

        /**
         * @brief Construct a CppMemberFuncT object
         *
         * @param pFunc the pointer to the class member function
         * @param objPtr the pointer to the class instance
         */
        CppMemberFuncT(MemberFuncPtrType pFunc, U* const objPtr)
            : mpCallerInstance(objPtr)
            , mpMemberFunction(pFunc)
        {
        }

        void OnEvent(const T& evt) override
        {
            if (mpCallerInstance)
            {
                (mpCallerInstance->*mpMemberFunction)(evt);
            }
        }

        bool IsSame(const KtEventHandlerT<T>& pHandler2) const override
        {
            auto pCasted = dynamic_cast<const CppMemberFuncT<T, U>*>(&pHandler2);
            if (!this->IsSametype(pHandler2) || !pCasted)
            {
                return false;
            }
            return mpCallerInstance == pCasted->mpCallerInstance && mpMemberFunction == pCasted->mpMemberFunction;
        }

    private:
        U* const mpCallerInstance = nullptr;
        MemberFuncPtrType mpMemberFunction = nullptr;
    };

   /**
    * @brief A internal adapter class used to register the KtEventHandlerCFuncAdapter to the event
    *
    * @tparam A KtEventHandlerCFuncAdapter type
    */
    template<typename A>
    class AnyFuncPtrT : public KtEventHandlerT<typename A::arg_type>
    {
        /// the underlying KtEventHandlerCFuncAdapter instance
        A mCFuncAdapter = { nullptr };

    public:
        using T = typename A::arg_type;

        /**
         * @brief Construct a new Any Func Ptr T object
         *
         * @param obj KtEventHandlerCFuncAdapter instance
         */
        AnyFuncPtrT(const A& obj)
            : mCFuncAdapter(obj)
        {
        }

        void OnEvent(const T& evt) override
        {
            mCFuncAdapter.OnEvent(evt);
        }

        bool IsSame(const KtEventHandlerT<T>& pHandler2) const override
        {
            auto pCasted = dynamic_cast<const AnyFuncPtrT<A>*>(&pHandler2);
            if (!this->IsSametype(pHandler2) || !pCasted)
            {
                return false;
            }
            // Check if the underlying function pointer is same
            return mCFuncAdapter == pCasted->mCFuncAdapter;
        }
    };

   /**
    * @brief A internal adapter class used to register the KtEventHandlerCFuncAdapterNoArgs to the event
    *
    * @tparam A KtEventHandlerCFuncAdapterNoArgs type
    */
    template<typename A>
    class AnyFuncPtr : public KtEventHandler
    {
        A mCFuncAdapter = { nullptr };

    public:
        /**
         * @brief Construct AnyFuncPtr object
         *
         * @param obj instance of KtEventHandlerCFuncAdapterNoArgs
         */
        AnyFuncPtr(const A& obj)
            : mCFuncAdapter(obj)
        {
        }

        void OnEvent() override
        {
            mCFuncAdapter.OnEvent();
        }

        bool IsSame(const KtEventHandler& pHandler2) const override
        {
            auto pCasted = dynamic_cast<const AnyFuncPtr*>(&pHandler2);
            if (!this->IsSametype(pHandler2) || !pCasted)
            {
                return false;
            }
            // Check if the underlying function pointer is same
            return mCFuncAdapter == pCasted->mCFuncAdapter;
        }
    };

    //

    /**
     * @brief Construct. Only provides static bind methods, so delete the constructor
     *
     */
    KtEventHandlerBinder() = delete;

public:
    /**
     * @brief overloading method of Bind returns a CppStaticFuncT from a C++ static member function pointer which has event argument parameter
     *
     * @tparam T the event argument type
     * @param pFunc the function pointer
     * @return std::shared_ptr<KtEventHandlerT<T>> CppStaticFuncT<T> event handler
     */
    template<typename T>
    static std::shared_ptr<KtEventHandlerT<T>> Bind(typename KtEventHandlerT<T>::FuncPtrType pFunc)
    {
        return std::make_shared<CppStaticFuncT<T>>(pFunc);
    }

    template<typename T>
    static std::shared_ptr<KtEventHandlerT<T>> Bind(std::function<void(const T &)> pFunc, int)
    {
        return std::make_shared<StdFuncT<T>>(pFunc);
    }

    template<typename T>
    static std::shared_ptr<KtEventHandlerT<T>> Bind(std::function<void(const T &)> pFunc, void *pyHandler, int)
    {
        return std::make_shared<PyFuncT<T>>(pFunc, pyHandler);
    }

    /**
     * @brief overloading method of Bind returns a CppMemberFuncT from a C++ member function pointer which has event argument parameter
     *
     * @tparam T the event argument type
     * @tparam U the class instance type
     * @param pFunc function pointer to the class member function
     * @param ObjPtr pointer to the class instance
     * @return std::shared_ptr<KtEventHandlerT<T>> the CppMemberFuncT event handler instance
     */
    template<typename T, typename U>
    static std::shared_ptr<KtEventHandlerT<T>> Bind(typename CppMemberFuncT<T, U>::MemberFuncPtrType pFunc, U* const ObjPtr)
    {
        return std::make_shared<CppMemberFuncT<T, U>>(pFunc, ObjPtr);
    }

    /**
     * @brief overloading method of Bind returns a CppMemberFuncT from a C++ function pointer which has no event argument parameter
     *
     * @param pFunc the function pointer
     * @return std::shared_ptr<KtEventHandler> CppStaticFunc event handler instance
     */
    static std::shared_ptr<KtEventHandler> Bind(typename CppStaticFunc::FuncPtrType pFunc)
    {
        return std::make_shared<CppStaticFunc>(pFunc);
    }

    static std::shared_ptr<KtEventHandler> Bind(std::function<void()> pFunc, int)
    {
        return std::make_shared<StdFunc>(pFunc);
    }

	static std::shared_ptr<KtEventHandler> Bind(std::function<void()> pFunc, void *pyHandler, int)
	{
		return std::make_shared<PyFunc>(pFunc, pyHandler);
	}

    /**
     * @brief overloading method of Bind returns a CppMemberFuncT from a C++ member function pointer which has no event argument parameter
     *
     * @tparam U the type of the class
     * @param pFunc the pointer to the C++ class member function
     * @param objPtr the pointer to the class instance
     * @return std::shared_ptr<KtEventHandler> CppMemberFunc event handler instance
     */
    template<typename U>
    static std::shared_ptr<KtEventHandler> Bind(typename CppMemberFunc<U>::MemberFuncPtrType pFunc, U* const objPtr)
    {
        return std::make_shared<CppMemberFunc<U>>(pFunc, objPtr);
    }

    /**
     * @brief Bind method for AnyFuncAdapter
     *
     * @tparam A
     * @param adapter
     * @return std::shared_ptr<KtEventHandlerT<typename A::arg_type>>
     */
    template<typename A>
    static std::shared_ptr<KtEventHandlerT<typename A::arg_type>> BindAdapter(const A& adapter)
    {
        return std::make_shared<AnyFuncPtrT<A>>(adapter);
    }

    /**
     * @brief
     *
     * @tparam A
     * @param adapter
     * @return std::shared_ptr<KtEventHandler>
     */
    template<typename A>
    static std::shared_ptr<KtEventHandler> BindAdapterNoArgs(const A& adapter)
    {
        return std::make_shared<AnyFuncPtr<A>>(adapter);
    }
};

}}

#endif // RCL_KT_EVENT_HANDLER_H