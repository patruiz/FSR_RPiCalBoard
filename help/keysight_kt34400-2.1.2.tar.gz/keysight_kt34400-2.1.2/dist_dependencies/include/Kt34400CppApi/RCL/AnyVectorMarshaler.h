/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#ifndef RCL_ANY_VECTOR_MARSHALER_H
#define RCL_ANY_VECTOR_MARSHALER_H

/**
 * @file AnyVectorMarshaler.h
 * @author the Rooftop team
 * defines the marshaler class for AnyVector<T>
 */

#include "ICustomMarshaler.h"
#include "BasicMarshaler.h"
#include "AnyVector.h"
#include <memory>
#include <chrono>
#include <exception>
#include <string>

// Handle calling conventions for Windows vs. Linux
#ifndef STDCALL
# ifdef WIN32
#   define STDCALL __stdcall
# else
#   define STDCALL
# endif
#endif

namespace Keysight {
namespace ApiCoreLibraries {

typedef void* (STDCALL* AnyVectorAllocationCallback_t)(void* originalHandle, std::int32_t size);

/**
 *@brief Generic template for AnyVector<T> marshaler
 *@tparam T the element type of AnyVector
*/
template <class T>
class AnyVectorMarshaler : public ICustomMarshaler<Keysight::ModularInstruments::AnyVector<T>>
{
public:
    void BytesToCpp(MarshalBuffer& marshalBuffer, Keysight::ModularInstruments::AnyVector<T>& result) override
    {
        std::int64_t pBuffer, length;
        std::int64_t delegateInt;
        mInt64Marshaler.BytesToCpp(marshalBuffer, pBuffer);
        mInt64Marshaler.BytesToCpp(marshalBuffer, length);
        mInt64Marshaler.BytesToCpp(marshalBuffer, delegateInt);

        auto cb = reinterpret_cast<AnyVectorAllocationCallback_t>(delegateInt);

        result = typename Keysight::ModularInstruments::AnyVector<T>(
            typename gsl::span<T>(
                (T*)pBuffer,
                static_cast<typename gsl::span<T>::index_type>(length)),
            cb);
    }

    void CppToBytes(const Keysight::ModularInstruments::AnyVector<T>& input, MarshalBuffer& marshalBuffer) override
    {
        mInt64Marshaler.CppToBytes(reinterpret_cast<std::int64_t>(input.getSpan().data()), marshalBuffer);
        mInt64Marshaler.CppToBytes(static_cast<std::int64_t>(input.getSpan().size()), marshalBuffer);
        mInt64Marshaler.CppToBytes(0, marshalBuffer);
    }

    std::int32_t GetBufferSize() const override
    {
        return 3 * mInt64Marshaler.GetBufferSize();
    }

private:
    BasicMarshaler<std::int64_t> mInt64Marshaler;
};



#if 0 //AnyVector<bool> is currently not used
template <>
class AnyVectorMarshaler<bool> : public ICustomMarshaler<Keysight::ModularInstruments::AnyVector<bool>>
{
public:
    void BytesToCpp(MarshalBuffer& marshalBuffer, Keysight::ModularInstruments::AnyVector<bool>& result) override
    {
        std::int64_t pBuffer, length;
        std::int64_t delegateInt;
        mInt64Marshaler.BytesToCpp(marshalBuffer, pBuffer);
        mInt64Marshaler.BytesToCpp(marshalBuffer, length);
        mInt64Marshaler.BytesToCpp(marshalBuffer, delegateInt);

        auto cb = reinterpret_cast<AnyVectorAllocationCallback_t>(delegateInt);

        result = typename Keysight::ModularInstruments::AnyVector<bool>(
            typename gsl::span<bool>(
                (bool*)pBuffer,
                static_cast<typename gsl::span<bool>::index_type>(length)),
            cb);

        // In DotNet side, as sizeof(CppBool) is not known, so we just use Int32[] to save the bool value
        // So in C++ side, we need to move the value so that the memory is aligned
        auto pBool = result.getSpan().data();
        auto pInt32 = reinterpret_cast<std::int32_t*>(pBool);
        for (int i = 0; i < static_cast<int>(result.getSpan().size()); i++)
        {
            pBool[i] = (pInt32[i] != 0);
        }
    }

    void CppToBytes(const Keysight::ModularInstruments::AnyVector<bool>& input, MarshalBuffer& marshalBuffer) override
    {
        // The C++ AnyVector treat the buffer as bool*, but the .NET side treat it as a Int32*
        // So we need to handle the difference
        auto pBool = input.getSpan().data();
        auto pInt32 = reinterpret_cast<std::int32_t*>(pBool);
        for (int i = static_cast<int>(input.getSpan().size()) - 1; i >= 0; i--)
        {
            pInt32[i] = static_cast<std::int32_t>(pBool[i]);
        }

        mInt64Marshaler.CppToBytes(reinterpret_cast<std::int64_t>(input.getSpan().data()), marshalBuffer);
        mInt64Marshaler.CppToBytes(static_cast<std::int64_t>(input.getSpan().length()), marshalBuffer);
    }

private:
    BasicMarshaler<std::int64_t> mInt64Marshaler;
};

#endif

}}
#endif // RCL_ANY_VECTOR_MARSHALER_H