/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#ifndef RCL_COMMON_ARRAY_REMOTE_MARSHALER_H
#define RCL_COMMON_ARRAY_REMOTE_MARSHALER_H

 /**
  * @file CommonArrayRemoteMarshaler.h
  * @author the Rooftop team
  * defines the rpc marshaler class for std::vector<T>
  */

#include "ICustomMarshaler.h"
#include "BasicMarshaler.h"
#include <vector>

namespace Keysight {
namespace ApiCoreLibraries {
/**
*@brief rpc marshaler class for std::vector < T >
*@tparam _eleT the element type of the array
*@tparam  _eleMarshalerT the marshaler class for the element type
*/
template <class _eleT, class _eleRemoteMarshalerT>
class CommonArrayRemoteMarshaler : public Keysight::ApiCoreLibraries::ICustomMarshaler<std::vector<_eleT>>
{
public:
	void BytesToCpp(MarshalBuffer& marshalBuffer, std::vector<_eleT>& result) override
	{
		result.clear();
		std::int32_t size = 0;
		mInt32Marshaler.BytesToCpp(marshalBuffer, size);
		for (int index = 0; index < size; index++)
		{
			auto element = _eleT();
			mElementRemoteMarshaler.BytesToCpp(marshalBuffer, element);
			result.push_back(element);
		}
	}

	void CppToBytes(const std::vector<_eleT>& input, MarshalBuffer& marshalBuffer) override
	{
		mInt32Marshaler.CppToBytes(static_cast<std::int32_t>(input.size()), marshalBuffer);
		for (auto& ele : input)
		{
			mElementRemoteMarshaler.CppToBytes(ele, marshalBuffer);
		}
	}

	std::int32_t GetBufferSize() const override
	{
		throw std::runtime_error("should not be called here!");
	}

	std::int32_t GetBufferSizeForRPC(const std::vector<_eleT>& input) const override
	{
		if (input.size() > 0)
		{
			return sizeof(std::int32_t) + static_cast<std::int32_t>(input.size())*(mElementRemoteMarshaler.GetBufferSizeForRPC(input[0]));
		}
		else
		{
			return sizeof(std::int32_t);
		}

	}

private:
	Keysight::ApiCoreLibraries::Int32Marshaler mInt32Marshaler;
	_eleRemoteMarshalerT mElementRemoteMarshaler;
};
}}

#endif // RCL_COMMON_ARRAY_REMOTE_MARSHALER_H