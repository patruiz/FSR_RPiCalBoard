/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#ifndef RCL_REP_CAP_H
#define RCL_REP_CAP_H

/**
 * @file RepCap.h
 * @author the Rooftop team
 *
 * defines class RepCap, which is the base class for collection style repeated capability instance
 */

#include "DriverNode.h"
#include <string>

namespace Keysight {
namespace ApiCoreLibraries {

/**
*@brief Base class for collection style repeated capability instance
*/
class RepCap : public DriverNode
{
public:
    RepCap(const std::shared_ptr<DriverNode>& parent, const std::string& name, std::int32_t index);

    /**
     * @brief Get repeated capability instance name where this node belongs
     *  there may be multiple level repeated capability in the node hierarchy
     *
     * @param level the level of the repeated capability, start from zero
     * @return std::string the requested repeated capability name
     */

    std::string GetRCName(std::int32_t level = 0) const override;
    /**
     * @brief Get the index of repeated capability instance within the hierarchy tree
     *  there may be multiple level repeated capability in the node hierarchy
     *
     * @param level the level of the repeated capability, start from zero
     * @return std::int32_t
     */
    std::int32_t GetRCIndex(std::int32_t level = 0) const override;

private:
    std::string mName = "";
    std::int32_t mIndex = 0;
};

}}
#endif // RCL_REP_CAP_H