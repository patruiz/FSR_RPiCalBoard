/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#ifndef RCL_REP_CAP_COLLECTION_T_H
#define RCL_REP_CAP_COLLECTION_T_H

/**
 * @file RepCapCollectionT.h
 * @author the Rooftop team
 *
 * defines class RepCapCollectionT, which is the base class for repeated capability collection Pimpl class
 */

#include "IRepCapCollectionT.h"

namespace Keysight {
namespace ApiCoreLibraries {

/**
 *@brief Base class for repeated capability collection Pimpl class
 *  This class holds a pointer to a class which really implement all the methods, all the operations are delegated to the implementation class
 *@note The method naming convention with this class follows the stl-style, not aligned with other files in this project.
 *@tparam T the repeated capability type.
 */

template <class T>
class RepCapCollectionT: public IRepCapCollectionT<T>
{
public:
    /**
     * @brief Returns a reference to the repeated capability instance that is mapped to a key representing the physical name
     *  Note that if such key does not already exist, an exception will be thrown, this is different with the [] operator in STL
     * @param key the physical name (case insensitive) of repeated capability instance to find
     * @return T& Reference to the mapped repeated capability instance
     * @throw InvalidOperationException if the key doesn't exist
     */
    T& operator[] (const std::string & key) override
    {
        return (*mCollectionImpl)[key];
    }

    /**
     * @brief Returns a reference to the repeated capability instance that is mapped to a key representing the physical name
     * @param key the physical name (case insensitive) of repeated capability instance to find
     * @return T& Reference to the mapped repeated capability instance
     * @throw InvalidOperationException if the key doesn't exist
     */
    T& Get(const std::string& key) override
    {
        return mCollectionImpl->Get(key);
    }

    /**
     * @brief Get repeated capability instance by index, with bound checking.
     *   The index is the of the order the instance is added.
     *
     * @param index zero-based index of the repeated capability instance to return
     * @return T& reference to the requested repeated capability instance
     * @throw InvalidOperationException if the index out of range
     */
    T& Get(std::int32_t index)
    {
        return mCollectionImpl->Get(index);
    }

    /**
     * @brief Get repeated capability physical name, with bound checking.
     *   The index is the of the order the instance is added.
     *
     * @param index zero-based index of the repeated capability name
     * @return std::string
     */
    std::string GetName(std::int32_t index)
    {
        return mCollectionImpl->GetName(index);
    }

    /**
     * @brief Returns the number of repeated capabilities in this collection
     *
     * @return IRepCapCollectionT<T>::size_type The number of elements in the collection.
     */
    typename IRepCapCollectionT<T>::size_type size() const override
    {
        return mCollectionImpl->size();
    }

    /**
     * @brief Returns an iterator to the first element of the container.
     *
     * @return IRepCapCollectionT<T>::iterator Iterator to the first element
     */
    typename IRepCapCollectionT<T>::iterator begin() override
    {
        return mCollectionImpl->begin();
    }

    /**
     * @brief Returns an iterator to the element following the last element of the container.
     *
     * @return IRepCapCollectionT<T>::iterator Iterator to the element following the last element.
     */
    typename IRepCapCollectionT<T>::iterator end() override
    {
        return mCollectionImpl->end();
    }

    /**
     * @brief Finds an repeated capability with physical name equivalent to key
     *
     * @param key physical name of the instance to search for
     * @return IRepCapCollectionT<T>::iterator Iterator to the repeated capability instance with name equivalent to key.
     *  If no such element is found, past-the-end (see end()) iterator is returned.
     */
    typename IRepCapCollectionT<T>::iterator find(const std::string& key) override
    {
        return mCollectionImpl->find(key);
    }

    /**
     * @brief increment the given iterator
     *
     * @param iter the current iterator
     */
    void IncreaseIterator(typename IRepCapCollectionT<T>::iterator& iter) override
    {
        mCollectionImpl->IncreaseIterator(iter);
    }

protected:
    /**
     *@brief Bind the implementation to this class.
     *@param implementation The pointer to the instance of IRepCapCollectionT<T> with full implementation
    */
    void BindRepCapCollectionImpl(std::shared_ptr<IRepCapCollectionT<T>> impl)
    {
        mCollectionImpl = impl;
    }

private:
    std::shared_ptr<IRepCapCollectionT<T>> mCollectionImpl = nullptr;
};

}}
#endif // RCL_REP_CAP_COLLECTION_T_H