/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#ifndef RCL_ENUM_MARSHALER_H
#define RCL_ENUM_MARSHALER_H

/**
 * @file EnumMarshaler.h
 * @author the Rooftop team
 * defines the marshaler class template for enumerations
 */

#include "ICustomMarshaler.h"
#include "BasicMarshaler.h"
#include <chrono>
#include <cstring>
#include <exception>
#include <memory>
#include <string>
#include <type_traits>

namespace Keysight {
namespace ApiCoreLibraries {

template <class T>
class EnumMarshaler : public ICustomMarshaler<T>
{
public:
    EnumMarshaler()
    {
        // runtime check to restrict T to enumeration type
        static_assert(std::is_enum<T>::value, "EnumMarshaler can only support enumeration type!");
    }

    void BytesToCpp(MarshalBuffer& marshalBuffer, T& result) override
    {
        int32_t temp = static_cast<int32_t>(result);
        mInt32Marshaler.BytesToCpp(marshalBuffer, temp);
        result = static_cast<T>(temp);
    }

    void CppToBytes(const T& input, MarshalBuffer& marshalBuffer) override
    {
        mInt32Marshaler.CppToBytes(static_cast<int32_t>(input), marshalBuffer);
    }

    std::int32_t GetBufferSize() const override
    {
        return mInt32Marshaler.GetBufferSize();
    }

private:
    Int32Marshaler mInt32Marshaler;
};

}}
#endif // RCL_ENUM_MARSHALER_H