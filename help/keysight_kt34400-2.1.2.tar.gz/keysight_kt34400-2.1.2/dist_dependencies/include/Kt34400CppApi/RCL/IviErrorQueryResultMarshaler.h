/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#ifndef RCL_IVI_ERROR_QUERY_RESULT_MARSHALER_H
#define RCL_IVI_ERROR_QUERY_RESULT_MARSHALER_H

/**
 * @file IviErrorQueryResultMarshaler.h
 * @author the Rooftop team
 * defines the marshaler class for ErrorQueryResult
 */

#include "IviErrorQueryResult.h"
#include "BasicMarshaler.h"
#include "StringMarshaler.h"
#include <memory>
#include <string>

namespace Keysight{
namespace ApiCoreLibraries{

using ErrorQueryResult = Keysight::ApiCoreLibraries::IviErrorQueryResult;

class IviErrorQueryResultMarshaler : public ICustomMarshaler<ErrorQueryResult>
{
public:
    void BytesToCpp(MarshalBuffer& marshalBuffer, ErrorQueryResult& result) override;
    void CppToBytes(const ErrorQueryResult& input, MarshalBuffer& marshalBuffer) override;
    std::int32_t GetBufferSize() const override;

private:
    BasicMarshaler<int32_t> mInt32Marshaler;
    StringMarshaler mStringMarshaler;
};

}}

#endif // RCL_IVI_ERROR_QUERY_RESULT_MARSHALER_H