/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#include "StringMarshaler.h"
#include "MemoryAllocation.h"

namespace Keysight {
namespace ApiCoreLibraries {

void StringMarshaler::BytesToCpp(MarshalBuffer& marshalBuffer, std::string& result)
{
    AnyVectorByte bytes{};
    mAnyVectorByteMarshaler.BytesToCpp(marshalBuffer, bytes);
    if (bytes.size() > 0)
    {
        auto span = bytes.getSpan();
        result = std::string(span.data(), span.data() + span.size());
    }
}

void StringMarshaler::CppToBytes(const std::string& input, MarshalBuffer& marshalBuffer)
{
    auto count = input.size();
    auto bytes = MemoryAllocation::CreateAnyVectorByte();

    if (bytes.size() != count)
    {
        bytes.resize(count);
    }
    
    std::memcpy(bytes.getSpan().data(), input.c_str(), static_cast<std::int32_t>(count));
    mAnyVectorByteMarshaler.CppToBytes(bytes, marshalBuffer);
}

std::int32_t StringMarshaler::GetBufferSize() const
{
    return mAnyVectorByteMarshaler.GetBufferSize();
}

}}