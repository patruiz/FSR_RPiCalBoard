/******************************************************
 *       Copyright Keysight Technologies 2018-2019
 ******************************************************/
#ifndef RCL_I_CUSTOM_RPC_EXC_MARSHALER_H
#define RCL_I_CUSTOM_RPC_EXC_MARSHALER_H

/**
 * @file ICustomRpcExcMarshaler.h
 * @author the Rooftop team
 *
 * defines the base class for all C++ customized exception marshalers
 */

#include <exception>
#include <memory>
#include <string>


namespace Keysight {
namespace ApiCoreLibraries {

/**
 *@brief template pure class to define the interface that the C++ marshaler class should implement
 *  All the C++ marshal class should inherit from this class
 *@tparam T the type of the data to be marshaled
*/
template <class T>
class ICustomRpcExcMarshaler
{
public:

    virtual ~ICustomRpcExcMarshaler() = default;
    
    /**
     * @brief Takes a marshal buffer and extracts a C++ customized exception type.
     *  @param data the marshal buffer that holds the data
     *  @return the output C++ customized exception object deserialized from the buffer
    */
    virtual T stringToObj(const std::string & data) = 0;

    /**
     * @brief Takes a C++ customized exception type and serialize it to std::string.
     * @param obj the input C++ customized exception object
     * @return the marshal buffer
    */
    virtual std::string objToString(const T &obj) const = 0;

};


}}

#endif // RCL_I_CUSTOM_RPC_EXC_MARSHALER_H