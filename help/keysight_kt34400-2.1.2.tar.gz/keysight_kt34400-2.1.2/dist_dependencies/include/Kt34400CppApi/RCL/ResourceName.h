/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#ifndef RCL_RESOURCE_NAME_H
#define RCL_RESOURCE_NAME_H

/**
 * @file ResourceName.h
 * @author the Rooftop team
 * defines the ResourceName class, which is used to parse resource name
 */

#include <string>
#include <regex>

namespace Keysight
{
namespace ApiCoreLibraries
{

/**
* @brief ResourceName is a helper class for parsing the resource name passed to the driver constructor
*
*/
class ResourceName
{
public:
    /**
    * @brief Construct a new resource name object from the input string
    * @param str resource name
    * @throw invalid_argument exception when no valid hostname found in the string
    */
    explicit ResourceName(const std::string& str);
    
    /**
    * @brief returns if the input resource name has a remote host name
    * @return bool value for if has valid remote host
    */
    bool HasRemoteHost() const;

    /**
    * @brief returns if the input resource name is a KDI address which prefixed with 'kdi://'
    * @return bool value for if it is a KDI address
    */
    bool IsKdiRemote() const;
    
    /**
    * @brief Get the remote host name if exists
    * @return remote host name
    */
    std::string GetRemoteHost() const;

    /**
    * @brief Get the local address from the resource name
    * @return local address
    */
    std::string GetLocalAddress() const;

private:
    void Parse();
    bool IsEqualIgnoreCase(const std::string& lfs, const std::string& rhs) const;
    std::string mFullResourceName{""};
    bool mHasRemote{false};
    bool mIsKdiRemote{false};
    std::string mRemoteHost{""};
    std::string mLocalAddress{""};

};

} // namespace ApiCoreLibraries
} // namespace Keysight


#endif // RCL_RESOURCE_NAME_H