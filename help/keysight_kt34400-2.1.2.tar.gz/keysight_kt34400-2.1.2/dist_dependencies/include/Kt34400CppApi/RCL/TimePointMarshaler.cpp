/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#include "TimePointMarshaler.h"

using namespace Keysight::ApiCoreLibraries;

void TimePointMarshaler::BytesToCpp(MarshalBuffer& marshalBuffer, TimePoint& result)
{
    TimePointDuration d = {};
    mDurationMarshaler.BytesToCpp(marshalBuffer, d);
    result = TimePoint(d);
}

void TimePointMarshaler::CppToBytes(const TimePoint& input, MarshalBuffer& marshalBuffer)
{
    mDurationMarshaler.CppToBytes(input.time_since_epoch(), marshalBuffer);
}

std::int32_t TimePointMarshaler::GetBufferSize() const
{
    return mDurationMarshaler.GetBufferSize();
}