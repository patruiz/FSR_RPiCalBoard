/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#include "EnumHelper.h"
#include <sstream>

using namespace std;
using namespace Keysight::ApiCoreLibraries;


namespace
{

/**
 * @brief local function to check if a number is power of 2
 *
 * @param n the number checked
 * @return true if the number is power of 2, otherwise false
 */
bool isPower2(std::int32_t n)
{
    if (n < 0) return false;
    if (n == 0) return true;
    if ((n & (n - 1)) == 0) return true;
    return false;
}

/**
 * @brief check if the enum is a bit map enum (flag) from all its possible values.
 *  the criteria is if all the possible values are power of 2
 * @param validMembers a map with key = enumValue
 * @return true if it is a bit map enum, otherwise false
 */
bool isBitMapEnum(const std::map<std::int32_t, std::string>& validMembers)
{
    for (auto& kv : validMembers)
    {
        if (!isPower2(kv.first))
        {
            return false;
        }
    }
    return true;
}

} // end of anonymous namespace


std::ostream& EnumHelper::EnumStreamOut(ostream & os, int32_t v, const map<int32_t, string>& validMembers)
{
    if (validMembers.find(v) != validMembers.end())
    {
        return os << validMembers.at(v);
    }

    if (!isBitMapEnum(validMembers))
    {
        return os << v;
    }

    std::ostringstream os1;
    for (auto& kv : validMembers)
    {
        if (v & kv.first)
        {
            os1 << (os1.str().empty() ? kv.second : ("|" + kv.second));
            v &= ~kv.first; // remove this bit
        }
    }

    //Has remaining value
    if (v != 0)
    {
        os1 << (os1.str().empty() ? "" : "|") << v;
    }

    os << os1.str();
    return os;
}