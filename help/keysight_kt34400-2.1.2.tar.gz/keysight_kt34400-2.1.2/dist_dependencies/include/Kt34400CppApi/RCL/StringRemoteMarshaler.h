/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#ifndef RCL_STRING_REMOTE_MARSHALER_H
#define RCL_STRING_REMOTE_MARSHALER_H

 /**
  * @file StringRemoteMarshaler.h
  * @author the Rooftop team
  *
  * this file defines the rpc marshaler class for std::string
  */
#include "CommonExport.h"
#include "ICustomMarshaler.h"
#include "BasicMarshaler.h"
#include <string>

namespace Keysight {
namespace ApiCoreLibraries {

/**
 *@brief rpc marshaler for std::string
*/
class KTROOFTOP_COMMON_API StringRemoteMarshaler : public ICustomMarshaler<std::string>
{
public:
	void BytesToCpp(MarshalBuffer& marshalBuffer, std::string& result) override;
	void CppToBytes(const std::string& input, MarshalBuffer& marshalBuffer) override;
	std::int32_t GetBufferSize() const;
	std::int32_t GetBufferSizeForRPC(const std::string& input) const override;

public:
	Int32Marshaler mInt32Marshaler;
};

}}
#endif // RCL_STRING_REMOTE_MARSHALER_H