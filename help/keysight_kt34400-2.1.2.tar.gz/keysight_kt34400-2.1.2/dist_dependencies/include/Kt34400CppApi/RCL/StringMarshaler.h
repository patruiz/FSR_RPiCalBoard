/******************************************************
 *       Copyright Keysight Technologies 2018-2021
 ******************************************************/
#ifndef RCL_STRING_MARSHALER_H
#define RCL_STRING_MARSHALER_H

/**
 * @file StringMarshaler.h
 * @author the Rooftop team
 *
 * this file defines the marshaler class for std::string
 */

#include "AnyVectorMarshaler.h"
#include <memory>
#include <chrono>
#include <exception>
#include <string>

namespace Keysight {
namespace ApiCoreLibraries {
/**
 *@brief marshaler for std::string
 * Note, this marshaler only support the string length less than 1024, the string is truncated if the size < 1024
*/
class StringMarshaler : public ICustomMarshaler<std::string>
{
public:
    void BytesToCpp(MarshalBuffer& marshalBuffer, std::string& result) override;
    void CppToBytes(const std::string& input, MarshalBuffer& marshalBuffer) override;
    std::int32_t GetBufferSize() const override;

private:
    using AnyVectorByte = typename Keysight::ModularInstruments::AnyVector<std::uint8_t>;
    using AnyVectorByteMarshaler = typename Keysight::ApiCoreLibraries::AnyVectorMarshaler<std::uint8_t>;

    AnyVectorByteMarshaler mAnyVectorByteMarshaler;
};

}}
#endif // RCL_STRING_MARSHALER_H