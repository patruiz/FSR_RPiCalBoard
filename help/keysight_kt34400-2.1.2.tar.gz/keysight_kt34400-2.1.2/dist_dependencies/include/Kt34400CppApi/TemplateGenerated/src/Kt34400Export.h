#ifndef SRC_KT34400_EXPORT_H
#define SRC_KT34400_EXPORT_H

#if defined(KT34400CPPAPI_STATIC)
#define KT34400_API
#else
#if defined(WIN32) || defined (_WIN32)
#ifdef KT34400API_EXPORTS
#define KT34400_API __declspec(dllexport)
#else
#define KT34400_API __declspec(dllimport)
#endif
#else
#define KT34400_API
#endif
#endif

#endif // SRC_KT34400_EXPORT_H
